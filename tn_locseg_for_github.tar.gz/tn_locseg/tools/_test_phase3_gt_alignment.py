"""
端到端验证 phase3 GT 对齐修复:
  1. 用修复后的 _load_gt_seg_resized_to_wb 在全数据集上抽样,统计:
     - 嵌入后前景重心 vs info.center_csv 的误差分布 (voxel)
     - 嵌入后前景体素数 vs nnUNet 64³ 内前景体素数 (应大致 ∝ spacing 比)
  2. 模拟 phase3 训练: 以 GT centroid 在 wb_image / wb_label 同步 crop 96³ patch,
     检查 patch 内 fg ratio 是否合理 (期望: 几个百分点, 类似旧代码 val_fg_stats)
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import json
import os
import sys

import numpy as np
import nibabel as nib
import torch
import torch.nn.functional as F


def load_aligned_label(nnunet_key, case_mapping, prepared_root, gt_seg_root):
    """复刻修复后的 _load_gt_seg_resized_to_wb 主体。"""
    prepared_case = case_mapping[nnunet_key]
    info = json.load(open(os.path.join(prepared_root, prepared_case, "info.json")))

    seg_path = os.path.join(gt_seg_root, f"{nnunet_key}.nii.gz")
    seg_nii = nib.load(seg_path)
    seg = seg_nii.get_fdata()
    if seg.ndim == 4:
        seg = seg[..., 0]
    seg = np.rint(seg).astype(np.int64)
    spacing_nnu = np.array(seg_nii.header.get_zooms()[:3], dtype=np.float64)

    wb_nii = nib.load(info["nii_path"])
    spacing_prep = np.array(wb_nii.header.get_zooms()[:3], dtype=np.float64)
    wb_shape = tuple(int(x) for x in wb_nii.shape[:3])

    target_shape = np.maximum(
        1, np.round(np.array(seg.shape) * spacing_nnu / spacing_prep).astype(np.int64)
    )
    seg_t = torch.from_numpy(seg.astype(np.float32)).view(1, 1, *seg.shape)
    seg_t = F.interpolate(seg_t, size=tuple(int(x) for x in target_shape), mode="nearest")
    seg_resamp = torch.round(seg_t[0, 0]).long().cpu().numpy()

    centroid_path = os.path.join(prepared_root, prepared_case, "centroid.npy")
    center = np.round(np.load(centroid_path).astype(np.float64)).astype(np.int64)
    half = target_shape // 2
    full = np.zeros(wb_shape, dtype=np.int64)

    def emb(c, h, t, dim):
        lo_full = c - h
        hi_full = lo_full + t
        lo_clip = max(0, int(lo_full))
        hi_clip = min(int(dim), int(hi_full))
        if hi_clip <= lo_clip:
            return None, None
        src_lo = lo_clip - int(lo_full)
        src_hi = src_lo + (hi_clip - lo_clip)
        return slice(lo_clip, hi_clip), slice(src_lo, src_hi)

    s0, ss0 = emb(center[0], half[0], target_shape[0], wb_shape[0])
    s1, ss1 = emb(center[1], half[1], target_shape[1], wb_shape[1])
    s2, ss2 = emb(center[2], half[2], target_shape[2], wb_shape[2])
    if s0 is not None:
        full[s0, s1, s2] = seg_resamp[ss0, ss1, ss2]

    mx = 2  # max label
    full = np.clip(full, 0, mx).astype(np.int64, copy=False)
    return full, info, wb_shape, target_shape, spacing_prep


def crop_patch(vol, center_voxel, patch=96):
    half = patch // 2
    cs = patch
    slices = []
    for c, dim in zip(center_voxel, vol.shape):
        lo = max(0, int(c) - half)
        hi = min(dim, lo + cs)
        lo = max(0, hi - cs)
        slices.append(slice(lo, hi))
    return vol[tuple(slices)]


def main():
    case_mapping = json.load(open(
        os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_raw/Dataset001_TN/case_mapping.json')
    ))
    prepared_root = os.path.join(REPO_ROOT, 'prepared_data')
    gt_seg_root = os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_preprocessed/Dataset001_TN/gt_segmentations')

    # 取所有 case 中的前 30 个抽样
    keys = sorted(case_mapping.keys())[:30]
    print(f"Sampling {len(keys)} cases / total {len(case_mapping)}")
    print()

    centroid_errs = []
    fg_counts_aligned = []
    fg_counts_nnu64 = []
    patch_fg_ratios = []
    patch_fg_voxels = []
    bad_cases = []

    for k in keys:
        try:
            full, info, wb_shape, target_shape, spacing_prep = load_aligned_label(
                k, case_mapping, prepared_root, gt_seg_root
            )
        except Exception as e:
            print(f"  [skip] {k}: {e}")
            continue

        fg_idx = np.argwhere(full > 0)
        if len(fg_idx) == 0:
            bad_cases.append(k)
            continue

        centroid_aligned = fg_idx.mean(0)
        centroid_path = os.path.join(prepared_root, case_mapping[k], "centroid.npy")
        center_ras = np.load(centroid_path).astype(np.float64)
        err_vox = np.linalg.norm(centroid_aligned - center_ras)
        err_mm = err_vox * spacing_prep.mean()
        centroid_errs.append((err_vox, err_mm))
        fg_counts_aligned.append(int((full > 0).sum()))

        # 在 nnUNet 64³ 标签内的前景数 (用于横向比较)
        seg64 = nib.load(os.path.join(gt_seg_root, f"{k}.nii.gz")).get_fdata()
        fg_counts_nnu64.append(int((seg64 > 0).sum()))

        # 模拟 phase3 训练: 以 GT centroid (center_ras) 裁 96³ patch
        patch = crop_patch(full, center_ras.astype(np.int64), patch=96)
        if patch.size > 0:
            patch_fg_voxels.append(int((patch > 0).sum()))
            patch_fg_ratios.append(float((patch > 0).mean()))

    if not centroid_errs:
        print("no valid cases!")
        sys.exit(1)

    errs_vox = np.array([e[0] for e in centroid_errs])
    errs_mm = np.array([e[1] for e in centroid_errs])

    print("=" * 60)
    print("前景重心 vs GT centroid (期望: 偏移 ~mask 不对称量级, 5-15 voxel 合理)")
    print("=" * 60)
    print(f"  voxel 误差:  mean={errs_vox.mean():.2f}, median={np.median(errs_vox):.2f}, max={errs_vox.max():.2f}")
    print(f"  mm   误差:  mean={errs_mm.mean():.2f}, median={np.median(errs_mm):.2f}, max={errs_mm.max():.2f}")
    print()
    print("  (旧错位代码: 重心误差 ~91 voxel ≈ 55 mm 是几何错位; 现在 ~7 voxel 是 mask 本身不对称)")
    print()

    print("=" * 60)
    print("前景体素数")
    print("=" * 60)
    print(f"  nnUNet 64³ 内 fg:        mean={np.mean(fg_counts_nnu64):.0f}, median={int(np.median(fg_counts_nnu64))}")
    print(f"  对齐到全脑 vox 后 fg:    mean={np.mean(fg_counts_aligned):.0f}, median={int(np.median(fg_counts_aligned))}")
    ratio = np.mean(fg_counts_aligned) / np.mean(fg_counts_nnu64)
    print(f"  比值 ≈ {ratio:.2f}  (期望 ≈ (1mm/0.6mm)³ ≈ 4.6)")
    print()

    print("=" * 60)
    print("模拟 phase3 训练: 以 GT centroid 裁 96³ patch (image+label 同步)")
    print("=" * 60)
    if patch_fg_voxels:
        pfv = np.array(patch_fg_voxels)
        pfr = np.array(patch_fg_ratios)
        fga = np.array(fg_counts_aligned)
        coverage = pfv / np.maximum(fga, 1)  # patch 内 fg / 全脑 fg
        print(f"  patch 内 fg 体素数:  mean={pfv.mean():.0f}, median={int(np.median(pfv))}, min={pfv.min()}, max={pfv.max()}")
        print(f"  patch 内 fg ratio :  mean={pfr.mean():.4f}, median={np.median(pfr):.4f}")
        print(f"  patch 包覆率 (patch_fg/total_fg): mean={coverage.mean():.3f}, min={coverage.min():.3f}")
        print(f"  非零 patch 比例    : {(pfv > 0).mean()*100:.1f}%")
        print()
        print(f"  (旧代码 val_fg_stats: gt_fg_vox≈9106 是错位标签下的, 不可比)")

    if bad_cases:
        print()
        print(f"WARN: {len(bad_cases)} cases 嵌入后无前景: {bad_cases[:5]}{'...' if len(bad_cases)>5 else ''}")

    print()
    # 真正的成功标准:
    # 1) 嵌入后 fg 数 ≈ nnu64 fg 数 × (spacing_nnu/spacing_prep)³  ✓ 已检查
    # 2) 以 GT centroid 裁 96³ patch 后,所有前景都被包入 (coverage = 1.0)
    # 3) 几何重心与 GT centroid 偏差 < 20 voxel (mask 不对称导致, 不应为 0)
    cov = pfv / np.maximum(fga, 1)
    pass_coverage = float(cov.min()) >= 0.99
    pass_centroid = errs_vox.max() < 20
    if pass_coverage and pass_centroid:
        print("PASS:")
        print(f"  - patch 100% 包覆全脑前景 (min coverage = {cov.min():.3f})")
        print(f"  - 重心误差 < 20 voxel (max = {errs_vox.max():.2f})")
        print(f"  - fg 体素数符合 spacing 比 ({np.mean(fg_counts_aligned)/np.mean(fg_counts_nnu64):.2f} vs 期望 4.6)")
    else:
        if not pass_coverage:
            bad = np.argmin(cov)
            print(f"FAIL: case {keys[bad]} patch 仅包覆 {cov[bad]:.3f} 全脑前景")
        if not pass_centroid:
            print(f"FAIL: 重心误差 max={errs_vox.max():.2f} voxel,可能 mask 异形或 ROI 大于 patch")
        sys.exit(1)


if __name__ == "__main__":
    main()
