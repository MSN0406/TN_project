#!/usr/bin/env python3
"""
从 nnU-Net / nnUNetTrainerLoc 的 training_log*.txt 解析指标，截断到指定 epoch（含），
按 nnunetv2.training.logging.nnunet_logger.nnUNetLogger.plot_progress_png 的样式重画 progress 图。

示例:
  python tools/replot_nnunet_progress_upto_epoch.py \\
    --fold-dir nnUNet_data/nnUNet_results_p3_smooth/Dataset001_TN/nnUNetTrainerLoc__nnUNetPlans__3d_fullres/fold_0 \\
    --max-epoch 200
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from __future__ import annotations

import argparse
import glob
import os
import re
import shutil
from typing import Any

import matplotlib

matplotlib.use("agg")
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns


EPOCH_HDR = re.compile(r"Epoch (\d+)\s*$")
TRAIN_LOSS = re.compile(r"train_loss\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?|nan)")
VAL_LOSS = re.compile(r"val_loss\s+([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?|nan)")
PSEUDO_DICE = re.compile(r"Pseudo dice\s+\[(.*)\]\s*$")
EPOCH_TIME = re.compile(r"Epoch time:\s+([+-]?\d*\.?\d+)\s+s")
SEG_LR = re.compile(r"Current learning rate:\s+seg=([+-]?\d*\.?\d+(?:[eE][+-]?\d+)?)")
FLOAT_IN_BRACKETS = re.compile(r"np\.float(?:32|64)\(([^)]+)\)")


def _latest_training_log(fold_dir: str) -> str:
    paths = sorted(
        glob.glob(os.path.join(fold_dir, "training_log_*.txt")),
        key=os.path.getmtime,
    )
    if not paths:
        raise FileNotFoundError(f"no training_log_*.txt under {fold_dir}")
    return paths[-1]


def _parse_pseudo_dice_mean(line: str) -> float:
    m = PSEUDO_DICE.search(line)
    if not m:
        return float("nan")
    inner = m.group(1)
    parts = FLOAT_IN_BRACKETS.findall(inner)
    vals: list[float] = []
    for p in parts:
        p = p.strip()
        if p.lower() == "nan":
            vals.append(float("nan"))
        else:
            vals.append(float(p))
    if not vals:
        return float("nan")
    arr = np.array(vals, dtype=np.float64)
    if np.all(np.isnan(arr)):
        return float("nan")
    return float(np.nanmean(arr))


def parse_training_log(path: str, max_epoch: int) -> dict[str, list[Any]]:
    """返回 nnUNetLogger.my_fantastic_logging 同结构字典，仅含 epoch 0..max_epoch。"""
    max_epoch = int(max_epoch)
    with open(path, encoding="utf-8", errors="replace") as f:
        lines = f.readlines()

    blocks: list[tuple[int, list[str]]] = []
    cur_n: int | None = None
    cur_lines: list[str] = []

    for line in lines:
        em = EPOCH_HDR.search(line)
        if em:
            if cur_n is not None:
                blocks.append((cur_n, cur_lines))
            cur_n = int(em.group(1))
            cur_lines = []
        elif cur_n is not None:
            cur_lines.append(line)
    if cur_n is not None:
        blocks.append((cur_n, cur_lines))

    blocks.sort(key=lambda x: x[0])
    by_epoch = {n: bl for n, bl in blocks}

    train_losses: list[float] = []
    val_losses: list[float] = []
    mean_fg_dice: list[float] = []
    dice_per_class_or_region: list[Any] = []
    lrs: list[float] = []
    epoch_start_timestamps: list[float] = []
    epoch_end_timestamps: list[float] = []

    t0 = 0.0
    for e in range(max_epoch + 1):
        if e not in by_epoch:
            raise ValueError(f"missing epoch {e} in log while building 0..{max_epoch}")
        bl = "\n".join(by_epoch[e])
        tm = TRAIN_LOSS.search(bl)
        vm = VAL_LOSS.search(bl)
        if not tm or not vm:
            raise ValueError(f"epoch {e}: missing train_loss or val_loss")
        train_losses.append(float(tm.group(1)) if tm.group(1).lower() != "nan" else float("nan"))
        val_losses.append(float(vm.group(1)) if vm.group(1).lower() != "nan" else float("nan"))

        pdl = None
        for ln in by_epoch[e]:
            if "Pseudo dice" in ln:
                pdl = ln
                break
        mean_fg_dice.append(_parse_pseudo_dice_mean(pdl) if pdl else float("nan"))

        if pdl and PSEUDO_DICE.search(pdl):
            inner = PSEUDO_DICE.search(pdl).group(1)
            raw_vals = []
            for x in FLOAT_IN_BRACKETS.findall(inner):
                raw_vals.append(float("nan") if x.strip().lower() == "nan" else float(x.strip()))
            dice_per_class_or_region.append(raw_vals)
        else:
            dice_per_class_or_region.append([])

        etm = EPOCH_TIME.search(bl)
        dur = float(etm.group(1)) if etm else 0.0
        epoch_start_timestamps.append(t0)
        t0 += dur
        epoch_end_timestamps.append(t0)

        lrm = SEG_LR.search(bl)
        if not lrm:
            raise ValueError(f"epoch {e}: missing seg learning rate line")
        lrs.append(float(lrm.group(1)))

    ema_fg_dice: list[float] = []
    for i, md in enumerate(mean_fg_dice):
        if i == 0:
            ema_fg_dice.append(md)
        else:
            prev = ema_fg_dice[-1]
            if np.isnan(md) and np.isnan(prev):
                ema_fg_dice.append(float("nan"))
            elif np.isnan(md):
                ema_fg_dice.append(prev)
            elif np.isnan(prev):
                ema_fg_dice.append(md)
            else:
                ema_fg_dice.append(prev * 0.9 + 0.1 * md)

    return {
        "mean_fg_dice": mean_fg_dice,
        "ema_fg_dice": ema_fg_dice,
        "dice_per_class_or_region": dice_per_class_or_region,
        "train_losses": train_losses,
        "val_losses": val_losses,
        "lrs": lrs,
        "epoch_start_timestamps": epoch_start_timestamps,
        "epoch_end_timestamps": epoch_end_timestamps,
    }


def plot_like_nnunet(logging: dict[str, list[Any]], output_png: str) -> None:
    """与 nnUNetLogger.plot_progress_png 一致的三联图。"""
    n = min(len(v) for v in logging.values() if isinstance(v, list))
    if n < 1:
        raise ValueError("empty logging")
    epoch = n - 1
    sns.set(font_scale=2.5)
    fig, ax_all = plt.subplots(3, 1, figsize=(30, 54))
    x_values = list(range(epoch + 1))

    ax = ax_all[0]
    ax2 = ax.twinx()
    ax.plot(
        x_values,
        logging["train_losses"][: n],
        color="b",
        ls="-",
        label="loss_tr",
        linewidth=4,
    )
    ax.plot(
        x_values,
        logging["val_losses"][: n],
        color="r",
        ls="-",
        label="loss_val",
        linewidth=4,
    )
    ax2.plot(
        x_values,
        logging["mean_fg_dice"][: n],
        color="g",
        ls="dotted",
        label="pseudo dice",
        linewidth=3,
    )
    ax2.plot(
        x_values,
        logging["ema_fg_dice"][: n],
        color="g",
        ls="-",
        label="pseudo dice (mov. avg.)",
        linewidth=4,
    )
    ax.set_xlabel("epoch")
    ax.set_ylabel("loss")
    ax2.set_ylabel("pseudo dice")
    ax.legend(loc=(0, 1))
    ax2.legend(loc=(0.2, 1))

    ax = ax_all[1]
    durs = [
        i - j
        for i, j in zip(
            logging["epoch_end_timestamps"][:n],
            logging["epoch_start_timestamps"][:n],
        )
    ]
    ax.plot(x_values, durs, color="b", ls="-", label="epoch duration", linewidth=4)
    ylim = [0, ax.get_ylim()[1]]
    ax.set(ylim=ylim)
    ax.set_xlabel("epoch")
    ax.set_ylabel("time [s]")
    ax.legend(loc=(0, 1))

    ax = ax_all[2]
    ax.plot(x_values, logging["lrs"][:n], color="b", ls="-", label="learning rate", linewidth=4)
    ax.set_xlabel("epoch")
    ax.set_ylabel("learning rate")
    ax.legend(loc=(0, 1))

    plt.tight_layout()
    fig.savefig(output_png)
    plt.close()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--fold-dir",
        default=os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_results_p3_smooth/Dataset001_TN/nnUNetTrainerLoc__nnUNetPlans__3d_fullres/fold_0'),
        help="含 training_log_*.txt 的 fold 目录",
    )
    ap.add_argument(
        "--max-epoch",
        type=int,
        default=200,
        help="保留到该 epoch（含）；即 x 轴为 0..max_epoch",
    )
    ap.add_argument(
        "--log",
        default=None,
        help="指定 training_log 路径；默认取该 fold 下最新 training_log_*.txt",
    )
    ap.add_argument(
        "-o",
        "--output",
        default=None,
        help="输出 png；默认 fold_dir/progress_upto_epoch{max}.png",
    )
    ap.add_argument(
        "--replace-progress",
        action="store_true",
        help="将 fold_dir/progress.png 备份为 progress_full_run_backup.png 并写入新 progress.png",
    )
    args = ap.parse_args()

    fold_dir = os.path.abspath(args.fold_dir)
    log_path = os.path.abspath(args.log) if args.log else _latest_training_log(fold_dir)
    out = args.output or os.path.join(fold_dir, f"progress_upto_epoch{args.max_epoch}.png")

    logging_dict = parse_training_log(log_path, args.max_epoch)
    plot_like_nnunet(logging_dict, out)
    print(f"wrote {out} (from log {log_path}, epochs 0..{args.max_epoch})")

    if args.replace_progress:
        main_png = os.path.join(fold_dir, "progress.png")
        bak = os.path.join(fold_dir, "progress_full_run_backup.png")
        if os.path.isfile(main_png):
            if os.path.isfile(bak):
                os.remove(bak)
            os.replace(main_png, bak)
            print(f"renamed existing progress.png -> {bak}")
        shutil.copy2(out, main_png)
        print(f"copied -> {main_png}")


if __name__ == "__main__":
    main()
