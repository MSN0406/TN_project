"""
等价性单元测试: 新 _load_and_crop_gt_label_patch  vs  旧 (整脑 long + hard_crop_3d) 路径。

不依赖 nnUNet trainer; 直接构造迷你 case + 复刻旧实现作为参考, 与新实现对比。
跑法:
    cd ${TN_ROOT} && python tools/_test_label_crop_equiv.py
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import os
import sys
import tempfile

import numpy as np
import torch
import torch.nn.functional as F


# ---------- 旧实现 (1:1 复刻) ----------

def old_centroid_norm_to_voxel_center(centroid_norm: torch.Tensor, spatial_shape):
    D, H, W = spatial_shape
    scale = torch.tensor(
        [max(D - 1, 1), max(H - 1, 1), max(W - 1, 1)],
        device=centroid_norm.device, dtype=torch.float32,
    )
    out = torch.round(centroid_norm.float() * scale).long()
    out[:, 0] = out[:, 0].clamp(0, D - 1)
    out[:, 1] = out[:, 1].clamp(0, H - 1)
    out[:, 2] = out[:, 2].clamp(0, W - 1)
    return out


def old_hard_crop_3d(volume, center_voxel, crop_size):
    if isinstance(crop_size, int):
        crop_size = (crop_size, crop_size, crop_size)
    B, C, D, H, W = volume.shape
    crops = []
    for b in range(B):
        c = center_voxel[b].long()
        halves = [s // 2 for s in crop_size]
        slices = []
        for dim_idx, (dim_size, half, cs) in enumerate(zip([D, H, W], halves, crop_size)):
            lo = max(0, c[dim_idx].item() - half)
            hi = min(dim_size, lo + cs)
            lo = max(0, hi - cs)
            slices.append(slice(lo, hi))
        crop = volume[b:b + 1, :, slices[0], slices[1], slices[2]]
        crops.append(crop)
    return torch.cat(crops, dim=0)


def old_build_and_crop(seg_list, case_shapes, padded_shape, centroid_norm, patch_size):
    """旧路径: 整脑 long batch + hard_crop_3d。"""
    B = len(seg_list)
    Dp, Hp, Wp = padded_shape
    batch_lbl = torch.zeros(B, 1, Dp, Hp, Wp, dtype=torch.long)
    for i, seg_np in enumerate(seg_list):
        d_i, h_i, w_i = case_shapes[i]
        batch_lbl[i, 0, :d_i, :h_i, :w_i] = torch.from_numpy(seg_np).long()
    center_vox = old_centroid_norm_to_voxel_center(centroid_norm, (Dp, Hp, Wp))
    return old_hard_crop_3d(batch_lbl, center_vox, patch_size)


# ---------- 新实现 (从 trainer 抽取的纯函数版本, 不带 self) ----------

def new_load_and_crop(
    seg_list,
    case_shapes,
    padded_shape,
    centroid_norm,
    patch_size,
    max_label_value=2,
):
    if isinstance(patch_size, int):
        patch_size = (patch_size, patch_size, patch_size)
    crop_d = int(patch_size[0])
    crop_h = int(patch_size[1])
    crop_w = int(patch_size[2])
    halves = (crop_d // 2, crop_h // 2, crop_w // 2)
    crops = (crop_d, crop_h, crop_w)
    pad_dims = (int(padded_shape[0]), int(padded_shape[1]), int(padded_shape[2]))

    centroid_np = centroid_norm.detach().to(torch.float32).cpu().numpy()
    case_shapes_np = np.asarray(case_shapes, dtype=np.int64)

    scale = np.array(
        [max(pad_dims[0] - 1, 1), max(pad_dims[1] - 1, 1), max(pad_dims[2] - 1, 1)],
        dtype=np.float32,
    )
    center_vox = np.rint(centroid_np * scale).astype(np.int64)
    center_vox[:, 0] = np.clip(center_vox[:, 0], 0, pad_dims[0] - 1)
    center_vox[:, 1] = np.clip(center_vox[:, 1], 0, pad_dims[1] - 1)
    center_vox[:, 2] = np.clip(center_vox[:, 2], 0, pad_dims[2] - 1)

    use_uint8 = max_label_value <= 255
    out_dtype = np.uint8 if use_uint8 else np.int64
    B = len(seg_list)
    out = np.zeros((B, 1, crop_d, crop_h, crop_w), dtype=out_dtype)

    for i in range(B):
        d_i = int(case_shapes_np[i, 0])
        h_i = int(case_shapes_np[i, 1])
        w_i = int(case_shapes_np[i, 2])

        lo = [0, 0, 0]
        hi = [0, 0, 0]
        for dim_idx in range(3):
            c = int(center_vox[i, dim_idx])
            half = halves[dim_idx]
            cs = crops[dim_idx]
            pad = pad_dims[dim_idx]
            lo_d = max(0, c - half)
            hi_d = min(pad, lo_d + cs)
            lo_d = max(0, hi_d - cs)
            lo[dim_idx] = lo_d
            hi[dim_idx] = hi_d

        cd_hi = min(hi[0], d_i)
        ch_hi = min(hi[1], h_i)
        cw_hi = min(hi[2], w_i)
        if cd_hi <= lo[0] or ch_hi <= lo[1] or cw_hi <= lo[2]:
            continue

        seg_np = seg_list[i]
        src = seg_np[lo[0]:cd_hi, lo[1]:ch_hi, lo[2]:cw_hi]
        if use_uint8:
            src = np.clip(src, 0, 255).astype(np.uint8, copy=False)
        pd_hi = cd_hi - lo[0]
        ph_hi = ch_hi - lo[1]
        pw_hi = cw_hi - lo[2]
        out[i, 0, :pd_hi, :ph_hi, :pw_hi] = src

    return torch.from_numpy(out).long()


# ---------- 测试用例 ----------

def make_case(rng, d, h, w, max_label=2):
    return rng.integers(0, max_label + 1, size=(d, h, w), dtype=np.int64)


def run_case(name, seg_list, case_shapes, padded_shape, centroids, patch_size):
    centroid_norm = torch.tensor(centroids, dtype=torch.float32)
    old = old_build_and_crop(seg_list, case_shapes, padded_shape, centroid_norm, patch_size)
    new = new_load_and_crop(seg_list, case_shapes, padded_shape, centroid_norm, patch_size)
    assert old.shape == new.shape, f"{name}: shape mismatch {old.shape} vs {new.shape}"
    eq = torch.equal(old, new)
    print(f"  [{name}] shape={tuple(old.shape)}  equal={eq}")
    if not eq:
        diff = (old != new).nonzero(as_tuple=False)
        print(f"    first diff at {diff[0].tolist()}: old={old[tuple(diff[0])].item()}, new={new[tuple(diff[0])].item()}")
        return False
    return True


def main():
    rng = np.random.default_rng(0)
    all_pass = True

    # 1. 中心 centroid, padded == case
    print("Test 1: centered centroid, no padding")
    seg_list = [make_case(rng, 64, 64, 64)]
    all_pass &= run_case("center", seg_list, [(64, 64, 64)], (64, 64, 64),
                         [[0.5, 0.5, 0.5]], 32)

    # 2. case 比 padded 小, batch 内多 case 形状不一
    print("Test 2: heterogeneous batch with padding")
    seg_list = [
        make_case(rng, 50, 60, 70),
        make_case(rng, 64, 50, 55),
        make_case(rng, 40, 64, 64),
    ]
    case_shapes = [(50, 60, 70), (64, 50, 55), (40, 64, 64)]
    padded = (64, 64, 70)  # max along each dim
    centroids = [[0.5, 0.5, 0.5], [0.3, 0.7, 0.2], [0.9, 0.1, 0.5]]
    all_pass &= run_case("hetero", seg_list, case_shapes, padded, centroids, 32)

    # 3. centroid 在 case 边界外 (padded 区域内): 验证 case 边界外应为 0
    print("Test 3: centroid in padded but outside case")
    seg_list = [make_case(rng, 30, 30, 30)]
    case_shapes = [(30, 30, 30)]
    padded = (64, 64, 64)
    centroids = [[0.9, 0.9, 0.9]]  # 落在 case 之外
    all_pass &= run_case("outside_case", seg_list, case_shapes, padded, centroids, 32)

    # 4. centroid 紧贴角点
    print("Test 4: centroid at corner (0,0,0)")
    seg_list = [make_case(rng, 64, 64, 64)]
    all_pass &= run_case("corner_lo", seg_list, [(64, 64, 64)], (64, 64, 64),
                         [[0.0, 0.0, 0.0]], 32)
    all_pass &= run_case("corner_hi", seg_list, [(64, 64, 64)], (64, 64, 64),
                         [[1.0, 1.0, 1.0]], 32)

    # 5. case 显著小于 padded (case 在 padded 一角, 大量 zero-padding 区域)
    # 注: 实际生产 invariant 是 padded == max(case_shape) >= patch_size。
    # 旧 hard_crop_3d 在 padded < patch 时返回 (padded,) 形状, 配合下游 F.interpolate
    # 强行缩放, 是一个潜在的"前景拉伸 bug"; 由于流水线里永远 padded > patch, 不会触发。
    # 此处只验证生产 invariant 下的等价性。
    print("Test 5: tiny case in large padded volume")
    seg_list = [make_case(rng, 20, 25, 30)]
    case_shapes = [(20, 25, 30)]
    padded = (96, 96, 96)
    centroids = [[0.05, 0.1, 0.12]]  # 落在 case 内
    all_pass &= run_case("tiny_case", seg_list, case_shapes, padded, centroids, 32)
    centroids = [[0.5, 0.5, 0.5]]    # 落在 case 外的 padding
    all_pass &= run_case("tiny_outside", seg_list, case_shapes, padded, centroids, 32)

    # 6. 非对称 patch
    print("Test 6: anisotropic patch")
    seg_list = [make_case(rng, 80, 64, 96)]
    case_shapes = [(80, 64, 96)]
    padded = (96, 96, 96)
    centroids = [[0.4, 0.6, 0.5]]
    all_pass &= run_case("aniso", seg_list, case_shapes, padded, centroids, (24, 32, 48))

    # 7. 大随机批次, 模拟训练真实情景
    print("Test 7: random stress test (B=4, varying shapes)")
    for trial in range(5):
        B = 4
        case_shapes = [
            (rng.integers(40, 100), rng.integers(40, 100), rng.integers(40, 100))
            for _ in range(B)
        ]
        padded = (
            max(s[0] for s in case_shapes),
            max(s[1] for s in case_shapes),
            max(s[2] for s in case_shapes),
        )
        seg_list = [make_case(rng, *s) for s in case_shapes]
        centroids = rng.random((B, 3)).astype(np.float32).tolist()
        all_pass &= run_case(f"stress_t{trial}", seg_list, case_shapes, padded,
                             centroids, 32)

    if all_pass:
        print()
        print("ALL EQUIVALENCE TESTS PASSED.")
        sys.exit(0)
    else:
        print()
        print("FAILED.")
        sys.exit(1)


if __name__ == "__main__":
    main()
