"""
dataset.py
==========
PyTorch Dataset for LocSegNet 训练.

每个 sample 包含:
  - whole_brain: (1, D, H, W) 原始 whole brain volume
  - centroid_ras: (3,) 体素坐标 (数组索引)
  - centroid_norm: (3,) 归一化坐标 [0, 1]
  - side: (1,) 侧别标签 (0.0=ipsi, 1.0=contra)
  - mask: (crop_size, crop_size, crop_size) 分割 GT mask
  - case_id: str

支持按 phase 返回不同内容以节省内存.
"""

import json
import os
import random

import nibabel as nib
import numpy as np
import torch
from torch.utils.data import Dataset


class TNLocSegDataset(Dataset):
    """
    三叉神经定位+分割数据集.

    参数:
        prepared_dir: 预处理数据目录 (prepare_dataset.py 的输出)
        case_ids: 要使用的 case id 列表 (None = 全部)
        phase: 训练阶段 (1=仅定位, 2=仅分割, 3=联合)
        transform: 数据增强 transform
        cache_wb: 是否缓存 whole brain (内存充足时建议开启)
        preload: 是否预加载全部数据到内存
        lr_flip_prob: 左右翻转 (dim0) 的概率, 仅训练集使用 (翻转时同步翻转 centroid, 不改变 side 标签)
    """

    def __init__(self, prepared_dir, case_ids=None, phase=1,
                 transform=None, cache_wb=False, preload=False,
                 lr_flip_prob=0.0, mask_size=None):
        self.prepared_dir = prepared_dir
        self.phase = phase
        self.transform = transform
        self.cache_wb = cache_wb
        self.lr_flip_prob = lr_flip_prob
        self.mask_size = mask_size  # 原始标注尺寸, None=不裁剪
        self._wb_cache = {}

        # 加载元数据
        with open(os.path.join(prepared_dir, "metadata.json")) as f:
            self.metadata = json.load(f)

        # 确定使用的 case 列表
        if case_ids is not None:
            self.case_ids = case_ids
        else:
            self.case_ids = self.metadata["case_ids"]

        # 预加载 case info
        self.cases = []
        for cid in self.case_ids:
            case_dir = os.path.join(prepared_dir, cid)
            info_path = os.path.join(case_dir, "info.json")
            if not os.path.isfile(info_path):
                continue
            with open(info_path) as f:
                info = json.load(f)
            info["case_dir"] = case_dir
            info["case_id"] = cid
            self.cases.append(info)

        # 预加载
        if preload:
            print(f"[Dataset] Preloading {len(self.cases)} cases...")
            for case in self.cases:
                self._load_wb(case["nii_path"])
            print(f"[Dataset] Preload done. Cached {len(self._wb_cache)} WB volumes.")

    def __len__(self):
        return len(self.cases)

    def _load_wb(self, nii_path):
        """加载 whole brain, 支持缓存."""
        if self.cache_wb and nii_path in self._wb_cache:
            return self._wb_cache[nii_path]

        nii = nib.load(nii_path)
        data = nii.get_fdata().astype(np.float32)
        # 处理 4D 数据: 取第一个 volume
        if data.ndim == 4:
            data = data[:, :, :, 0]

        if self.cache_wb:
            self._wb_cache[nii_path] = data

        return data

    @staticmethod
    def _parse_side(case_id):
        """从 case_id 中提取侧别: 0.0=ipsi/left, 1.0=contra/right."""
        if case_id.endswith("_ipsi") or case_id.endswith("_left"):
            return 0.0
        elif case_id.endswith("_contra") or case_id.endswith("_right"):
            return 1.0
        else:
            return 0.0  # fallback

    def __getitem__(self, idx):
        case = self.cases[idx]
        case_dir = case["case_dir"]

        # --- 侧别标签 ---
        side = self._parse_side(case["case_id"])

        # --- 加载 centroid ---
        centroid_ras = np.load(os.path.join(case_dir, "centroid.npy"))  # (3,)

        # --- 加载 whole brain ---
        wb = self._load_wb(case["nii_path"])
        wb_shape = np.array(wb.shape[:3], dtype=np.float32)

        # 归一化坐标到 [0, 1]
        centroid_norm = centroid_ras.astype(np.float32) / (wb_shape - 1)

        # --- 加载 mask ---
        mask = None
        if self.phase >= 2:
            mask_path = os.path.join(case_dir, "mask_aligned.nii.gz")
            mask_nii = nib.load(mask_path)
            mask = mask_nii.get_fdata().astype(np.int64)
            # Center-crop 到原始标注尺寸 (64³→48³)
            if self.mask_size is not None and mask.shape[0] > self.mask_size:
                ms = self.mask_size
                d, h, w = mask.shape
                d0, h0, w0 = (d - ms) // 2, (h - ms) // 2, (w - ms) // 2
                mask = mask[d0:d0+ms, h0:h0+ms, w0:w0+ms]

        # --- Whole brain 强度归一化 (z-score, per-volume) ---
        # 仅对前景 (>0) 区域计算统计量
        fg_mask = wb > 0
        if fg_mask.sum() > 100:
            mean = wb[fg_mask].mean()
            std = wb[fg_mask].std()
            wb = (wb - mean) / (std + 1e-8)
        else:
            wb = (wb - wb.mean()) / (wb.std() + 1e-8)

        # --- 左右翻转增强 (dim0) ---
        if self.lr_flip_prob > 0 and random.random() < self.lr_flip_prob:
            wb = wb[::-1, :, :].copy()  # 沿 dim0 (L-R) 翻转
            centroid_norm[0] = 1.0 - centroid_norm[0]
            centroid_ras[0] = wb_shape[0] - 1 - centroid_ras[0]
            if mask is not None:
                mask = mask[::-1, :, :].copy()
            # side 标签不变: 翻转后仍然是同一侧别, 只是物理位置镜像

        # --- 数据增强 ---
        if self.transform is not None:
            wb, centroid_norm, mask = self.transform(wb, centroid_norm, mask)

        # --- 构建返回字典 ---
        sample = {
            "whole_brain": torch.from_numpy(wb).unsqueeze(0).float(),  # (1, D, H, W)
            "centroid_ras": torch.from_numpy(centroid_ras).float(),
            "centroid_norm": torch.from_numpy(centroid_norm).float(),
            "side": torch.tensor([side], dtype=torch.float32),  # (1,) 侧别标签
            "wb_shape": torch.from_numpy(wb_shape).float(),
            "case_id": case["case_id"],
        }

        if mask is not None:
            sample["mask"] = torch.from_numpy(mask).long()  # (crop_D, crop_H, crop_W)

        return sample


def _filter_case_ids_by_source(case_ids, case_filter):
    """
    case_filter:
        None: 不筛选
        "openneuro": 仅 BIDS/OpenNeuro 风格 case_id（以 sub- 开头）
        "inhouse": 仅院内病例（不以 sub- 开头）
    """
    if case_filter is None:
        return list(case_ids)
    cf = str(case_filter).lower().strip()
    if cf in ("none", "", "all"):
        return list(case_ids)
    if cf == "openneuro":
        return [c for c in case_ids if str(c).startswith("sub-")]
    if cf == "inhouse":
        return [c for c in case_ids if not str(c).startswith("sub-")]
    raise ValueError(
        f"case_filter 必须是 None/'openneuro'/'inhouse', 收到: {case_filter!r}"
    )


def get_train_val_split(prepared_dir, train_ratio=0.8, seed=42, case_filter=None):
    """
    按 MRN 分组做训练/验证分割 (同一个病人的 ipsi 和 contra 不拆开).

    参数:
        case_filter: 见 _filter_case_ids_by_source；用于只在 OpenNeuro 或只在院内子集上划分.

    返回:
        train_ids: list of case_id
        val_ids: list of case_id
    """
    with open(os.path.join(prepared_dir, "metadata.json")) as f:
        metadata = json.load(f)

    case_ids = _filter_case_ids_by_source(metadata["case_ids"], case_filter)
    if len(case_ids) == 0:
        raise ValueError(
            f"筛选后 case_ids 为空 (case_filter={case_filter!r}), 请检查 prepared_dir 与 metadata"
        )

    # 按 MRN 分组
    mrn_groups = {}
    for cid in case_ids:
        # case_id 格式: "MRN_side"
        parts = cid.rsplit("_", 1)
        mrn = parts[0]
        if mrn not in mrn_groups:
            mrn_groups[mrn] = []
        mrn_groups[mrn].append(cid)

    # 随机分割 MRN
    mrn_list = sorted(mrn_groups.keys())
    random.seed(seed)
    random.shuffle(mrn_list)

    n_train = int(len(mrn_list) * train_ratio)
    train_mrns = set(mrn_list[:n_train])

    train_ids = []
    val_ids = []
    for mrn, cids in mrn_groups.items():
        if mrn in train_mrns:
            train_ids.extend(cids)
        else:
            val_ids.extend(cids)

    tag = f" case_filter={case_filter}" if case_filter else ""
    print(f"[Split]{tag} {len(train_mrns)} train MRNs ({len(train_ids)} cases), "
          f"{len(mrn_list) - n_train} val MRNs ({len(val_ids)} cases)")

    return train_ids, val_ids


def locseg_collate_fn(batch):
    """
    自定义 collate: whole brain 尺寸可能不同, 需要 padding.
    """
    # 找最大尺寸
    max_d = max(s["whole_brain"].shape[1] for s in batch)
    max_h = max(s["whole_brain"].shape[2] for s in batch)
    max_w = max(s["whole_brain"].shape[3] for s in batch)

    # Pad 到统一尺寸
    padded_wb = []
    for s in batch:
        wb = s["whole_brain"]  # (1, D, H, W)
        d, h, w = wb.shape[1:]
        pad = (0, max_w - w, 0, max_h - h, 0, max_d - d)  # (w_before, w_after, h_before, ...)
        padded_wb.append(torch.nn.functional.pad(wb, pad, value=0))

    result = {
        "whole_brain": torch.stack(padded_wb),  # (B, 1, D, H, W)
        "centroid_ras": torch.stack([s["centroid_ras"] for s in batch]),
        "centroid_norm": torch.stack([s["centroid_norm"] for s in batch]),
        "side": torch.stack([s["side"] for s in batch]),  # (B, 1)
        "wb_shape": torch.stack([s["wb_shape"] for s in batch]),
        "case_id": [s["case_id"] for s in batch],
    }

    if "mask" in batch[0]:
        result["mask"] = torch.stack([s["mask"] for s in batch])

    return result
