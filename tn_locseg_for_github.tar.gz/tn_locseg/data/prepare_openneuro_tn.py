#!/usr/bin/env python3
"""
prepare_openneuro_tn.py
=======================
将 OpenNeuro TN 分割包 (BIDS + Cohort_Data_with_Centroids.xlsx + Cropped TIFF)
转换为与 prepare_dataset.py 相同目录结构, 供 LocSegNet 定位+分割训练使用.

输入 (默认路径可在命令行覆盖):
  - BIDS 根目录: 含 sub-XXX/anat/*_T1w.nii.gz
  - TN_OpenNeuro_Segmentation_Dataset/: Excel + Cropped_MRI_{Left,Right} + Manual_Segmentations_{Left,Right}

每个 case 为「一个 BIDS 受试者 × 一个半球 (left/right)」:
  case_id = "{BIDS_ID}_{hemi}"  例如 sub-010_left, sub-010_right

质心: 使用表中 R_Sagittal/R_Coronal/R_Axial (右半球目标) 或 L_* (左半球目标),
      经与 prepare_dataset 相同的 CSV→RAS 体素索引转换.

用法:
  cd /path/to/tn_locseg
  python data/prepare_openneuro_tn.py \\
    --bids_root ${TN_OPENNEURO_DIR} \\
    --seg_root ${TN_OPENNEURO_SEG_DIR} \\
    --out_dir ${TN_ROOT}/prepared_data_openneuro

然后在 configs 中设置 data.prepared_dir 指向 out_dir 即可训练.
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys

import nibabel as nib
import numpy as np
import pandas as pd

# 项目根目录
_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# --- 与 prepare_dataset.py 保持一致 (避免 import 该文件时拉取 yaml/torch) ---
def csv_to_array_index(sag_csv, cor_csv, axi_csv, wb_shape):
    S0, S1, S2 = wb_shape[:3]
    sag_idx = int(round(sag_csv))
    cor_idx = int(round(S1 - 1 - cor_csv))
    axi_idx = int(round(S2 - 1 - axi_csv))
    return np.array([sag_idx, cor_idx, axi_idx], dtype=np.int64)


def transform_tiff_mask(mask_tiff):
    mask = np.transpose(mask_tiff, (2, 1, 0))
    mask = np.flip(mask, axis=(0, 1, 2)).copy()
    return mask


def embed_mask_in_crop(mask_ras, crop_size):
    ms = np.array(mask_ras.shape)
    cs = np.array(crop_size)
    result = np.zeros(crop_size, dtype=mask_ras.dtype)
    offset = (cs - ms) // 2
    src_start = np.maximum(0, -offset)
    src_end = np.minimum(ms, cs - offset)
    dst_start = np.maximum(0, offset)
    dst_end = dst_start + (src_end - src_start)
    result[dst_start[0]:dst_end[0],
           dst_start[1]:dst_end[1],
           dst_start[2]:dst_end[2]] = mask_ras[src_start[0]:src_end[0],
                                                src_start[1]:src_end[1],
                                                src_start[2]:src_end[2]]
    return result


def _import_tifffile():
    try:
        import tifffile
        return tifffile
    except ImportError as e:
        raise ImportError(
            "需要 tifffile: pip install tifffile",
        ) from e


def find_t1w(bids_root: str, bids_id: str) -> str | None:
    """返回 sub-XXX 的首选 T1w NIfTI 路径."""
    anat = os.path.join(bids_root, bids_id, "anat")
    if not os.path.isdir(anat):
        return None
    cands = sorted(glob.glob(os.path.join(anat, "*_T1w.nii.gz")))
    return cands[0] if cands else None


def bids_id_to_int(bids_id: str) -> int:
    """sub-010 -> 10, 与 {id}_cropped.tiff 文件名对齐."""
    m = re.match(r"sub-0*(\d+)$", bids_id.strip(), re.I)
    if m:
        return int(m.group(1))
    m = re.match(r"sub-(\d+)$", bids_id.strip(), re.I)
    if m:
        return int(m.group(1))
    raise ValueError(f"无法解析 BIDS_ID: {bids_id}")


def find_tiff_pair(seg_root: str, file_num: int, hemi: str) -> tuple[str | None, str | None]:
    """
    hemi: 'left' | 'right'
    返回 (mri_tiff, manual_tiff) 或 (None, None).
    """
    hdir = "Left" if hemi == "left" else "Right"
    mri_dir = os.path.join(seg_root, f"Cropped_MRI_{hdir}")
    man_dir = os.path.join(seg_root, f"Manual_Segmentations_{hdir}")
    mri_pat = os.path.join(mri_dir, f"{file_num}_cropped.tiff")
    if not os.path.isfile(mri_pat):
        return None, None
    # 手工标注文件名在 Left/Right 下可能都叫 *_right_manual.tiff, 用通配符
    g = sorted(glob.glob(os.path.join(man_dir, f"{file_num}_*.tiff")))
    if not g:
        return mri_pat, None
    return mri_pat, g[0]


def row_has_valid_coords(row: pd.Series, hemi: str) -> bool:
    if hemi == "right":
        cols = ("R_Sagittal", "R_Coronal", "R_Axial")
    else:
        cols = ("L_Sagittal", "L_Coronal", "L_Axial")
    try:
        for c in cols:
            v = float(row[c])
            if np.isnan(v):
                return False
        return True
    except (TypeError, ValueError):
        return False


def prepare_openneuro(
    bids_root: str,
    seg_root: str,
    out_dir: str,
    cohort_xlsx: str | None = None,
    crop_size: int = 64,
    segmented_flag: str = "Y",
) -> list[dict]:
    tifffile = _import_tifffile()
    cohort_xlsx = cohort_xlsx or os.path.join(seg_root, "Cohort_Data_with_Centroids.xlsx")
    df = pd.read_excel(cohort_xlsx)
    os.makedirs(out_dir, exist_ok=True)

    crop_size_arr = np.array([crop_size, crop_size, crop_size], dtype=np.int64)
    stats = {
        "total": 0, "success": 0,
        "skip_not_segmented": 0, "skip_no_t1": 0,
        "skip_no_tiff": 0, "skip_bad_coord": 0, "skip_mask_read": 0,
    }
    all_cases: list[dict] = []

    for _, row in df.iterrows():
        bids_id = str(row["BIDS_ID"]).strip()
        seg_status = str(row.get("Segmented?", "")).strip()
        if seg_status != segmented_flag:
            stats["skip_not_segmented"] += 1
            continue

        try:
            file_num = bids_id_to_int(bids_id)
        except ValueError:
            stats["skip_not_segmented"] += 1
            continue

        nii_path = find_t1w(bids_root, bids_id)
        if nii_path is None:
            stats["skip_no_t1"] += 1
            continue

        nii_proxy = nib.load(nii_path)
        wb_shape = nii_proxy.shape[:3]

        for hemi in ("left", "right"):
            stats["total"] += 1
            if not row_has_valid_coords(row, hemi):
                stats["skip_bad_coord"] += 1
                continue

            mri_tiff, man_tiff = find_tiff_pair(seg_root, file_num, hemi)
            if mri_tiff is None or man_tiff is None:
                stats["skip_no_tiff"] += 1
                continue

            if hemi == "right":
                sag_csv = float(row["R_Sagittal"])
                cor_csv = float(row["R_Coronal"])
                axi_csv = float(row["R_Axial"])
            else:
                sag_csv = float(row["L_Sagittal"])
                cor_csv = float(row["L_Coronal"])
                axi_csv = float(row["L_Axial"])

            center_ras = csv_to_array_index(sag_csv, cor_csv, axi_csv, wb_shape)
            if np.any(center_ras < 0) or np.any(center_ras >= np.array(wb_shape)):
                print(
                    f"  [WARN] {bids_id}_{hemi}: center {center_ras} 超出 WB {wb_shape}, 跳过",
                )
                stats["skip_bad_coord"] += 1
                continue

            try:
                mask_tiff = tifffile.imread(man_tiff).astype(np.float32)
            except Exception as ex:
                print(f"  [WARN] 读取 mask 失败 {man_tiff}: {ex}")
                stats["skip_mask_read"] += 1
                continue

            mask_ras = transform_tiff_mask(mask_tiff)
            mask_embedded = embed_mask_in_crop(mask_ras, crop_size_arr)

            case_id = f"{bids_id}_{hemi}"
            case_dir = os.path.join(out_dir, case_id)
            os.makedirs(case_dir, exist_ok=True)

            np.save(os.path.join(case_dir, "centroid.npy"), center_ras)

            mask_nii = nib.Nifti1Image(mask_embedded.astype(np.uint8), np.eye(4))
            nib.save(mask_nii, os.path.join(case_dir, "mask_aligned.nii.gz"))

            info = {
                "mrn": bids_id,
                "side": hemi,
                "source": "OpenNeuro_TN_Segmentation",
                "nii_path": nii_path,
                "wb_shape": list(wb_shape),
                "nii_ndim": len(nii_proxy.shape),
                "center_csv": [sag_csv, cor_csv, axi_csv],
                "center_ras": center_ras.tolist(),
                "mask_shape_original": list(mask_tiff.shape),
                "mask_shape_embedded": list(mask_embedded.shape),
                "mask_nonzero_pct": float(
                    100 * np.count_nonzero(mask_embedded) / mask_embedded.size,
                ),
                "num_classes": int(mask_embedded.max()) + 1,
                "seg_tiff_manual": man_tiff,
                "seg_tiff_mri_crop": mri_tiff,
            }
            with open(os.path.join(case_dir, "info.json"), "w", encoding="utf-8") as f:
                json.dump(info, f, indent=2)

            all_cases.append({**info, "case_id": case_id})
            stats["success"] += 1
            if stats["success"] % 20 == 0:
                print(f"  [{stats['success']}] {case_id}")

    metadata = {
        "num_cases": stats["success"],
        "crop_size": crop_size,
        "coordinate_system": "RAS",
        "source": "OpenNeuro TN OpenNeuro_Segmentation_Dataset + BIDS T1w",
        "csv_to_ras": "same as prepare_dataset.csv_to_array_index",
        "tiff_transform": "same as prepare_dataset.transform_tiff_mask",
        "stats": stats,
        "case_ids": [c["case_id"] for c in all_cases],
    }
    with open(os.path.join(out_dir, "metadata.json"), "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)

    print(f"\n{'='*60}")
    print("OpenNeuro 数据准备完成")
    print(f"  成功: {stats['success']}")
    print(f"  跳过 Segmented!= {segmented_flag!r}: {stats['skip_not_segmented']}")
    print(f"  跳过 无 T1w: {stats['skip_no_t1']}")
    print(f"  跳过 无 TIFF 对: {stats['skip_no_tiff']}")
    print(f"  跳过 坐标无效/越界: {stats['skip_bad_coord']}")
    print(f"  跳过 mask 读取失败: {stats['skip_mask_read']}")
    print(f"  输出: {out_dir}")
    print(f"{'='*60}")

    return all_cases


def main():
    parser = argparse.ArgumentParser(description="OpenNeuro TN → LocSegNet prepared_data")
    parser.add_argument("--bids_root", type=str, default="${TN_OPENNEURO_DIR}")
    parser.add_argument(
        "--seg_root",
        type=str,
        default="${TN_OPENNEURO_SEG_DIR}",
    )
    parser.add_argument(
        "--out_dir",
        type=str,
        default=os.path.join(_ROOT, "prepared_data_openneuro"),
    )
    parser.add_argument(
        "--cohort_xlsx",
        type=str,
        default=None,
        help="默认 seg_root/Cohort_Data_with_Centroids.xlsx",
    )
    parser.add_argument("--crop_size", type=int, default=64)
    parser.add_argument(
        "--segmented_flag",
        type=str,
        default="Y",
        help="只处理 Segmented? 列等于该值的行 (默认 Y)",
    )
    args = parser.parse_args()

    prepare_openneuro(
        bids_root=args.bids_root,
        seg_root=args.seg_root,
        out_dir=args.out_dir,
        cohort_xlsx=args.cohort_xlsx,
        crop_size=args.crop_size,
        segmented_flag=args.segmented_flag,
    )


if __name__ == "__main__":
    main()
