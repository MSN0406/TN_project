"""
prepare_dataset.py
==================
将原始数据（Whole Brain NIfTI + CSV centroid + TIFF mask）预处理为
统一格式的训练数据:
  - whole brain NIfTI (原始, 保持不变)
  - centroid 坐标 (转换为 RAS 数组索引)
  - mask NIfTI (从 TIFF 转换并对齐到 whole brain 坐标系)

输出目录结构:
  prepared_data/
    ├── metadata.json           # 全局元数据
    ├── {MRN}_{side}/
    │   ├── centroid.npy        # (3,) 数组索引 [sag, cor, axi] in RAS
    │   ├── mask_aligned.nii.gz # 对齐到 WB 坐标系的 mask (48³ → 嵌入到 crop_size³)
    │   └── info.json           # 该 case 的元信息
    └── ...

用法:
    python prepare_dataset.py --config ../configs/default.yaml
    python prepare_dataset.py \\
        --nii_root /path/to/nifti \\
        --crop_root /path/to/crops \\
        --ipsi_csv /path/to/ipsi.csv \\
        --contra_csv /path/to/contra.csv \\
        --out_dir /path/to/prepared_data
"""

import argparse
import json
import os
import sys

import nibabel as nib
import numpy as np
import pandas as pd
import tifffile
import yaml


def csv_to_array_index(sag_csv, cor_csv, axi_csv, wb_shape):
    """
    将 CSV 中的坐标转换为 RAS 数组索引.

    CSV 坐标约定 (来自医学查看器):
        sagittal: L→R (与 RAS axis 0 同向)
        coronal:  A→P (与 RAS axis 1 反向)
        axial:    S→I (与 RAS axis 2 反向)

    NIfTI RAS 数组:
        axis 0: L→R (sagittal)
        axis 1: P→A (coronal)
        axis 2: I→S (axial)
    """
    S0, S1, S2 = wb_shape[:3]
    sag_idx = int(round(sag_csv))
    cor_idx = int(round(S1 - 1 - cor_csv))
    axi_idx = int(round(S2 - 1 - axi_csv))
    return np.array([sag_idx, cor_idx, axi_idx], dtype=np.int64)


def transform_tiff_mask(mask_tiff):
    """
    将 TIFF mask 从存储轴序 (axi_inv, cor_inv, sag_inv) 转换为
    RAS 轴序 (sag, cor, axi).

    TIFF 存储为 (axi, cor, sag), 且三轴方向均与 RAS 相反.
    """
    # transpose: (axi, cor, sag) → (sag, cor, axi)
    mask = np.transpose(mask_tiff, (2, 1, 0))
    # flip: 三轴方向翻转
    mask = np.flip(mask, axis=(0, 1, 2)).copy()
    return mask


def embed_mask_in_crop(mask_ras, crop_size):
    """
    将 mask (如 48³) 居中嵌入到 crop_size³ 的体积中.
    如果 mask 比 crop_size 小, 四周填 0.
    如果 mask 比 crop_size 大, 中心裁剪.
    """
    ms = np.array(mask_ras.shape)
    cs = np.array(crop_size)

    result = np.zeros(crop_size, dtype=mask_ras.dtype)

    # 计算 mask 在 result 中的位置 (居中)
    offset = (cs - ms) // 2

    # 源范围和目标范围
    src_start = np.maximum(0, -offset)
    src_end = np.minimum(ms, cs - offset)
    dst_start = np.maximum(0, offset)
    dst_end = dst_start + (src_end - src_start)

    result[dst_start[0]:dst_end[0],
           dst_start[1]:dst_end[1],
           dst_start[2]:dst_end[2]] = mask_ras[src_start[0]:src_end[0],
                                                src_start[1]:src_end[1],
                                                src_start[2]:src_end[2]]
    return result


def find_mask_file(crop_root, mrn_str, side):
    """查找 mask TIFF 文件."""
    side_map = {"ipsi": "Ipsilateral", "contra": "Contralateral"}
    side_dir = side_map.get(side, side)
    path = os.path.join(crop_root, f"202022_{side_dir}_Target", f"{mrn_str}_mask.tiff")
    if os.path.isfile(path):
        return path
    return None


def find_nii_file(nii_root, mrn_str):
    """查找 NIfTI 文件, 支持带/不带前导零."""
    mrn_nozero = str(int(mrn_str)) if mrn_str.isdigit() else mrn_str

    candidates = [
        os.path.join(nii_root, mrn_str, f"{mrn_str}.nii.gz"),
        os.path.join(nii_root, mrn_nozero, f"{mrn_nozero}.nii.gz"),
    ]
    for p in candidates:
        if os.path.isfile(p):
            return p

    # 模糊匹配
    if os.path.isdir(nii_root):
        for d in os.listdir(nii_root):
            if d.lstrip("0") == mrn_nozero or d == mrn_str:
                candidate = os.path.join(nii_root, d, f"{d}.nii.gz")
                if os.path.isfile(candidate):
                    return candidate
    return None


def prepare_all(nii_root, crop_root, ipsi_csv, contra_csv, out_dir, crop_size=64):
    """预处理所有数据."""
    os.makedirs(out_dir, exist_ok=True)

    ipsi_df = pd.read_csv(ipsi_csv).set_index("MRN")
    contra_df = pd.read_csv(contra_csv).set_index("MRN")
    common_mrn = ipsi_df.index.intersection(contra_df.index)

    crop_size_arr = np.array([crop_size, crop_size, crop_size])

    stats = {"total": 0, "success": 0, "skip_no_nii": 0,
             "skip_no_mask": 0, "skip_bad_coord": 0}
    all_cases = []

    for mrn in common_mrn:
        mrn_str = str(mrn).strip()

        for side, df in [("ipsi", ipsi_df), ("contra", contra_df)]:
            stats["total"] += 1
            row = df.loc[mrn]

            # 检查坐标是否有效
            try:
                sag_csv = float(row["sagittal"])
                cor_csv = float(row["coronal"])
                axi_csv = float(row["axial"])
                if np.isnan(sag_csv) or np.isnan(cor_csv) or np.isnan(axi_csv):
                    raise ValueError("NaN coordinate")
            except (ValueError, TypeError):
                stats["skip_bad_coord"] += 1
                continue

            # 查找 NIfTI
            nii_path = find_nii_file(nii_root, mrn_str)
            if nii_path is None:
                stats["skip_no_nii"] += 1
                continue
            # 用实际找到的 MRN (可能有前导零)
            actual_mrn = os.path.basename(os.path.dirname(nii_path))

            # 查找 mask
            mask_path = find_mask_file(crop_root, actual_mrn, side)
            if mask_path is None:
                # 尝试不带前导零的版本
                mask_path = find_mask_file(crop_root, mrn_str, side)
            if mask_path is None:
                stats["skip_no_mask"] += 1
                continue

            # 加载 NIfTI header 获取 shape (不需要加载全部数据)
            nii_proxy = nib.load(nii_path)
            wb_shape = nii_proxy.shape[:3]  # 取前 3 维 (有些病例是 4D)

            # 坐标转换
            center_ras = csv_to_array_index(sag_csv, cor_csv, axi_csv, wb_shape)

            # 检查坐标是否在有效范围内
            if np.any(center_ras < 0) or np.any(center_ras >= np.array(wb_shape)):
                print(f"  [WARN] {actual_mrn}_{side}: center {center_ras} 超出范围 {wb_shape}, 跳过")
                stats["skip_bad_coord"] += 1
                continue

            # 加载并转换 mask
            mask_tiff = tifffile.imread(mask_path).astype(np.float32)
            mask_ras = transform_tiff_mask(mask_tiff)

            # 嵌入到 crop_size 大小
            mask_embedded = embed_mask_in_crop(mask_ras, crop_size_arr)

            # 保存
            case_id = f"{actual_mrn}_{side}"
            case_dir = os.path.join(out_dir, case_id)
            os.makedirs(case_dir, exist_ok=True)

            # 保存 centroid
            np.save(os.path.join(case_dir, "centroid.npy"), center_ras)

            # 保存 mask 为 NIfTI (使用单位 affine, 后续训练时直接用数组)
            mask_nii = nib.Nifti1Image(mask_embedded.astype(np.uint8), np.eye(4))
            nib.save(mask_nii, os.path.join(case_dir, "mask_aligned.nii.gz"))

            # 保存 info
            info = {
                "mrn": actual_mrn,
                "side": side,
                "nii_path": nii_path,
                "wb_shape": list(wb_shape),
                "nii_ndim": len(nii_proxy.shape),  # 原始维度数 (3 或 4)
                "center_csv": [sag_csv, cor_csv, axi_csv],
                "center_ras": center_ras.tolist(),
                "mask_shape_original": list(mask_tiff.shape),
                "mask_shape_embedded": list(mask_embedded.shape),
                "mask_nonzero_pct": float(100 * np.count_nonzero(mask_embedded)
                                          / mask_embedded.size),
                "num_classes": int(mask_embedded.max()) + 1,
            }
            with open(os.path.join(case_dir, "info.json"), "w") as f:
                json.dump(info, f, indent=2)

            all_cases.append(info)
            stats["success"] += 1

            if stats["success"] % 20 == 0:
                print(f"  [{stats['success']}] Processed {case_id}")

    # 保存全局元数据
    metadata = {
        "num_cases": stats["success"],
        "crop_size": crop_size,
        "coordinate_system": "RAS",
        "axis_mapping": {
            "axis_0": "L→R (sagittal)",
            "axis_1": "P→A (coronal)",
            "axis_2": "I→S (axial)",
        },
        "csv_to_ras": {
            "sagittal": "same direction",
            "coronal": "flipped (A→P → P→A)",
            "axial": "flipped (S→I → I→S)",
        },
        "tiff_transform": "transpose(2,1,0) + flip_all",
        "stats": stats,
        "case_ids": [c["mrn"] + "_" + c["side"] for c in all_cases],
    }
    with open(os.path.join(out_dir, "metadata.json"), "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"\n{'='*60}")
    print(f"数据准备完成:")
    print(f"  成功: {stats['success']}")
    print(f"  跳过 (无 NIfTI): {stats['skip_no_nii']}")
    print(f"  跳过 (无 mask): {stats['skip_no_mask']}")
    print(f"  跳过 (坐标无效): {stats['skip_bad_coord']}")
    print(f"  输出目录: {out_dir}")
    print(f"{'='*60}")

    return all_cases


def main():
    parser = argparse.ArgumentParser(description="准备 LocSegNet 训练数据")
    parser.add_argument("--config", type=str, help="YAML 配置文件路径")
    parser.add_argument("--nii_root", type=str)
    parser.add_argument("--crop_root", type=str)
    parser.add_argument("--ipsi_csv", type=str)
    parser.add_argument("--contra_csv", type=str)
    parser.add_argument("--out_dir", type=str)
    parser.add_argument("--crop_size", type=int, default=64)
    args = parser.parse_args()

    if args.config:
        with open(args.config) as f:
            cfg = yaml.safe_load(f)
        nii_root = args.nii_root or cfg["data"]["nii_root"]
        crop_root = args.crop_root or cfg["data"]["crop_root"]
        ipsi_csv = args.ipsi_csv or cfg["data"]["ipsi_csv"]
        contra_csv = args.contra_csv or cfg["data"]["contra_csv"]
        out_dir = args.out_dir or cfg["data"]["prepared_dir"]
        crop_size = args.crop_size or cfg["segmentation"]["crop_size"][0]
    else:
        nii_root = args.nii_root
        crop_root = args.crop_root
        ipsi_csv = args.ipsi_csv
        contra_csv = args.contra_csv
        out_dir = args.out_dir
        crop_size = args.crop_size

    prepare_all(nii_root, crop_root, ipsi_csv, contra_csv, out_dir, crop_size)


if __name__ == "__main__":
    main()
