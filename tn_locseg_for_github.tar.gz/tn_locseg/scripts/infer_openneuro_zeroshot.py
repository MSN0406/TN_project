"""
infer_openneuro_zeroshot.py
===========================
拿当前 inhouse 训练的 ckpt, 直接在 OpenNeuro 80 个 sub-* 上 zero-shot 推理.

OpenNeuro 数据**没有**进 nnUNet preprocessing, 只在 prepared_data/sub-*/ 下.
- image: 从 info.json["nii_path"] 读
- GT: 用 prepared_data/sub-*/mask_aligned.nii.gz (与 nnUNet gt_segmentations 同格式: 64³, 1mm)

策略: monkey-patch trainer 的 _case_mapping 和 _load_gt_seg_resized_to_wb,
让 sub-* key 走 OpenNeuro 路径 (从 prepared_data 读 mask_aligned), 其它沿用院内逻辑.

输出:
  <output_dir>/<sub-X_side>_image.nii.gz
  <output_dir>/<sub-X_side>_gt.nii.gz
  <output_dir>/<sub-X_side>_pred.nii.gz
  <output_dir>/dice.csv
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import os, sys, json, argparse, shutil
import numpy as np
import torch
import torch.nn.functional as F
import nibabel as nib

sys.path.insert(0, REPO_ROOT)


def project_patch(patch, ps, ctr, resamp_shape, native_shape):
    full = np.zeros(tuple(resamp_shape), dtype=patch.dtype)
    half = [s // 2 for s in ps]
    lo, hi, sl, sh = [], [], [], []
    for d in range(3):
        c = int(ctr[d]); lo_f = c - half[d]; hi_f = lo_f + ps[d]
        lo_c = max(0, lo_f); hi_c = min(int(resamp_shape[d]), hi_f)
        if hi_c <= lo_c: return np.zeros(native_shape, dtype=patch.dtype)
        lo.append(lo_c); hi.append(hi_c); sl.append(lo_c - lo_f); sh.append(sl[-1] + (hi_c - lo_c))
    full[lo[0]:hi[0], lo[1]:hi[1], lo[2]:hi[2]] = patch[sl[0]:sh[0], sl[1]:sh[1], sl[2]:sh[2]]
    if tuple(int(x) for x in resamp_shape) == tuple(int(x) for x in native_shape): return full
    t = torch.from_numpy(full.astype(np.float32)).view(1, 1, *resamp_shape)
    out = F.interpolate(t, size=tuple(int(x) for x in native_shape), mode='nearest')[0, 0].numpy()
    return np.round(out).astype(patch.dtype)


def gt_to_native_from_mask_aligned(prep_name, native_shape, spacing_prep, prepared_dir):
    """OpenNeuro: 直接读 mask_aligned.nii.gz (64³ 1mm), embed 到 native shape."""
    mask_nii = nib.load(os.path.join(prepared_dir, prep_name, 'mask_aligned.nii.gz'))
    mask = np.rint(mask_nii.get_fdata()).astype(np.int64)
    spacing_mask = np.array(mask_nii.header.get_zooms()[:3], dtype=np.float64)
    target_shape = np.maximum(1, np.round(np.array(mask.shape) * spacing_mask / spacing_prep).astype(int))
    mask_t = torch.from_numpy(mask.astype(np.float32)).view(1, 1, *mask.shape)
    mask_t = F.interpolate(mask_t, size=tuple(int(x) for x in target_shape), mode='nearest')
    mask_resamp = torch.round(mask_t[0, 0]).long().numpy()
    centroid = np.load(os.path.join(prepared_dir, prep_name, 'centroid.npy')).astype(np.float64)
    center = np.round(centroid).astype(int); half = target_shape // 2
    full = np.zeros(native_shape, dtype=np.uint8)
    def emb(c, h, t, dim):
        lf=c-h; hf=lf+t; lc=max(0,int(lf)); hc=min(int(dim),int(hf))
        if hc<=lc: return None,None
        sl=lc-int(lf); sh=sl+(hc-lc)
        return slice(lc,hc), slice(sl,sh)
    s = [emb(center[i], half[i], target_shape[i], native_shape[i]) for i in range(3)]
    if any(x[0] is None for x in s): return full
    full[s[0][0], s[1][0], s[2][0]] = np.clip(mask_resamp[s[0][1], s[1][1], s[2][1]], 0, 255).astype(np.uint8)
    return full


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--output_dir', required=True)
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--cases', nargs='+', default=None, help='指定 prepared_data sub-* 名; 默认全部 80 个')
    ap.add_argument('--save_nii', action='store_true', help='也保存 image+gt+pred NIfTI (默认只算 dice)')
    ap.add_argument('--use_gt_centroid', action='store_true')
    args = ap.parse_args()

    os.environ.setdefault('nnUNet_raw', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_raw'))
    os.environ.setdefault('nnUNet_preprocessed', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_preprocessed'))
    os.environ.setdefault('TN_PREPARED_DATA_DIR', os.path.join(REPO_ROOT, 'prepared_data'))
    os.environ.update({
        'TN_WB_TARGET_SPACING': '1,1,1', 'TN_WB_USE_PLANS_FG_NORM': '0',
        'TN_WB_NORM_CLIP': '0', 'TN_WB_CROP_PADDING': 'border',
        'TN_PHASE3_VAL_USE_GT_CROP': '1', 'TN_VESSEL_LOSS_WEIGHT': '0',
        'TN_SEG_DROPOUT_P': '0', 'TN_PHASE3_SEG_AUG': '0',
        'TN_PHASE1_EPOCHS': '0', 'TN_PHASE2_EPOCHS': '0', 'TN_PHASE3_EPOCHS': '1000',
        'TN_NUM_ITERS_PER_EPOCH_PHASE3': '200', 'TN_NUM_VAL_ITERS_PER_EPOCH_PHASE3': '30',
        'TN_INNER_DICE_ENABLE': '0', 'TN_OVERSAMPLE_FOREGROUND_PERCENT': '0.85',
    })

    from nnunetv2.utilities.dataset_name_id_conversion import maybe_convert_to_dataset_name
    from batchgenerators.utilities.file_and_folder_operations import join, load_json
    from nnunetv2.paths import nnUNet_preprocessed
    from nnunet_loc_trainer import nnUNetTrainerLoc

    plans = load_json(join(nnUNet_preprocessed, 'Dataset001_TN', 'nnUNetPlans.json'))
    dataset_json = load_json(join(nnUNet_preprocessed, 'Dataset001_TN', 'dataset.json'))
    plans['configurations']['3d_fullres']['patch_size'] = [96, 96, 96]
    plans['configurations']['3d_fullres']['batch_size'] = 4
    device = torch.device('cuda', args.gpu)
    trainer = nnUNetTrainerLoc(plans=plans, configuration='3d_fullres', fold=0, dataset_json=dataset_json, device=device)
    trainer.initialize()
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    trainer.network.load_state_dict(ckpt['network_weights'])
    trainer.network.eval()
    print(f'[infer] ckpt epoch={ckpt.get("current_epoch")}')

    # === Monkey-patch: 给 trainer 加 OpenNeuro 的 case_mapping (key=prepared_name, identity) ===
    prepared_dir = os.environ['TN_PREPARED_DATA_DIR']
    sub_names = sorted([d for d in os.listdir(prepared_dir) if d.startswith('sub-')])
    print(f'[infer] OpenNeuro 共 {len(sub_names)} 个 case')
    for sn in sub_names:
        trainer._case_mapping[sn] = sn  # nnunet_key == prepared_name (identity)

    # === Monkey-patch GT 加载: sub-* 直接读 mask_aligned.nii.gz, 其它走原逻辑 ===
    orig_load_gt = trainer._load_gt_seg_resized_to_wb
    def patched_load_gt(nnunet_key, wb_shape_dhw):
        if nnunet_key.startswith('sub-'):
            # OpenNeuro: 用 mask_aligned.nii.gz 顶替 nnUNet gt_segmentations
            prep_dir = os.path.join(prepared_dir, nnunet_key)
            mask_nii = nib.load(os.path.join(prep_dir, 'mask_aligned.nii.gz'))
            mask = np.rint(mask_nii.get_fdata()).astype(np.int64)
            spacing_mask = np.array(mask_nii.header.get_zooms()[:3], dtype=np.float64)
            info = json.load(open(os.path.join(prep_dir, 'info.json')))
            wb_nii = nib.load(info['nii_path'])
            spacing_prep = np.array(wb_nii.header.get_zooms()[:3], dtype=np.float64)
            native_shape = tuple(int(x) for x in wb_nii.shape[:3])
            target_shape = np.maximum(1, np.round(np.array(mask.shape) * spacing_mask / spacing_prep).astype(int))
            mt = torch.from_numpy(mask.astype(np.float32)).view(1, 1, *mask.shape)
            mt = F.interpolate(mt, size=tuple(int(x) for x in target_shape), mode='nearest')
            mask_resamp = torch.round(mt[0, 0]).long().numpy()
            centroid = np.load(os.path.join(prep_dir, 'centroid.npy')).astype(np.float64)
            center = np.round(centroid).astype(int); half = target_shape // 2
            full_native = np.zeros(native_shape, dtype=np.int64)
            def emb(c, h, t, dim):
                lf=c-h; hf=lf+t; lc=max(0,int(lf)); hc=min(int(dim),int(hf))
                if hc<=lc: return None,None
                sl=lc-int(lf); sh=sl+(hc-lc)
                return slice(lc,hc), slice(sl,sh)
            s = [emb(center[i], half[i], target_shape[i], native_shape[i]) for i in range(3)]
            if any(x[0] is None for x in s):
                pass
            else:
                full_native[s[0][0], s[1][0], s[2][0]] = mask_resamp[s[0][1], s[1][1], s[2][1]]
            # Resample to wb_shape_dhw (after wb_target_spacing)
            if native_shape != tuple(int(x) for x in wb_shape_dhw):
                ft = torch.from_numpy(full_native.astype(np.float32)).view(1, 1, *native_shape)
                ft = F.interpolate(ft, size=tuple(int(x) for x in wb_shape_dhw), mode='nearest')
                full = torch.round(ft[0, 0]).long().numpy()
            else:
                full = full_native
            return np.clip(full, 0, 2).astype(np.int64)
        else:
            return orig_load_gt(nnunet_key, wb_shape_dhw)
    trainer._load_gt_seg_resized_to_wb = patched_load_gt

    # === 跑推理 ===
    cases = args.cases if args.cases else sub_names
    os.makedirs(args.output_dir, exist_ok=True)
    mod = trainer.network.module if hasattr(trainer.network, 'module') else trainer.network
    if hasattr(mod, '_orig_mod'): mod = mod._orig_mod

    rows = ['case,fg1_dice,fg2_dice,min_dice,fg1_tp,fg1_fp,fg1_fn,fg2_tp,fg2_fp,fg2_fn,gt_fg1,gt_fg2,loc_err_vox']
    for ci, case in enumerate(cases):
        try:
            with torch.no_grad():
                wb_tensor, wb_shapes, gt_centroid_norm = trainer._build_whole_brain_batch([case])
                wb_tensor = wb_tensor.to(device); gt_centroid_norm = gt_centroid_norm.to(device)
                hm_l, hm_r, c_l, c_r = trainer._loc_forward(wb_tensor, mod)
                pred_centroid = trainer._select_centroid_by_gt_side(c_l, c_r, gt_centroid_norm,
                    wb_shapes=wb_shapes, padded_shape=wb_tensor.shape[2:])
                centroid = gt_centroid_norm if args.use_gt_centroid else pred_centroid
                centroid = trainer._round_centroid_to_voxel(centroid, wb_tensor.shape[2:])
                seg_input = trainer._crop_with_centroid(wb_tensor, centroid, (96, 96, 96))
                logits = mod.forward_seg(seg_input)
                if isinstance(logits, (list, tuple)): logits = logits[0]
                pred_patch = logits.argmax(dim=1)[0].cpu().numpy().astype(np.uint8)
                scale = (torch.tensor(wb_tensor.shape[2:], device=device) - 1).float()
                crop_vox = (centroid * scale).cpu().numpy()[0]
                gt_vox = (gt_centroid_norm * scale).cpu().numpy()[0]
                pr_vox = (pred_centroid * scale).cpu().numpy()[0]
                loc_err = float(np.linalg.norm(gt_vox - pr_vox))
                resamp_shape = tuple(int(x) for x in wb_tensor.shape[2:])

            info = json.load(open(os.path.join(prepared_dir, case, 'info.json')))
            img_nii = nib.load(info['nii_path'])
            native_shape = tuple(int(x) for x in img_nii.shape[:3])
            spacing_prep = np.array(img_nii.header.get_zooms()[:3], dtype=np.float64)
            pred_native = project_patch(pred_patch, (96, 96, 96), crop_vox, resamp_shape, native_shape)
            gt_native = gt_to_native_from_mask_aligned(case, native_shape, spacing_prep, prepared_dir)

            fg1_g = (gt_native == 1); fg1_p = (pred_native == 1)
            fg1_tp = int((fg1_g & fg1_p).sum()); fg1_fp = int((fg1_p & ~fg1_g).sum()); fg1_fn = int((fg1_g & ~fg1_p).sum())
            fg1_d = 2*fg1_tp / max(1, 2*fg1_tp + fg1_fp + fg1_fn)
            fg2_g = (gt_native == 2); fg2_p = (pred_native == 2)
            fg2_tp = int((fg2_g & fg2_p).sum()); fg2_fp = int((fg2_p & ~fg2_g).sum()); fg2_fn = int((fg2_g & ~fg2_p).sum())
            fg2_d = 2*fg2_tp / max(1, 2*fg2_tp + fg2_fp + fg2_fn)
            min_d = min(fg1_d, fg2_d)
            rows.append(f'{case},{fg1_d:.4f},{fg2_d:.4f},{min_d:.4f},{fg1_tp},{fg1_fp},{fg1_fn},{fg2_tp},{fg2_fp},{fg2_fn},{int(fg1_g.sum())},{int(fg2_g.sum())},{loc_err:.2f}')
            print(f'[{ci+1:3d}/{len(cases)}] {case}: FG1={fg1_d:.3f} FG2={fg2_d:.3f} min={min_d:.3f} loc_err={loc_err:.2f}')

            if args.save_nii:
                nib.save(nib.Nifti1Image(img_nii.get_fdata().astype(np.float32), img_nii.affine, img_nii.header),
                         os.path.join(args.output_dir, f'{case}_image.nii.gz'))
                nib.save(nib.Nifti1Image(gt_native, img_nii.affine, img_nii.header),
                         os.path.join(args.output_dir, f'{case}_gt.nii.gz'))
                nib.save(nib.Nifti1Image(pred_native, img_nii.affine, img_nii.header),
                         os.path.join(args.output_dir, f'{case}_pred.nii.gz'))
        except Exception as e:
            print(f'[{ci+1}] {case} FAILED: {e}')
            rows.append(f'{case},FAIL,FAIL,FAIL,,,,,,,,,')

    csv_path = os.path.join(args.output_dir, 'dice.csv')
    with open(csv_path, 'w') as f: f.write('\n'.join(rows))
    print(f'\n=== aggregate ===')
    fg1 = [float(r.split(',')[1]) for r in rows[1:] if r.split(',')[1] != 'FAIL']
    fg2 = [float(r.split(',')[2]) for r in rows[1:] if r.split(',')[2] != 'FAIL']
    if fg1:
        print(f'FG1 (nerve):  mean={np.mean(fg1):.4f}, median={np.median(fg1):.4f}, std={np.std(fg1):.4f}, min={np.min(fg1):.3f}, max={np.max(fg1):.3f}, n={len(fg1)}')
        print(f'FG2 (vessel): mean={np.mean(fg2):.4f}, median={np.median(fg2):.4f}, std={np.std(fg2):.4f}, min={np.min(fg2):.3f}, max={np.max(fg2):.3f}, n={len(fg2)}')
    print(f'csv: {csv_path}')


if __name__ == '__main__':
    main()
