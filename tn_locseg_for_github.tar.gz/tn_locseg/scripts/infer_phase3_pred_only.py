"""
infer_phase3_pred_only.py
=========================
轻量推理: 只输出预测的 label NIfTI, 用 prepared_data 的 MRN_side 命名.

每个 case 输出 1 个文件: <output_dir>/<MRN_side>_best.nii.gz
  - 与原始 prepared_data NIfTI 同 affine / 同 spacing / 同 shape
  - voxel 值: 0=背景, 1=nerve, 2=vessel (实心 label, 不是 contour)
  - 直接在 ITK-SNAP / 3D Slicer 里 overlay 到 prepared_data 全脑就行
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import argparse, os, sys, json
import numpy as np
import torch
import torch.nn.functional as F
import nibabel as nib

sys.path.insert(0, REPO_ROOT)


def project_patch_to_native(patch_np, patch_size, center_vox_in_resamp, resamp_shape, native_shape):
    full_resamp = np.zeros(tuple(resamp_shape), dtype=patch_np.dtype)
    half = [s // 2 for s in patch_size]
    lo, hi, src_lo, src_hi = [], [], [], []
    for d in range(3):
        c = int(center_vox_in_resamp[d])
        lo_full = c - half[d]; hi_full = lo_full + patch_size[d]
        lo_clip = max(0, lo_full); hi_clip = min(int(resamp_shape[d]), hi_full)
        if hi_clip <= lo_clip:
            return np.zeros(native_shape, dtype=patch_np.dtype)
        lo.append(lo_clip); hi.append(hi_clip)
        src_lo.append(lo_clip - lo_full); src_hi.append(src_lo[-1] + (hi_clip - lo_clip))
    full_resamp[lo[0]:hi[0], lo[1]:hi[1], lo[2]:hi[2]] = \
        patch_np[src_lo[0]:src_hi[0], src_lo[1]:src_hi[1], src_lo[2]:src_hi[2]]

    if tuple(int(x) for x in resamp_shape) == tuple(int(x) for x in native_shape):
        return full_resamp
    t = torch.from_numpy(full_resamp.astype(np.float32)).view(1, 1, *resamp_shape)
    out = F.interpolate(t, size=tuple(int(x) for x in native_shape), mode='nearest')[0, 0].numpy()
    return np.round(out).astype(patch_np.dtype)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--cases', nargs='+', default=None)
    ap.add_argument('--n', type=int, default=8)
    ap.add_argument('--all_val', action='store_true', help='跑全部 76 个 val case')
    ap.add_argument('--output_dir', required=True)
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--use_gt_centroid', action='store_true')
    ap.add_argument('--suffix', default='_best', help='文件名后缀, 默认 _best -> <MRN_side>_best.nii.gz')
    args = ap.parse_args()

    os.environ.setdefault('nnUNet_raw', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_raw'))
    os.environ.setdefault('nnUNet_preprocessed', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_preprocessed'))
    os.environ.setdefault('TN_PREPARED_DATA_DIR', os.path.join(REPO_ROOT, 'prepared_data'))
    os.environ['TN_WB_TARGET_SPACING'] = '1,1,1'
    os.environ['TN_WB_USE_PLANS_FG_NORM'] = '0'
    os.environ['TN_WB_NORM_CLIP'] = '0'
    os.environ['TN_WB_CROP_PADDING'] = 'border'
    os.environ['TN_PHASE3_VAL_USE_GT_CROP'] = '1'
    os.environ['TN_VESSEL_LOSS_WEIGHT'] = '0'
    os.environ['TN_SEG_DROPOUT_P'] = '0'
    os.environ['TN_PHASE3_SEG_AUG'] = '0'
    os.environ['TN_PHASE1_EPOCHS'] = '0'
    os.environ['TN_PHASE2_EPOCHS'] = '0'
    os.environ['TN_PHASE3_EPOCHS'] = '1000'
    os.environ['TN_NUM_ITERS_PER_EPOCH_PHASE3'] = '200'
    os.environ['TN_NUM_VAL_ITERS_PER_EPOCH_PHASE3'] = '30'
    os.environ['TN_INNER_DICE_ENABLE'] = '0'
    os.environ['TN_OVERSAMPLE_FOREGROUND_PERCENT'] = '0.85'

    from nnunetv2.utilities.dataset_name_id_conversion import maybe_convert_to_dataset_name
    from batchgenerators.utilities.file_and_folder_operations import join, load_json
    from nnunetv2.paths import nnUNet_preprocessed
    from nnunet_loc_trainer import nnUNetTrainerLoc

    dataset_name = maybe_convert_to_dataset_name('Dataset001_TN')
    plans = load_json(join(nnUNet_preprocessed, dataset_name, 'nnUNetPlans.json'))
    dataset_json = load_json(join(nnUNet_preprocessed, dataset_name, 'dataset.json'))
    plans['configurations']['3d_fullres']['patch_size'] = [96, 96, 96]
    plans['configurations']['3d_fullres']['batch_size'] = 4

    device = torch.device('cuda', args.gpu) if torch.cuda.is_available() else torch.device('cpu')
    trainer = nnUNetTrainerLoc(plans=plans, configuration='3d_fullres', fold=0,
                               dataset_json=dataset_json, device=device)
    trainer.initialize()
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    trainer.network.load_state_dict(ckpt['network_weights'])
    trainer.network.eval()
    print(f'[infer] loaded ckpt epoch={ckpt.get("current_epoch")}, use_gt_centroid={args.use_gt_centroid}')

    splits = load_json(join(nnUNet_preprocessed, dataset_name, 'splits_final.json'))
    val_keys = splits[0]['val']
    if args.cases:
        cases = args.cases
    elif args.all_val:
        cases = list(val_keys)
    else:
        cases = list(val_keys[:args.n])
    print(f'[infer] cases ({len(cases)})')

    case_mapping = json.load(open(join(os.environ['nnUNet_raw'], 'Dataset001_TN', 'case_mapping.json')))
    prepared_dir = os.environ['TN_PREPARED_DATA_DIR']

    os.makedirs(args.output_dir, exist_ok=True)
    summary = []
    mod = trainer.network.module if hasattr(trainer.network, 'module') else trainer.network
    if hasattr(mod, '_orig_mod'): mod = mod._orig_mod

    for ci, case in enumerate(cases):
        prep_name = case_mapping[case]
        out_path = join(args.output_dir, f'{prep_name}{args.suffix}.nii.gz')
        try:
            with torch.no_grad():
                wb_tensor, wb_shapes, gt_centroid_norm = trainer._build_whole_brain_batch([case])
                wb_tensor = wb_tensor.to(device)
                gt_centroid_norm = gt_centroid_norm.to(device)
                hm_l, hm_r, c_l, c_r = trainer._loc_forward(wb_tensor, mod)
                pred_centroid = trainer._select_centroid_by_gt_side(
                    c_l, c_r, gt_centroid_norm, wb_shapes=wb_shapes, padded_shape=wb_tensor.shape[2:]
                )
                centroid = gt_centroid_norm if args.use_gt_centroid else pred_centroid
                centroid = trainer._round_centroid_to_voxel(centroid, wb_tensor.shape[2:])
                seg_input = trainer._crop_with_centroid(wb_tensor, centroid, (96, 96, 96))
                logits = mod.forward_seg(seg_input)
                if isinstance(logits, (list, tuple)): logits = logits[0]
                pred_patch = logits.argmax(dim=1)[0].cpu().numpy().astype(np.uint8)
                scale = (torch.tensor(wb_tensor.shape[2:], device=device) - 1).float()
                crop_vox = (centroid * scale).cpu().numpy()[0]
                resamp_shape = tuple(int(x) for x in wb_tensor.shape[2:])

            info = json.load(open(join(prepared_dir, prep_name, 'info.json')))
            img_nii = nib.load(info['nii_path'])
            native_shape = tuple(int(x) for x in img_nii.shape[:3])
            pred_native = project_patch_to_native(pred_patch, (96, 96, 96), crop_vox, resamp_shape, native_shape)
            nib.save(nib.Nifti1Image(pred_native, img_nii.affine, img_nii.header), out_path)
            n1 = int((pred_native == 1).sum()); n2 = int((pred_native == 2).sum())
            line = f'[{ci+1}/{len(cases)}] {case} ({prep_name}): nerve={n1} vessel={n2}  -> {out_path}'
            print(line)
            summary.append(line)
        except Exception as e:
            line = f'[{ci+1}/{len(cases)}] {case} FAILED: {e}'
            print(line); summary.append(line)

    with open(join(args.output_dir, 'summary.txt'), 'w') as f:
        f.write('\n'.join(summary))
    print(f'\n输出目录: {args.output_dir}/')


if __name__ == '__main__':
    main()
