"""Render fig_seg_dice.png from regen_*/val_dice_per_case.csv."""
import os, argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--in_csv', required=True)
    ap.add_argument('--out_png', required=True)
    ap.add_argument('--ckpt_tag', default='locaug e555')
    args = ap.parse_args()

    df = pd.read_csv(args.in_csv)
    df = df[df['fg1_dice'] != 'FAIL'].copy()
    df['fg1_dice'] = df['fg1_dice'].astype(float)
    df['fg2_dice'] = df['fg2_dice'].astype(float)
    df['loc_err_mm'] = df['loc_err_mm'].astype(float)
    n = len(df)
    n1 = df['fg1_dice'].mean(); m1 = df['fg1_dice'].median()
    n2 = df['fg2_dice'].mean(); m2 = df['fg2_dice'].median()
    le = df['loc_err_mm'].mean()

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    bins_n = np.linspace(0, max(0.82, df['fg1_dice'].max()*1.05), 24)
    axes[0].hist(df['fg1_dice'], bins=bins_n, color='#c0504d', edgecolor='white')
    axes[0].axvline(n1, color='navy', linestyle='--', linewidth=2, label=f'Mean: {n1:.4f}')
    axes[0].axvline(m1, color='darkorange', linestyle='--', linewidth=2, label=f'Median: {m1:.4f}')
    axes[0].set_xlabel('Dice (nerve)'); axes[0].set_ylabel('Count')
    axes[0].set_title('Nerve Dice (per-case, native space)')
    axes[0].legend(fontsize=10); axes[0].grid(alpha=0.3)

    bins_v = np.linspace(0, max(0.32, df['fg2_dice'].max()*1.05), 24)
    axes[1].hist(df['fg2_dice'], bins=bins_v, color='#4f81bd', edgecolor='white')
    axes[1].axvline(n2, color='navy', linestyle='--', linewidth=2, label=f'Mean: {n2:.4f}')
    axes[1].axvline(m2, color='darkorange', linestyle='--', linewidth=2, label=f'Median: {m2:.4f}')
    axes[1].set_xlabel('Dice (vessel)'); axes[1].set_ylabel('Count')
    axes[1].set_title('Vessel Dice (per-case, native space)')
    axes[1].legend(fontsize=10); axes[1].grid(alpha=0.3)

    fig.suptitle(f'Segmentation Metrics — {args.ckpt_tag}  |  n={n} val cases\n'
                 f'Mean Dice Nerve: {n1:.4f}    Mean Dice Vessel: {n2:.4f}    Mean Loc err: {le:.2f} mm',
                 fontsize=13, fontweight='bold')
    plt.tight_layout(rect=[0, 0, 1, 0.93])
    fig.savefig(args.out_png, dpi=140, bbox_inches='tight')
    print(f'[saved] {args.out_png}')


if __name__ == '__main__':
    main()
