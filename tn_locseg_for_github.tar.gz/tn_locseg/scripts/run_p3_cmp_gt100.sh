#!/usr/bin/env bash
# Phase3 可比实验：训练裁剪质心 100% GT（phase3_min_gt_mix=1）
# 输出目录独立，避免与其它实验抢占 checkpoint

set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_p3_cmp_gt100_20260502"

PRETRAINED="${ROOT}/nnUNet_data/nnUNet_results_p3_patch96_aug_20260430_165940/Dataset001_TN/nnUNetTrainerLoc__nnUNetPlans__3d_fullres/fold_0/phase3_best.pth"

export TN_WB_TARGET_SPACING=1,1,1
export TN_WB_USE_PLANS_FG_NORM=1
export TN_PHASE3_VAL_USE_GT_CROP=1
export TN_PHASE3_VESSEL_OVERSAMPLE_PROB=0.35
export TN_VESSEL_LOSS_WEIGHT=0.75
export TN_OVERSAMPLE_FOREGROUND_PERCENT=0.55
export TN_SEG_DROPOUT_P=0.15

LOG_DIR="${nnUNet_results}"
mkdir -p "$LOG_DIR"
LOG="${LOG_DIR}/train_gt100_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

"${PYTHON:-python}" train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --pretrained_weights "$PRETRAINED" \
  --loc_arch attn \
  --seg_patch_size 96 96 96 \
  --seg_bs 4 \
  --phase1_epochs 0 \
  --phase2_epochs 0 \
  --phase3_epochs 1000 \
  --phase3_warmup_epochs 200 \
  --num_iters_phase3 200 \
  --num_val_iters_phase3 30 \
  --val_interval 5 \
  --disable_inner_dice \
  --smooth_sigma 0 \
  --loc_loss_weight 0.2 \
  --loc_phase3_lr 5e-4 \
  --loc_phase3_lr_schedule cosine \
  --loc_phase3_lr_min_ratio 0.1 \
  --phase3_min_gt_mix 1.0 \
  --phase3_fg_aux_weight 0.0 \
  2>&1 | tee "$LOG"

echo "[done] log: $LOG"
