#!/usr/bin/env bash
# OpenNeuro fine-tune on T2w, init from locaug ckpt (Step 2 of the ablation)
# 起点: mix0604_locaug epoch 70 (inhouse + loc aug 训出来的)
# vs   v3 ckpt fine-tune 起点 (peak 0.37) — 看 aug-trained 起点是否突破
set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"
export TN_PREPARED_DATA_DIR="$ROOT/prepared_data_openneuro_t2w"

OUT="$ROOT/nnUNet_data/nnUNet_results_openneuro_finetune_t2w_from_locaug_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT"

"${PYTHON:-python}" \
  $ROOT/scripts/finetune_openneuro.py \
  --init_ckpt $ROOT/nnUNet_data/viz_snapshots/mix0604_locaug_phase3_best_e70.pth \
  --split_json $ROOT/nnUNet_data/openneuro_finetune_split.json \
  --output_dir "$OUT" \
  --gpu 0 \
  --epochs 100 \
  --iters_per_epoch 64 \
  --seg_lr 5e-4 \
  --loc_lr 1e-4 \
  --bs 4 \
  --val_interval 2 \
  2>&1 | tee "$OUT/run.log"
echo "[done] log: $OUT/run.log"
