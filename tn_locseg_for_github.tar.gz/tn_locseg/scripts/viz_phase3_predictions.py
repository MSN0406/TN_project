"""
viz_phase3_predictions.py
=========================
Load a phase3 ckpt, forward on val cases, dump visualization PNG (3 orthogonal slices
through GT centroid: image / GT overlay / pred overlay) + per-case dice metrics.

Output: <output_dir>/<case>.png  (one figure per case)
        <output_dir>/summary.txt (per-case dice + overall stats)
"""
import argparse, os, sys, json
import numpy as np
import torch
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap

sys.path.insert(0, '/home/jzhou169/tn_locseg')


def overlay_label(ax, img_slice, label_slice, title, overlays=(('FG1', 1, 'red'), ('FG2', 2, 'cyan'))):
    """Show grayscale image with colored label overlay."""
    ax.imshow(img_slice.T, cmap='gray', origin='lower')
    for name, cls_id, color in overlays:
        mask = (label_slice == cls_id).T
        if mask.any():
            ax.contour(mask, levels=[0.5], colors=[color], linewidths=0.8, alpha=0.85)
    ax.set_title(title, fontsize=9)
    ax.set_xticks([])
    ax.set_yticks([])


def forward_one_case(trainer, case_key, device):
    mod = trainer.network.module if hasattr(trainer.network, 'module') else trainer.network
    if hasattr(mod, '_orig_mod'):
        mod = mod._orig_mod

    with torch.no_grad():
        wb_tensor, wb_shapes, gt_centroid_norm = trainer._build_whole_brain_batch([case_key])
        wb_tensor = wb_tensor.to(device)
        gt_centroid_norm = gt_centroid_norm.to(device)
        # Use loc-pred centroid? for honest eval, we run loc forward and use pred centroid (deployment mode).
        hm_l, hm_r, c_l, c_r = trainer._loc_forward(wb_tensor, mod)
        pred_centroid = trainer._select_centroid_by_gt_side(
            c_l, c_r, gt_centroid_norm, wb_shapes=wb_shapes, padded_shape=wb_tensor.shape[2:]
        )
        # Two flavors: GT-crop (oracle ceiling) and pred-crop (deployment).
        results = {}
        for label, centroid in [('gt_crop', gt_centroid_norm), ('pred_crop', pred_centroid)]:
            centroid = trainer._round_centroid_to_voxel(centroid, wb_tensor.shape[2:])
            seg_input = trainer._crop_with_centroid(wb_tensor, centroid, (96, 96, 96))
            seg_target = trainer._load_and_crop_gt_label_patch(
                [case_key], wb_shapes, wb_tensor.shape[2:], centroid, (96, 96, 96)
            )
            logits = mod.forward_seg(seg_input)
            if isinstance(logits, (list, tuple)):
                logits = logits[0]
            probs = torch.softmax(logits, dim=1)
            pred_seg = probs.argmax(dim=1)
            img = seg_input[0, 0].cpu().numpy()
            gt = seg_target[0, 0].cpu().numpy()
            pred = pred_seg[0].cpu().numpy()
            # per-class dice
            dice = {}
            for cls_id in (1, 2):
                tp = ((pred == cls_id) & (gt == cls_id)).sum()
                fp = ((pred == cls_id) & (gt != cls_id)).sum()
                fn = ((pred != cls_id) & (gt == cls_id)).sum()
                dice[f'FG{cls_id}'] = 2 * tp / max(1, 2 * tp + fp + fn)
            results[label] = dict(img=img, gt=gt, pred=pred, dice=dice)
        # Also report loc error
        gt_vox = (gt_centroid_norm * (torch.tensor(wb_tensor.shape[2:], device=device) - 1).float()).cpu().numpy()
        pr_vox = (pred_centroid * (torch.tensor(wb_tensor.shape[2:], device=device) - 1).float()).cpu().numpy()
        loc_err_vox = float(np.linalg.norm(gt_vox - pr_vox))
        return results, loc_err_vox


def make_figure(case_key, results, loc_err_vox, save_path):
    """3 rows × 6 cols figure: 3 orthogonal planes, 6 panels (img, GT, pred for each crop mode)."""
    gt_crop = results['gt_crop']
    pred_crop = results['pred_crop']
    img_g = gt_crop['img']
    gt_g = gt_crop['gt']
    pr_g = gt_crop['pred']
    img_p = pred_crop['img']
    gt_p = pred_crop['gt']
    pr_p = pred_crop['pred']

    # Find GT FG centroid in GT-crop patch (always around k=48)
    fg = (gt_g > 0)
    if fg.any():
        cz, cy, cx = [int(c) for c in np.argwhere(fg).mean(axis=0)]
    else:
        cz, cy, cx = 48, 48, 48

    fig, axes = plt.subplots(3, 6, figsize=(18, 9))
    plane_names = ['axial (z)', 'coronal (y)', 'sagittal (x)']
    for row, (plane, idx, slicer) in enumerate([
        (plane_names[0], cz, lambda v: v[idx]),
        (plane_names[1], cy, lambda v: v[:, idx]),
        (plane_names[2], cx, lambda v: v[:, :, idx]),
    ]):
        # GT-crop (oracle): 3 panels
        overlay_label(axes[row, 0], slicer(img_g), np.zeros_like(slicer(gt_g)), f'GT-crop image\n{plane}={idx}')
        overlay_label(axes[row, 1], slicer(img_g), slicer(gt_g), f'GT-crop GT')
        overlay_label(axes[row, 2], slicer(img_g), slicer(pr_g), f'GT-crop pred')
        # pred-crop (deployment): 3 panels
        overlay_label(axes[row, 3], slicer(img_p), np.zeros_like(slicer(gt_p)), f'pred-crop image')
        overlay_label(axes[row, 4], slicer(img_p), slicer(gt_p), f'pred-crop GT')
        overlay_label(axes[row, 5], slicer(img_p), slicer(pr_p), f'pred-crop pred')

    title = (f'{case_key}  |  GT-crop dice FG1={gt_crop["dice"]["FG1"]:.3f} FG2={gt_crop["dice"]["FG2"]:.3f}  |  '
             f'pred-crop dice FG1={pred_crop["dice"]["FG1"]:.3f} FG2={pred_crop["dice"]["FG2"]:.3f}  |  '
             f'loc_err={loc_err_vox:.2f} vox\n'
             f'overlay: red=FG1 (nerve), cyan=FG2 (vessel)')
    fig.suptitle(title, fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.96])
    fig.savefig(save_path, dpi=110, bbox_inches='tight')
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--cases', nargs='+', default=None,
                    help='specific TN_xxxx keys to viz; default = sample 6 from val list')
    ap.add_argument('--n_random', type=int, default=6)
    ap.add_argument('--output_dir', required=True)
    ap.add_argument('--gpu', type=int, default=0)
    args = ap.parse_args()

    # Set up env (matching the v3 mix0604 config)
    os.environ.setdefault('nnUNet_raw', '/home/jzhou169/tn_locseg/nnUNet_data/nnUNet_raw')
    os.environ.setdefault('nnUNet_preprocessed', '/home/jzhou169/tn_locseg/nnUNet_data/nnUNet_preprocessed')
    os.environ.setdefault('TN_PREPARED_DATA_DIR', '/home/jzhou169/tn_locseg/prepared_data')
    os.environ['TN_WB_TARGET_SPACING'] = '1,1,1'
    os.environ['TN_WB_USE_PLANS_FG_NORM'] = '0'
    os.environ['TN_WB_NORM_CLIP'] = '0'
    os.environ['TN_WB_CROP_PADDING'] = 'border'
    os.environ['TN_PHASE3_VAL_USE_GT_CROP'] = '1'
    os.environ['TN_VESSEL_LOSS_WEIGHT'] = '0'
    os.environ['TN_SEG_DROPOUT_P'] = '0'
    os.environ['TN_PHASE3_SEG_AUG'] = '0'
    os.environ['TN_PHASE1_EPOCHS'] = '0'
    os.environ['TN_PHASE2_EPOCHS'] = '0'
    os.environ['TN_PHASE3_EPOCHS'] = '1000'
    os.environ['TN_NUM_ITERS_PER_EPOCH_PHASE3'] = '200'
    os.environ['TN_NUM_VAL_ITERS_PER_EPOCH_PHASE3'] = '30'
    os.environ['TN_INNER_DICE_ENABLE'] = '0'
    os.environ['TN_OVERSAMPLE_FOREGROUND_PERCENT'] = '0.85'

    from nnunetv2.utilities.dataset_name_id_conversion import maybe_convert_to_dataset_name
    from batchgenerators.utilities.file_and_folder_operations import join, load_json
    from nnunetv2.paths import nnUNet_preprocessed
    from nnunet_loc_trainer import nnUNetTrainerLoc

    dataset_name = maybe_convert_to_dataset_name('Dataset001_TN')
    plans = load_json(join(nnUNet_preprocessed, dataset_name, 'nnUNetPlans.json'))
    dataset_json = load_json(join(nnUNet_preprocessed, dataset_name, 'dataset.json'))
    plans['configurations']['3d_fullres']['patch_size'] = [96, 96, 96]
    plans['configurations']['3d_fullres']['batch_size'] = 4

    device = torch.device('cuda', args.gpu) if torch.cuda.is_available() else torch.device('cpu')
    trainer = nnUNetTrainerLoc(plans=plans, configuration='3d_fullres', fold=0,
                               dataset_json=dataset_json, device=device)
    trainer.initialize()
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    trainer.network.load_state_dict(ckpt['network_weights'])
    trainer.network.eval()
    print(f'[viz] loaded ckpt epoch={ckpt.get("current_epoch")}')

    # Pick cases
    splits = load_json(join(nnUNet_preprocessed, dataset_name, 'splits_final.json'))
    val_keys = splits[0]['val']
    if args.cases:
        cases = args.cases
    else:
        rng = np.random.default_rng(42)
        cases = list(rng.choice(val_keys, size=min(args.n_random, len(val_keys)), replace=False))
    print(f'[viz] cases ({len(cases)}): {cases}')

    os.makedirs(args.output_dir, exist_ok=True)
    summary_lines = []
    overall_dice = {'gt_crop_FG1': [], 'gt_crop_FG2': [], 'pred_crop_FG1': [], 'pred_crop_FG2': []}
    for ci, case in enumerate(cases):
        print(f'[viz] {ci+1}/{len(cases)}: {case}')
        try:
            results, loc_err = forward_one_case(trainer, case, device)
        except Exception as e:
            print(f'  FAILED: {e}')
            summary_lines.append(f'{case}: FAILED ({e})')
            continue
        save_path = join(args.output_dir, f'{case}.png')
        make_figure(case, results, loc_err, save_path)
        gd = results['gt_crop']['dice']
        pd = results['pred_crop']['dice']
        overall_dice['gt_crop_FG1'].append(gd['FG1'])
        overall_dice['gt_crop_FG2'].append(gd['FG2'])
        overall_dice['pred_crop_FG1'].append(pd['FG1'])
        overall_dice['pred_crop_FG2'].append(pd['FG2'])
        line = (f'{case}: GT-crop FG1={gd["FG1"]:.3f} FG2={gd["FG2"]:.3f}  '
                f'pred-crop FG1={pd["FG1"]:.3f} FG2={pd["FG2"]:.3f}  '
                f'loc_err={loc_err:.2f} vox')
        summary_lines.append(line)
        print(f'  -> {save_path}')
        print(f'  {line}')

    # Aggregate
    summary_lines.append('')
    summary_lines.append('=== Aggregate (mean across cases) ===')
    for k, v in overall_dice.items():
        summary_lines.append(f'{k}: mean={np.mean(v):.4f}, median={np.median(v):.4f}, std={np.std(v):.4f}, min={np.min(v):.4f}, max={np.max(v):.4f}, n={len(v)}')
    summary_path = join(args.output_dir, 'summary.txt')
    with open(summary_path, 'w') as f:
        f.write('\n'.join(summary_lines))
    print('\n=== summary ===')
    print('\n'.join(summary_lines))
    print(f'\nsaved: {summary_path}')


if __name__ == '__main__':
    main()
