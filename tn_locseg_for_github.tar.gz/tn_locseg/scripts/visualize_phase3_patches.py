"""
可视化 phase3 训练时模型实际看到的 96^3 patch 与 GT 标注的对齐情况.

对每个抽样 case:
  1. 加载 prepared_data 中的全脑 nii (例如 340x512x512 @ 0.5 mm)
  2. 加载 64^3 GT mask (1 mm), 按 spacing 比例重采样后嵌入到全脑网格
  3. 以 centroid 为中心从全脑里裁出 96^3 patch (与 trainer 逻辑一致, WB 0.5mm 下 = 48 mm 物理范围)
  4. 画三个正交中心切片 (axial/coronal/sagittal):
       - 灰度 = MRI 强度
       - 红/绿轮廓 = nerve / vessel 标注
       - 黄色虚线框 = 标注真实存在的区域 (mask_shape_original 的 48 mm 物理边界)
       - 黄框外 = "被强制当 background 的未标注区域"
  5. 在标题中报告:
       - patch 覆盖标注的体素比例
       - patch 中未标注的体素比例 (= 假阳性陷阱区域)

用法:
  conda run -n tnproject python scripts/visualize_phase3_patches.py \
      --num_cases 6 --out_dir vis_patches \
      --fold0_val   # 只挑 fold0 的 val cases (与训练评估一致)
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.patches as mpatches
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
from scipy.ndimage import zoom


ROOT = Path("${TN_ROOT}")
RAW_BASE = ROOT / "nnUNet_data" / "nnUNet_raw" / "Dataset001_TN"
PREP_BASE = ROOT / "prepared_data"
GT_SEG_BASE = ROOT / "nnUNet_data" / "nnUNet_preprocessed" / "Dataset001_TN" / "gt_segmentations"
SPLITS_FILE = ROOT / "nnUNet_data" / "nnUNet_preprocessed" / "Dataset001_TN" / "splits_final.json"
CASE_MAPPING_FILE = RAW_BASE / "case_mapping.json"

PATCH_SIZE = 96
ANNOT_PHYSICAL_MM = 48.0
LABEL_NAMES = {0: "background", 1: "nerve", 2: "vessel"}
LABEL_COLORS = {1: "tab:red", 2: "tab:green"}


def load_case(nnunet_key: str, case_mapping: dict, prep_base: Path = PREP_BASE):
    prepared = case_mapping[nnunet_key]
    case_dir = prep_base / prepared
    info = json.loads((case_dir / "info.json").read_text())

    wb_nii = nib.load(info["nii_path"])
    wb = wb_nii.get_fdata().astype(np.float32)
    if wb.ndim == 4:
        wb = wb[..., 0]
    wb_spacing = np.array(wb_nii.header.get_zooms()[:3], dtype=np.float64)

    gt_path = GT_SEG_BASE / f"{nnunet_key}.nii.gz"
    gt_nii = nib.load(gt_path)
    gt = np.rint(gt_nii.get_fdata()).astype(np.int32)
    if gt.ndim == 4:
        gt = gt[..., 0]
    gt_spacing = np.array(gt_nii.header.get_zooms()[:3], dtype=np.float64)

    centroid = np.load(case_dir / "centroid.npy").astype(np.float64)

    return {
        "key": nnunet_key,
        "prepared": prepared,
        "info": info,
        "wb": wb,
        "wb_spacing": wb_spacing,
        "gt_64": gt,
        "gt_spacing": gt_spacing,
        "centroid": centroid,
    }


def embed_gt_to_wb(case: dict) -> tuple[np.ndarray, np.ndarray]:
    """复刻 trainer 中 _load_gt_seg_resized_to_wb 的 spacing-aware 重采样 + 嵌入逻辑.

    返回:
      gt_wb: 与 wb 同形状的 int32 标签体, 仅在 ROI 区域非零;
      annotated_mask_wb: 同形状 bool, 标记"原始标注覆盖范围" (含背景 0 也算被标注),
                         即 mask_shape_embedded 投影到 wb 网格后的盒子.
    """
    wb_shape = case["wb"].shape
    centroid = case["centroid"]
    gt_64 = case["gt_64"]
    gt_spacing = case["gt_spacing"]
    wb_spacing = case["wb_spacing"]

    target_shape = np.maximum(
        1, np.round(np.array(gt_64.shape) * gt_spacing / wb_spacing).astype(np.int64)
    )
    zoom_factors = target_shape.astype(np.float64) / np.array(gt_64.shape, dtype=np.float64)
    gt_resamp = zoom(gt_64, zoom_factors, order=0, mode="nearest").astype(np.int32)

    if not np.array_equal(np.asarray(gt_resamp.shape, dtype=np.int64), target_shape):
        cropped = np.zeros(tuple(int(x) for x in target_shape), dtype=np.int32)
        sl_d = tuple(slice(0, min(int(target_shape[i]), gt_resamp.shape[i])) for i in range(3))
        cropped[sl_d] = gt_resamp[sl_d]
        gt_resamp = cropped

    center = np.round(centroid).astype(np.int64)
    half = (target_shape // 2).astype(np.int64)

    gt_wb = np.zeros(wb_shape, dtype=np.int32)
    annotated = np.zeros(wb_shape, dtype=bool)

    def emb_slice(c: int, h: int, t: int, dim: int):
        lo = c - h
        hi = lo + t
        lo_clip = max(0, int(lo))
        hi_clip = min(int(dim), int(hi))
        if hi_clip <= lo_clip:
            return None, None
        src_lo = lo_clip - int(lo)
        src_hi = src_lo + (hi_clip - lo_clip)
        return slice(lo_clip, hi_clip), slice(src_lo, src_hi)

    s0, ss0 = emb_slice(center[0], half[0], target_shape[0], wb_shape[0])
    s1, ss1 = emb_slice(center[1], half[1], target_shape[1], wb_shape[1])
    s2, ss2 = emb_slice(center[2], half[2], target_shape[2], wb_shape[2])
    if s0 is not None and s1 is not None and s2 is not None:
        gt_wb[s0, s1, s2] = gt_resamp[ss0, ss1, ss2]
        annotated[s0, s1, s2] = True

    return gt_wb, annotated


def crop_patch(volume: np.ndarray, centroid: np.ndarray, patch: int) -> tuple[np.ndarray, tuple]:
    """以 centroid 为中心裁出 patch^3, 边界用 0/False 填充. 返回 (patch_volume, lo_corner_in_wb)."""
    half = patch // 2
    center = np.round(centroid).astype(np.int64)
    lo = center - half
    hi = lo + patch
    out_shape = (patch, patch, patch)
    out = np.zeros(out_shape, dtype=volume.dtype)

    src_lo = np.maximum(lo, 0)
    src_hi = np.minimum(hi, np.array(volume.shape))
    if np.any(src_hi <= src_lo):
        return out, tuple(int(x) for x in lo)
    dst_lo = src_lo - lo
    dst_hi = dst_lo + (src_hi - src_lo)
    out[dst_lo[0]:dst_hi[0], dst_lo[1]:dst_hi[1], dst_lo[2]:dst_hi[2]] = volume[
        src_lo[0]:src_hi[0], src_lo[1]:src_hi[1], src_lo[2]:src_hi[2]
    ]
    return out, tuple(int(x) for x in lo)


def render_case(case: dict, out_path: Path, patch_size: int = PATCH_SIZE):
    gt_wb, annotated_wb = embed_gt_to_wb(case)
    img_patch, lo_corner = crop_patch(case["wb"], case["centroid"], patch_size)
    gt_patch, _ = crop_patch(gt_wb, case["centroid"], patch_size)
    annot_patch, _ = crop_patch(annotated_wb.astype(np.int8), case["centroid"], patch_size)
    annot_patch = annot_patch.astype(bool)

    p_lo = np.percentile(img_patch[img_patch > 0], 1) if (img_patch > 0).any() else 0
    p_hi = np.percentile(img_patch, 99.5) if img_patch.size else 1

    annot_voxels = int(annot_patch.sum())
    fg_voxels = int((gt_patch > 0).sum())
    forced_bg_voxels = int(((~annot_patch) & (gt_patch == 0)).sum())
    total = patch_size ** 3
    nerve_voxels = int((gt_patch == 1).sum())
    vessel_voxels = int((gt_patch == 2).sum())

    annot_phys_voxels = ANNOT_PHYSICAL_MM / case["wb_spacing"]
    annot_half_phys = annot_phys_voxels / 2.0
    patch_center = np.array([patch_size // 2] * 3, dtype=np.float64)

    fig, axes = plt.subplots(1, 3, figsize=(15, 5.4))
    plane_names = ["axial (z mid)", "coronal (y mid)", "sagittal (x mid)"]
    mid = patch_size // 2

    def get_slice(vol, axis):
        if axis == 0:
            return vol[mid, :, :]
        if axis == 1:
            return vol[:, mid, :]
        return vol[:, :, mid]

    annot_axes_idx = [(1, 2), (0, 2), (0, 1)]

    for ax, axis, name in zip(axes, range(3), plane_names):
        img_sl = get_slice(img_patch, axis).T
        gt_sl = get_slice(gt_patch, axis).T
        annot_sl = get_slice(annot_patch.astype(np.int8), axis).T

        ax.imshow(img_sl, cmap="gray", origin="lower", vmin=p_lo, vmax=p_hi)

        not_annot_overlay = np.zeros((*annot_sl.shape, 4), dtype=np.float32)
        not_annot_overlay[annot_sl == 0] = (1.0, 1.0, 0.0, 0.18)
        ax.imshow(not_annot_overlay, origin="lower")

        for label_v, color in LABEL_COLORS.items():
            mask = (gt_sl == label_v)
            if not mask.any():
                continue
            ax.contour(mask.astype(np.uint8), levels=[0.5], colors=color, linewidths=1.2)

        a, b = annot_axes_idx[axis]
        rect_w = annot_phys_voxels[b]
        rect_h = annot_phys_voxels[a]
        rect = mpatches.Rectangle(
            (patch_center[b] - rect_w / 2, patch_center[a] - rect_h / 2),
            rect_w, rect_h,
            linewidth=1.0, edgecolor="yellow", facecolor="none", linestyle="--",
        )
        ax.add_patch(rect)
        ax.axhline(patch_center[a], color="cyan", linewidth=0.4, alpha=0.5)
        ax.axvline(patch_center[b], color="cyan", linewidth=0.4, alpha=0.5)

        ax.set_title(name, fontsize=10)
        ax.set_xticks([])
        ax.set_yticks([])

    title = (
        f"{case['key']} ({case['prepared']})  |  WB={tuple(case['wb'].shape)}  "
        f"spacing={tuple(np.round(case['wb_spacing'], 2).tolist())}mm  "
        f"centroid={case['centroid'].astype(int).tolist()}\n"
        f"annot_in_patch={annot_voxels}/{total} ({100*annot_voxels/total:.1f}%)  |  "
        f"fg(nerve+vessel)={fg_voxels} ({100*fg_voxels/total:.2f}%)  "
        f"[nerve={nerve_voxels}, vessel={vessel_voxels}]  |  "
        f"forced_bg_outside_annot={total - annot_voxels} ({100*(total-annot_voxels)/total:.1f}%)"
    )
    fig.suptitle(title, fontsize=10)

    legend_handles = [
        mpatches.Patch(color="tab:red", label="GT nerve (label=1)"),
        mpatches.Patch(color="tab:green", label="GT vessel (label=2)"),
        mpatches.Patch(facecolor=(1, 1, 0, 0.18), edgecolor="yellow",
                       linestyle="--", label="not-annotated region (forced bg)"),
        mpatches.Patch(facecolor="none", edgecolor="yellow",
                       linestyle="--", label="annotation 48mm core"),
    ]
    fig.legend(handles=legend_handles, loc="lower center", ncol=4, fontsize=9,
               frameon=False, bbox_to_anchor=(0.5, -0.02))

    fig.tight_layout(rect=[0, 0.04, 1, 0.93])
    fig.savefig(out_path, dpi=120, bbox_inches="tight")
    plt.close(fig)
    return {
        "annot_voxels": annot_voxels,
        "forced_bg_voxels": forced_bg_voxels,
        "fg_voxels": fg_voxels,
        "nerve_voxels": nerve_voxels,
        "vessel_voxels": vessel_voxels,
        "total": total,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--out_dir", type=str, default="vis_patches")
    parser.add_argument("--num_cases", type=int, default=6)
    parser.add_argument("--keys", type=str, nargs="*", default=None,
                        help="显式指定 nnU-Net keys, 如 TN_0010 TN_0011 ...")
    parser.add_argument("--fold0_val", action="store_true",
                        help="从 fold0 val 中均匀抽样")
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    out_dir = ROOT / args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    case_mapping = json.loads(CASE_MAPPING_FILE.read_text())

    if args.keys:
        keys = args.keys
    elif args.fold0_val:
        splits = json.loads(SPLITS_FILE.read_text())
        val = splits[0]["val"]
        rng = np.random.default_rng(args.seed)
        idx = rng.choice(len(val), size=min(args.num_cases, len(val)), replace=False)
        keys = [val[i] for i in sorted(idx.tolist())]
    else:
        all_keys = sorted(case_mapping.keys())
        rng = np.random.default_rng(args.seed)
        idx = rng.choice(len(all_keys), size=min(args.num_cases, len(all_keys)), replace=False)
        keys = [all_keys[i] for i in sorted(idx.tolist())]

    print(f"[vis] writing to {out_dir}, cases={keys}")

    summary = []
    for k in keys:
        try:
            case = load_case(k, case_mapping)
        except Exception as e:
            print(f"  [skip] {k}: {type(e).__name__}: {e}")
            continue
        out_png = out_dir / f"{k}_{case['prepared']}.png"
        stats = render_case(case, out_png)
        print(
            f"  {k}/{case['prepared']}: "
            f"annot={100*stats['annot_voxels']/stats['total']:.1f}%  "
            f"fg={100*stats['fg_voxels']/stats['total']:.2f}%  "
            f"forced_bg={100*(stats['total']-stats['annot_voxels'])/stats['total']:.1f}%  "
            f"-> {out_png.name}"
        )
        summary.append({"key": k, **stats})

    if summary:
        annot_pct = np.mean([100 * s["annot_voxels"] / s["total"] for s in summary])
        forced_pct = np.mean([100 * (s["total"] - s["annot_voxels"]) / s["total"] for s in summary])
        fg_pct = np.mean([100 * s["fg_voxels"] / s["total"] for s in summary])
        print(
            f"\n[summary] mean over {len(summary)} cases: "
            f"annot_in_patch={annot_pct:.1f}%, "
            f"forced_bg_in_patch={forced_pct:.1f}%, "
            f"fg_in_patch={fg_pct:.2f}%"
        )


if __name__ == "__main__":
    main()
