"""
finetune_openneuro.py
=====================
Fine-tune mix0604_v3 best ckpt on OpenNeuro 64 train + 16 val cases.

策略:
  - 不走 nnUNet preprocessing 那套 (OpenNeuro 没进 nnUNet 数据集)
  - 用 dummy dataloader (只提供 keys, batch.data/target 是占位 zeros), phase3 路径
    实际从 prepared_data 走 wholebrain bridge 加载
  - monkey-patch trainer 的 case_mapping + _load_gt_seg_resized_to_wb
  - 低 lr (5e-4), 100 epoch, AdamW
  - 输出 ckpt + per-epoch dice csv
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import os, sys, json, argparse, time
import numpy as np
import torch
import torch.nn.functional as F
import nibabel as nib

sys.path.insert(0, REPO_ROOT)


class DummyKeyIterator:
    """无限迭代, 每次 yield 一个 batch 含 bs 个 keys + dummy data/target.
    phase3 路径忽略 batch.data/target, 只用 keys."""
    def __init__(self, keys, batch_size, patch_size=(96, 96, 96), shuffle=True):
        self.keys = list(keys)
        self.bs = batch_size
        self.ps = patch_size
        self.shuffle = shuffle
        self._buf = []
    def __iter__(self): return self
    def __next__(self):
        if len(self._buf) < self.bs:
            new_order = list(self.keys)
            if self.shuffle:
                np.random.shuffle(new_order)
            self._buf.extend(new_order)
        sampled = self._buf[:self.bs]
        self._buf = self._buf[self.bs:]
        return {
            'data': torch.zeros(self.bs, 1, *self.ps, dtype=torch.float32),
            'target': torch.zeros(self.bs, 1, *self.ps, dtype=torch.long),
            'keys': np.array(sampled),
        }


def patch_trainer_for_openneuro(trainer, prepared_dir):
    """1. 给 _case_mapping 加 sub-* identity 映射. 2. patch GT 加载用 mask_aligned."""
    sub_names = sorted([d for d in os.listdir(prepared_dir) if d.startswith('sub-')])
    for sn in sub_names:
        trainer._case_mapping[sn] = sn

    orig_load_gt = trainer._load_gt_seg_resized_to_wb
    def patched(nnunet_key, wb_shape_dhw):
        if not nnunet_key.startswith('sub-'):
            return orig_load_gt(nnunet_key, wb_shape_dhw)
        prep_dir = os.path.join(prepared_dir, nnunet_key)
        mask_nii = nib.load(os.path.join(prep_dir, 'mask_aligned.nii.gz'))
        mask = np.rint(mask_nii.get_fdata()).astype(np.int64)
        spacing_mask = np.array(mask_nii.header.get_zooms()[:3], dtype=np.float64)
        info = json.load(open(os.path.join(prep_dir, 'info.json')))
        wb_nii = nib.load(info['nii_path'])
        spacing_prep = np.array(wb_nii.header.get_zooms()[:3], dtype=np.float64)
        native_shape = tuple(int(x) for x in wb_nii.shape[:3])
        target_shape = np.maximum(1, np.round(np.array(mask.shape) * spacing_mask / spacing_prep).astype(int))
        mt = torch.from_numpy(mask.astype(np.float32)).view(1, 1, *mask.shape)
        mt = F.interpolate(mt, size=tuple(int(x) for x in target_shape), mode='nearest')
        mask_resamp = torch.round(mt[0, 0]).long().numpy()
        centroid = np.load(os.path.join(prep_dir, 'centroid.npy')).astype(np.float64)
        center = np.round(centroid).astype(int); half = target_shape // 2
        full_native = np.zeros(native_shape, dtype=np.int64)
        def emb(c, h, t, dim):
            lf=c-h; hf=lf+t; lc=max(0,int(lf)); hc=min(int(dim),int(hf))
            if hc<=lc: return None,None
            sl=lc-int(lf); sh=sl+(hc-lc)
            return slice(lc,hc), slice(sl,sh)
        s = [emb(center[i], half[i], target_shape[i], native_shape[i]) for i in range(3)]
        if all(x[0] is not None for x in s):
            full_native[s[0][0], s[1][0], s[2][0]] = mask_resamp[s[0][1], s[1][1], s[2][1]]
        if native_shape != tuple(int(x) for x in wb_shape_dhw):
            ft = torch.from_numpy(full_native.astype(np.float32)).view(1, 1, *native_shape)
            ft = F.interpolate(ft, size=tuple(int(x) for x in wb_shape_dhw), mode='nearest')
            full = torch.round(ft[0, 0]).long().numpy()
        else:
            full = full_native
        return np.clip(full, 0, 2).astype(np.int64)
    trainer._load_gt_seg_resized_to_wb = patched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--init_ckpt', required=True, help='起点 ckpt (mix0604_v3 best)')
    ap.add_argument('--split_json', required=True)
    ap.add_argument('--output_dir', required=True)
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--epochs', type=int, default=100)
    ap.add_argument('--iters_per_epoch', type=int, default=64, help='默认 64 ≈ 走完 train 集 1 遍 (bs=4 × 16 = 64 case-views ≈ 64 train)')
    ap.add_argument('--seg_lr', type=float, default=5e-4, help='fine-tune 用低 lr (vs 训练 0.01)')
    ap.add_argument('--loc_lr', type=float, default=1e-4)
    ap.add_argument('--bs', type=int, default=4)
    ap.add_argument('--val_interval', type=int, default=2)
    args = ap.parse_args()

    # Env
    os.environ.setdefault('nnUNet_raw', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_raw'))
    os.environ.setdefault('nnUNet_preprocessed', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_preprocessed'))
    os.environ.setdefault('TN_PREPARED_DATA_DIR', os.path.join(REPO_ROOT, 'prepared_data'))
    os.environ.update({
        'TN_WB_TARGET_SPACING': '1,1,1', 'TN_WB_USE_PLANS_FG_NORM': '0',
        'TN_WB_NORM_CLIP': '0', 'TN_WB_CROP_PADDING': 'border',
        'TN_PHASE3_VAL_USE_GT_CROP': '1', 'TN_VESSEL_LOSS_WEIGHT': '0',
        'TN_SEG_DROPOUT_P': '0.15', 'TN_PHASE3_SEG_AUG': '1',
        # 加 loc aug — gentle 版本 (上一轮 aug 过强导致 catastrophic forgetting,
        # val FG1 dice 从 0.37 一路掉到 0.09). 现在减半频率 + 减半幅度.
        'TN_LOC_PHASE3_AUG': '1',
        'TN_LOC_AUG_AFFINE_PROB': '0.3',
        'TN_LOC_AUG_MAX_ROTATE_DEG': '5',
        'TN_LOC_AUG_SCALE_MIN': '0.95', 'TN_LOC_AUG_SCALE_MAX': '1.05',
        'TN_LOC_AUG_GAMMA_PROB': '0.15',
        'TN_PHASE1_EPOCHS': '0', 'TN_PHASE2_EPOCHS': '0',
        'TN_PHASE3_EPOCHS': str(args.epochs),
        'TN_OVERSAMPLE_FOREGROUND_PERCENT': '0.85',
        'TN_INNER_DICE_ENABLE': '0',
    })
    os.makedirs(args.output_dir, exist_ok=True)
    log_path = os.path.join(args.output_dir, f'finetune_{time.strftime("%Y%m%d_%H%M%S")}.log')

    def log(msg):
        with open(log_path, 'a') as f: f.write(msg + '\n')
        print(msg, flush=True)

    log(f'[finetune] init_ckpt={args.init_ckpt}, epochs={args.epochs}, lr_seg={args.seg_lr}, lr_loc={args.loc_lr}')

    from nnunetv2.utilities.dataset_name_id_conversion import maybe_convert_to_dataset_name
    from batchgenerators.utilities.file_and_folder_operations import join, load_json
    from nnunetv2.paths import nnUNet_preprocessed
    from nnunet_loc_trainer import nnUNetTrainerLoc

    plans = load_json(join(nnUNet_preprocessed, 'Dataset001_TN', 'nnUNetPlans.json'))
    dataset_json = load_json(join(nnUNet_preprocessed, 'Dataset001_TN', 'dataset.json'))
    plans['configurations']['3d_fullres']['patch_size'] = [96, 96, 96]
    plans['configurations']['3d_fullres']['batch_size'] = args.bs

    device = torch.device('cuda', args.gpu)
    trainer = nnUNetTrainerLoc(plans=plans, configuration='3d_fullres', fold=0,
                               dataset_json=dataset_json, device=device)
    trainer.initialize()
    ckpt = torch.load(args.init_ckpt, map_location=device, weights_only=False)
    trainer.network.load_state_dict(ckpt['network_weights'])
    log(f'[finetune] loaded init ckpt epoch={ckpt.get("current_epoch")}')

    # Patch case_mapping + GT loading
    patch_trainer_for_openneuro(trainer, os.environ['TN_PREPARED_DATA_DIR'])

    # 替换 dataloader 为我们的 dummy iterator
    splits = json.load(open(args.split_json))
    train_keys = splits['train']; val_keys = splits['val']
    log(f'[finetune] train={len(train_keys)} val={len(val_keys)}')
    trainer.dataloader_train = DummyKeyIterator(train_keys, args.bs, (96, 96, 96), shuffle=True)
    trainer.dataloader_val = DummyKeyIterator(val_keys, args.bs, (96, 96, 96), shuffle=False)

    # 重建 optimizer with low lr
    from nnunet_loc_trainer import nnUNetTrainerLoc as _T
    mod = trainer.network.module if hasattr(trainer.network, 'module') else trainer.network
    if hasattr(mod, '_orig_mod'): mod = mod._orig_mod
    seg_params = [p for p in mod.seg_net.parameters() if p.requires_grad]
    loc_params = [p for p in mod.loc_net.parameters() if p.requires_grad]
    trainer.optimizer = torch.optim.AdamW(
        [{'params': seg_params, 'lr': args.seg_lr, 'name': 'seg'},
         {'params': loc_params, 'lr': args.loc_lr, 'name': 'loc'}],
        weight_decay=3e-5
    )
    log(f'[finetune] optimizer AdamW: seg_lr={args.seg_lr}, loc_lr={args.loc_lr}')

    # Manual training loop (绕过 trainer.run_training, 它会重建 optimizer)
    best_dice = -1.0
    csv_rows = ['epoch,train_seg_loss,train_loc_err,val_loss,val_loc_err,val_fg1_dice,val_fg2_dice']
    for epoch in range(args.epochs):
        trainer.current_epoch = epoch
        trainer.network.train()
        # train
        train_losses = []; train_loc_errs = []; train_seg_losses = []
        for it in range(args.iters_per_epoch):
            batch = next(trainer.dataloader_train)
            out = trainer.train_step(batch)
            train_losses.append(float(out['loss']))
            train_seg_losses.append(float(out['seg_loss']))
            train_loc_errs.append(float(out['loc_err_vox']))
        # val
        if (epoch + 1) % args.val_interval == 0 or epoch == args.epochs - 1:
            trainer.network.eval()
            tps = np.zeros(2); fps = np.zeros(2); fns = np.zeros(2)
            val_losses = []; val_loc_errs = []
            for it in range(max(1, len(val_keys) // args.bs)):
                batch = next(trainer.dataloader_val)
                with torch.no_grad():
                    out = trainer.validation_step(batch)
                val_losses.append(float(out['loss']))
                val_loc_errs.append(float(out.get('loc_err_vox', 0)))
                tps += np.asarray(out['tp_hard'])
                fps += np.asarray(out['fp_hard'])
                fns += np.asarray(out['fn_hard'])
            dice = 2*tps / np.maximum(1, 2*tps + fps + fns)
            avg_d = float(np.mean(dice))
            line = f'epoch {epoch+1:3d}/{args.epochs}  train_seg_loss={np.mean(train_seg_losses):+.4f}  train_loc_err={np.mean(train_loc_errs):.2f}  val_loss={np.mean(val_losses):+.4f}  val_loc_err={np.mean(val_loc_errs):.2f}  dice FG1={dice[0]:.4f} FG2={dice[1]:.4f}'
            log(line)
            csv_rows.append(f'{epoch+1},{np.mean(train_seg_losses):.4f},{np.mean(train_loc_errs):.4f},{np.mean(val_losses):.4f},{np.mean(val_loc_errs):.4f},{dice[0]:.4f},{dice[1]:.4f}')
            with open(os.path.join(args.output_dir, 'metrics.csv'), 'w') as f: f.write('\n'.join(csv_rows))
            if avg_d > best_dice:
                best_dice = avg_d
                torch.save({'network_weights': trainer.network.state_dict(),
                            'current_epoch': epoch, 'best_dice': best_dice},
                           os.path.join(args.output_dir, 'finetune_best.pth'))
                log(f'  -> new best (avg dice={best_dice:.4f}), saved finetune_best.pth')
            torch.save({'network_weights': trainer.network.state_dict(), 'current_epoch': epoch},
                       os.path.join(args.output_dir, 'finetune_latest.pth'))
        else:
            line = f'epoch {epoch+1:3d}/{args.epochs}  train_seg_loss={np.mean(train_seg_losses):+.4f}  train_loc_err={np.mean(train_loc_errs):.2f}'
            log(line)

    log(f'\n[finetune] done. best avg dice = {best_dice:.4f}')
    log(f'output: {args.output_dir}/finetune_best.pth')


if __name__ == '__main__':
    main()
