#!/usr/bin/env bash
set -euo pipefail

ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="${ROOT}/train_p3_smooth_inner48_${TS}.log"

cd "${ROOT}"
export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_p3_smooth_inner48"
export CUDA_VISIBLE_DEVICES=2

"${PYTHON:-python}" train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --phase1_epochs 0 \
  --phase2_epochs 0 \
  --phase3_epochs 600 \
  --phase3_warmup_epochs 40 \
  --smooth_sigma 1.0 \
  --seg_bs 8 \
  --num_iters_phase3 60 \
  --num_val_iters_phase3 30 \
  --val_interval 5 \
  --inner_dice_crop 48 \
  --pretrained_weights "${ROOT}/nnUNet_data/nnUNet_results_p3_smooth/Dataset001_TN/nnUNetTrainerLoc__nnUNetPlans__3d_fullres/fold_0/phase3_best.pth" \
  |& tee "${LOG}"

echo "[done] log: ${LOG}"
