#!/usr/bin/env bash
# Phase3 from scratch, 套今天 (2026-05-04) 加的两条改动:
#   1) --loss focal_tversky  (CE + FocalTversky, alpha=0.7 beta=0.3 gamma=4/3)
#   2) --oversample_foreground_percent 0.85  (从 0.55 提到 0.85)
# 其余沿用 run_p3_scratch_mix0604.sh 的成熟配置:
#   - phase3_min_gt_mix 0.6  (60% GT crop + 40% pred crop, 教网络容忍 loc 漂移)
#   - phase3_val_full + cover 4  (val 全覆盖, pseudo dice 标准差 ±0.01 而非 ±0.03)
#   - splits_final.json 已 MRN-disjoint (fix_splits_by_mrn.py)
#   - dropout p=0.15 保留 (与历史可比)

set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-1}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_p3_scratch_ftversky_20260504"

export TN_WB_TARGET_SPACING=1,1,1
export TN_WB_USE_PLANS_FG_NORM=1
export TN_PHASE3_VAL_USE_GT_CROP=1
export TN_PHASE3_VESSEL_OVERSAMPLE_PROB=0.35
export TN_VESSEL_LOSS_WEIGHT=0.75
# 不再 export TN_OVERSAMPLE_FOREGROUND_PERCENT, 让 CLI 默认 0.85 生效
export TN_SEG_DROPOUT_P=0.15

LOG_DIR="${nnUNet_results}"
mkdir -p "$LOG_DIR"
LOG="${LOG_DIR}/train_scratch_ftversky_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

"${PYTHON:-python}" train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --loc_arch attn \
  --seg_patch_size 96 96 96 \
  --seg_bs 4 \
  --phase1_epochs 0 \
  --phase2_epochs 0 \
  --phase3_epochs 1000 \
  --phase3_warmup_epochs 200 \
  --num_iters_phase3 200 \
  --num_val_iters_phase3 30 \
  --phase3_val_full \
  --phase3_val_cover 4 \
  --val_interval 5 \
  --disable_inner_dice \
  --smooth_sigma 0 \
  --loc_loss_weight 0.2 \
  --loc_phase3_lr 5e-4 \
  --loc_phase3_lr_schedule cosine \
  --loc_phase3_lr_min_ratio 0.1 \
  --phase3_min_gt_mix 0.6 \
  --phase3_fg_aux_weight 0.0 \
  --loss focal_tversky \
  --ft_alpha 0.7 \
  --ft_beta 0.3 \
  --ft_gamma 1.333 \
  --oversample_foreground_percent 0.85 \
  2>&1 | tee "$LOG"

echo "[done] log: $LOG"
