#!/usr/bin/env bash
# Phase3 单 case 过拟合 sanity check
# 目的: 确认 phase3 pipeline 在 1 个 case 上能学到 dice → 0.9+
#   - 通过 → pipeline 正常, v3 卡 0.13 是别的原因 (数据量 / val 泛化)
#   - 不通过 → 一定有结构 bug (GT 错位 / 标签加载错 / 归一化), 立刻定位
# 配置 (相比 v3):
#   - 用临时 preprocessed_overfit dir, splits 全 5 折都是 train=val=[TN_0004]
#   - 全部用 GT 质心 (--phase3_min_gt_mix 1.0), 排除 loc 干扰
#   - num_iters_phase3=30, val_interval=1 (每 epoch 一次 val, 信号密集)
#   - 30 epoch 跑, 单 epoch ~75-90s, 总计 ~40 min
# 不开 augmentation? 仍然开 (默认), 即使带 aug 单 case 也必须能拟合到 dice ≈ 0.95+

set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
# 关键: 用 _overfit 临时 dir, splits 是单 case
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed_overfit"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_p3_overfit_sanity_20260507"

export TN_WB_TARGET_SPACING=1,1,1
# #24 fix: D001 是 MRI 不是 CT, 必须用 per-case 全图 z-score (与 D096 stock 一致),
# 不能用 CT-style 全局 plans-fg-norm + clip (那个 std 只有 0.19, 网络学不到东西).
export TN_WB_USE_PLANS_FG_NORM=0
export TN_WB_NORM_CLIP=0                  # 关 (CT-only)
export TN_WB_CROP_PADDING=border          # #22 c (跨 modality 都对)

export TN_PHASE3_VAL_USE_GT_CROP=1
export TN_PHASE3_VESSEL_OVERSAMPLE_PROB=0.35
export TN_VESSEL_LOSS_WEIGHT=0            # #23 关 vessel aux
# 单 case overfit sanity 必须关掉这俩, 否则 train (dropout+aug) >> eval (无), pseudo dice 永远 0
export TN_SEG_DROPOUT_P=0
export TN_PHASE3_SEG_AUG=0

LOG_DIR="${nnUNet_results}"
mkdir -p "$LOG_DIR"
LOG="${LOG_DIR}/train_overfit_sanity_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

"${PYTHON:-python}" train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --continue_training \
  --loc_arch attn \
  --seg_patch_size 96 96 96 \
  --seg_bs 4 \
  --phase1_epochs 0 \
  --phase2_epochs 0 \
  --phase3_epochs 100 \
  --phase3_warmup_epochs 5 \
  --num_iters_phase3 30 \
  --num_val_iters_phase3 8 \
  --val_interval 1 \
  --disable_inner_dice \
  --smooth_sigma 0 \
  --loc_loss_weight 0.2 \
  --loc_phase3_lr 5e-4 \
  --loc_phase3_lr_schedule cosine \
  --loc_phase3_lr_min_ratio 0.1 \
  --phase3_min_gt_mix 1.0 \
  --phase3_fg_aux_weight 0.0 \
  --loss default \
  --oversample_foreground_percent 0.85 \
  2>&1 | tee "$LOG"

echo "[done] log: $LOG"
