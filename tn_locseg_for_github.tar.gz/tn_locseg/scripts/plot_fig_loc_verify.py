"""Render fig_loc_verify.png from regen_*/val_dice_per_case.csv + sample_*.npz."""
import os, argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--in_dir', required=True)
    ap.add_argument('--out_png', required=True)
    ap.add_argument('--ckpt_tag', default='locaug e555')
    args = ap.parse_args()

    df = pd.read_csv(os.path.join(args.in_dir, 'val_dice_per_case.csv'))
    df = df[df['loc_err_vox'] != 'FAIL'].copy()
    df['loc_err_vox'] = df['loc_err_vox'].astype(float)
    df['loc_err_mm'] = df['loc_err_mm'].astype(float)
    n_cases = len(df)
    mean_vox = df['loc_err_vox'].mean(); median_vox = df['loc_err_vox'].median()
    mean_mm = df['loc_err_mm'].mean(); median_mm = df['loc_err_mm'].median()

    fig = plt.figure(figsize=(15, 10))
    gs = fig.add_gridspec(2, 3, height_ratios=[1, 1], hspace=0.32, wspace=0.28)

    # ---- top-left: histogram ----
    ax = fig.add_subplot(gs[0, 0])
    bins = np.linspace(0, max(35, df['loc_err_vox'].max()*1.05), 25)
    ax.hist(df['loc_err_vox'], bins=bins, color='#5b9bd5', edgecolor='white')
    ax.axvline(mean_vox, color='red', linestyle='--', linewidth=1.5, label=f'Mean: {mean_vox:.1f} vox')
    ax.axvline(median_vox, color='orange', linestyle='--', linewidth=1.5, label=f'Median: {median_vox:.1f} vox')
    ax.set_xlabel('Localization Error (voxels @ 1 mm)')
    ax.set_ylabel('Count')
    ax.set_title('Error Distribution (Voxel)')
    ax.legend(loc='upper right', fontsize=9)
    ax.grid(alpha=0.3)

    # ---- top-mid: CDF (mm) ----
    ax = fig.add_subplot(gs[0, 1])
    s = np.sort(df['loc_err_mm'].values)
    cdf = np.linspace(0, 100, len(s), endpoint=True)
    ax.plot(s, cdf, color='#1f77b4', linewidth=2)
    pct = lambda thr: (df['loc_err_mm'] < thr).mean() * 100
    for thr, color in [(2, '#2ca02c'), (5, '#ff7f0e'), (10, '#d62728')]:
        ax.axvline(thr, color=color, linestyle=':', alpha=0.7)
        ax.annotate(f'<{thr}mm: {pct(thr):.0f}%', xy=(thr, pct(thr)),
                    xytext=(thr+0.5, pct(thr)-3), fontsize=9, color=color)
    ax.set_xlabel('Error (mm)')
    ax.set_ylabel('Cumulative %')
    ax.set_title('CDF (Physical Distance)')
    ax.set_xlim(0, max(15, s.max()*1.05)); ax.set_ylim(0, 102)
    ax.grid(alpha=0.3)

    # ---- top-right: ipsi vs contra box ----
    ax = fig.add_subplot(gs[0, 2])
    ipsi = df[df['side'] == 'ipsi']['loc_err_mm']
    contra = df[df['side'] == 'contra']['loc_err_mm']
    bp = ax.boxplot([ipsi, contra], labels=[f'Ipsi (n={len(ipsi)})', f'Contra (n={len(contra)})'],
                    patch_artist=True, widths=0.5)
    for patch, color in zip(bp['boxes'], ['#5b9bd5', '#ed7d31']):
        patch.set_facecolor(color); patch.set_alpha(0.7)
    ax.set_ylabel('Error (mm)')
    ax.set_title('Ipsi vs Contra (mm)')
    ax.text(1, max(ipsi.max(), contra.max())*1.05, f'Mean={ipsi.mean():.2f}', ha='center', fontsize=8)
    ax.text(2, max(ipsi.max(), contra.max())*1.05, f'Mean={contra.mean():.2f}', ha='center', fontsize=8)
    ax.grid(alpha=0.3, axis='y')

    # ---- bottom: 3 axial samples (low / med / high) ----
    titles = {'low': 'Best decile', 'med': 'Median', 'high': 'Worst decile'}
    for i, tag in enumerate(['low', 'med', 'high']):
        ax = fig.add_subplot(gs[1, i])
        p = os.path.join(args.in_dir, f'sample_{tag}.npz')
        if not os.path.exists(p):
            ax.text(0.5, 0.5, f'(missing {tag})', ha='center', va='center'); ax.axis('off'); continue
        d = np.load(p, allow_pickle=True)
        sl = d['slice_ax']  # (D, H)
        # Display axial slice (transpose so vertical is anatomical superior)
        lo, hi = np.percentile(sl, [2, 98])
        ax.imshow(sl.T, cmap='gray', vmin=lo, vmax=hi, origin='lower')
        gt = d['gt_vox']; pr = d['pr_vox']
        ax.scatter([gt[0]], [gt[1]], s=80, edgecolor='cyan', facecolor='none', linewidth=2, label='GT')
        ax.scatter([pr[0]], [pr[1]], s=80, marker='+', color='red', linewidth=2, label='Pred')
        case = str(d['case']); side = str(d['side']); err = float(d['err_mm'])
        ax.set_title(f'{titles[tag]} — {case} ({side})\nerr={err:.2f} mm', fontsize=10)
        ax.legend(loc='upper right', fontsize=8, framealpha=0.6)
        ax.set_xlabel('x (vox)'); ax.set_ylabel('y (vox)')

    fig.suptitle(f'Localization Verification (whole-brain @ 1 mm iso, {args.ckpt_tag})  |  n={n_cases} val cases\n'
                 f'Mean: {mean_vox:.1f} vox / {mean_mm:.2f} mm    Median: {median_vox:.1f} vox / {median_mm:.2f} mm',
                 fontsize=13, fontweight='bold', y=0.995)
    fig.savefig(args.out_png, dpi=140, bbox_inches='tight')
    print(f'[saved] {args.out_png}')


if __name__ == '__main__':
    main()
