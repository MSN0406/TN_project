#!/usr/bin/env bash
# Fine-tune mix0604_v3 best ckpt on OpenNeuro 64 train + 16 val cases.
set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

OUT="${ROOT}/nnUNet_data/nnUNet_results_openneuro_finetune_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT"
echo "Output: $OUT"

"${PYTHON:-python}" \
  ${ROOT}/scripts/finetune_openneuro.py \
  --init_ckpt ${ROOT}/nnUNet_data/viz_snapshots/mix0604_v3_phase3_best_e110.pth \
  --split_json ${ROOT}/nnUNet_data/openneuro_finetune_split.json \
  --output_dir "$OUT" \
  --gpu 0 \
  --epochs 100 \
  --iters_per_epoch 64 \
  --seg_lr 5e-4 \
  --loc_lr 1e-4 \
  --bs 4 \
  --val_interval 2 \
  2>&1 | tee "$OUT/run.log"

echo "[done] log: $OUT/run.log"
