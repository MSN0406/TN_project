#!/usr/bin/env bash
# Phase3 from scratch, 100% GT crop (phase3_min_gt_mix=1.0) — v2 with all fixes
# vs run_p3_scratch_gt100.sh, 套上 2026-05-04 加的全部修复:
#   #21 (P0) Focal Tversky loss + oversample 0.85
#   #22 b   wholebrain norm clip to plans [p0.5, p99.5]      (env TN_WB_NORM_CLIP=1, default)
#   #22 c   diff_crop padding_mode 'zeros' -> 'border'        (env TN_WB_CROP_PADDING=border, default)
#   phase3_val_full + cover 4                                  (低噪音 pseudo dice)
#   splits 已 MRN-disjoint
#
# 与 run_p3_scratch_mix0604_v2.sh 构成 A/B 对比 (纯 GT 质心 vs mix 60/40)
# GT100 是"理论最强 train condition" (无 loc 漂移污染), 与 mix 比可看 loc 干扰多大

set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-1}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_p3_scratch_gt100_v2_20260504"

export TN_WB_TARGET_SPACING=1,1,1
export TN_WB_USE_PLANS_FG_NORM=1
# 新修复 (默认就是这俩, 显式写出来便于 grep 验证)
export TN_WB_NORM_CLIP=1
export TN_WB_CROP_PADDING=border

export TN_PHASE3_VAL_USE_GT_CROP=1
export TN_PHASE3_VESSEL_OVERSAMPLE_PROB=0.35
export TN_VESSEL_LOSS_WEIGHT=0.75
# 不再 export TN_OVERSAMPLE_FOREGROUND_PERCENT, 让 CLI 默认 0.85 生效
export TN_SEG_DROPOUT_P=0.15

LOG_DIR="${nnUNet_results}"
mkdir -p "$LOG_DIR"
LOG="${LOG_DIR}/train_scratch_gt100_v2_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

"${PYTHON:-python}" train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --loc_arch attn \
  --seg_patch_size 96 96 96 \
  --seg_bs 4 \
  --phase1_epochs 0 \
  --phase2_epochs 0 \
  --phase3_epochs 1000 \
  --phase3_warmup_epochs 200 \
  --num_iters_phase3 200 \
  --num_val_iters_phase3 30 \
  --phase3_val_full \
  --phase3_val_cover 4 \
  --val_interval 5 \
  --disable_inner_dice \
  --smooth_sigma 0 \
  --loc_loss_weight 0.2 \
  --loc_phase3_lr 5e-4 \
  --loc_phase3_lr_schedule cosine \
  --loc_phase3_lr_min_ratio 0.1 \
  --phase3_min_gt_mix 1.0 \
  --phase3_fg_aux_weight 0.0 \
  --loss focal_tversky \
  --ft_alpha 0.7 \
  --ft_beta 0.3 \
  --ft_gamma 1.333 \
  --oversample_foreground_percent 0.85 \
  2>&1 | tee "$LOG"

echo "[done] log: $LOG"
