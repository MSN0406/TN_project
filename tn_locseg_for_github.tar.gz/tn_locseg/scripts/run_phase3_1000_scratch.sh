#!/usr/bin/env bash
set -euo pipefail

ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
TS="$(date +%Y%m%d_%H%M%S)"
LOG="${ROOT}/train_phase3_1000_scratch_${TS}.log"

cd "${ROOT}"
export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_p3_1000_scratch"
# 默认用空闲卡；覆盖示例: CUDA_VISIBLE_DEVICES=3 bash ...
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-2}"

"${PYTHON:-python}" train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --phase1_epochs 0 \
  --phase2_epochs 0 \
  --phase3_epochs 1000 \
  --phase3_warmup_epochs 40 \
  --smooth_sigma 1.0 \
  --seg_bs 8 \
  --num_iters_phase3 60 \
  --num_val_iters_phase3 30 \
  --val_interval 5 \
  --inner_dice_crop 48 \
  |& tee "${LOG}"

echo "[done] log: ${LOG}"
