#!/usr/bin/env bash
# 标准 nnUNetv2 训练 on Dataset096_TN_Crop96 (96³ TN crops)
# 纯 seg, 不带 loc head — 看看仅 seg 在 cropped 上能跑到多少 dice
# 这是历史 0.97 dice 那个 setup 的"标准化版", 用作天花板基准

set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-3}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_d096_phase2_standard_20260504"

# 关闭 nnUNet 的 torch.compile (动态 shape 易卡)
export nnUNet_compile="f"

LOG_DIR="${nnUNet_results}"
mkdir -p "$LOG_DIR"
LOG="${LOG_DIR}/train_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

# 标准 nnUNetv2 训练: dataset_id=096, config=3d_fullres, fold=0
# 默认 nnUNetTrainer, 1000 epochs, 250 train iter/epoch, 50 val iter/epoch
"${PYTHON:-python}" \
  nnUNetv2_train 096 3d_fullres 0 2>&1 | tee "$LOG"

echo "[done] log: $LOG"
