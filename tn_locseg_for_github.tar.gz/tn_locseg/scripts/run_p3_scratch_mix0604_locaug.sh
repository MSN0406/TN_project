#!/usr/bin/env bash
# Phase3 from scratch, mix0604 + gentle loc augmentation (vs run_p3_scratch_mix0604_v3.sh)
# 目的: 测试 inhouse 训练时加 loc aug 是否提高 OOD (OpenNeuro) 泛化能力
#
# 区别于 v3:
#   - TN_LOC_PHASE3_AUG=1 (loc 输入加 affine + intensity aug)
#   - gentle 参数: prob 0.3, ±5°, scale 0.95-1.05, gamma_prob 0.15
#     (上次 strong aug ±15°/prob 0.7 在 fine-tune 时 catastrophic forgetting)
#
# 期望对比 (vs v3 无 aug):
#   inhouse val dice:        0.63 → 0.62-0.65  (相当或微涨)
#   OpenNeuro zero-shot:     0.001 → 0.05-0.20  (主要改善)
#   OpenNeuro fine-tune 起点: 更好

set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-1}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_p3_scratch_mix0604_locaug_20260512"

export TN_WB_TARGET_SPACING=1,1,1
export TN_WB_USE_PLANS_FG_NORM=0
export TN_WB_NORM_CLIP=0
export TN_WB_CROP_PADDING=border

export TN_PHASE3_VAL_USE_GT_CROP=1
export TN_PHASE3_VESSEL_OVERSAMPLE_PROB=0.35
export TN_VESSEL_LOSS_WEIGHT=0
export TN_SEG_DROPOUT_P=0.15

# === 关键新增: loc input 加 gentle aug ===
export TN_LOC_PHASE3_AUG=1
export TN_LOC_AUG_AFFINE_PROB=0.3
export TN_LOC_AUG_MAX_ROTATE_DEG=5
export TN_LOC_AUG_SCALE_MIN=0.95
export TN_LOC_AUG_SCALE_MAX=1.05
export TN_LOC_AUG_GAMMA_PROB=0.15

LOG_DIR="${nnUNet_results}"
mkdir -p "$LOG_DIR"
LOG="${LOG_DIR}/train_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

"${PYTHON:-python}" train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --loc_arch attn \
  --seg_patch_size 96 96 96 \
  --seg_bs 4 \
  --phase1_epochs 0 \
  --phase2_epochs 0 \
  --phase3_epochs 1000 \
  --phase3_warmup_epochs 200 \
  --num_iters_phase3 200 \
  --num_val_iters_phase3 30 \
  --phase3_val_full \
  --phase3_val_cover 4 \
  --val_interval 5 \
  --disable_inner_dice \
  --smooth_sigma 0 \
  --loc_loss_weight 0.2 \
  --loc_phase3_lr 5e-4 \
  --loc_phase3_lr_schedule cosine \
  --loc_phase3_lr_min_ratio 0.1 \
  --phase3_min_gt_mix 0.6 \
  --phase3_fg_aux_weight 0.0 \
  --loss default \
  --oversample_foreground_percent 0.85 \
  2>&1 | tee "$LOG"

echo "[done] log: $LOG"
