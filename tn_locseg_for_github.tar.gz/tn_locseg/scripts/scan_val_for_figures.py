"""
Run inference on all in-house val cases for a single checkpoint and dump:
  - CSV with per-case nerve/vessel dice + loc_err (vox & mm) + ipsi/contra tag
  - axial-slice + centroid samples for 3 representative cases (low/median/high err)
Output dir layout:
  out_dir/
    val_dice_per_case.csv
    sample_low.npz   (image_slice, gt_xy, pred_xy, case_name, err_mm)
    sample_med.npz
    sample_high.npz

The numeric / pre-processing setup mirrors scripts/scan_all_val_dice.py exactly,
so the loc_err numbers are produced from the same whole-brain pipeline used in training.
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import os, sys, json, argparse
import numpy as np
import torch
import torch.nn.functional as F
import nibabel as nib

sys.path.insert(0, REPO_ROOT)


def project_patch(patch, ps, ctr, resamp_shape, native_shape):
    full = np.zeros(tuple(resamp_shape), dtype=patch.dtype)
    half = [s // 2 for s in ps]
    lo, hi, sl, sh = [], [], [], []
    for d in range(3):
        c = int(ctr[d]); lo_f = c - half[d]; hi_f = lo_f + ps[d]
        lo_c = max(0, lo_f); hi_c = min(int(resamp_shape[d]), hi_f)
        if hi_c <= lo_c: return np.zeros(native_shape, dtype=patch.dtype)
        lo.append(lo_c); hi.append(hi_c); sl.append(lo_c - lo_f); sh.append(sl[-1] + (hi_c - lo_c))
    full[lo[0]:hi[0], lo[1]:hi[1], lo[2]:hi[2]] = patch[sl[0]:sh[0], sl[1]:sh[1], sl[2]:sh[2]]
    if tuple(int(x) for x in resamp_shape) == tuple(int(x) for x in native_shape): return full
    t = torch.from_numpy(full.astype(np.float32)).view(1, 1, *resamp_shape)
    out = F.interpolate(t, size=tuple(int(x) for x in native_shape), mode='nearest')[0, 0].numpy()
    return np.round(out).astype(patch.dtype)


def gt_to_native(prep_name, nnunet_key, native_shape, spacing_prep):
    PREP = os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_preprocessed/Dataset001_TN')
    seg_nii = nib.load(f'{PREP}/gt_segmentations/{nnunet_key}.nii.gz')
    seg = np.rint(seg_nii.get_fdata()).astype(np.int64)
    spacing_nnu = np.array(seg_nii.header.get_zooms()[:3], dtype=np.float64)
    target_shape = np.maximum(1, np.round(np.array(seg.shape) * spacing_nnu / spacing_prep).astype(int))
    seg_t = torch.from_numpy(seg.astype(np.float32)).view(1, 1, *seg.shape)
    seg_t = F.interpolate(seg_t, size=tuple(int(x) for x in target_shape), mode='nearest')
    seg_resamp = torch.round(seg_t[0, 0]).long().numpy()
    centroid = np.load(os.path.join(REPO_ROOT, f'prepared_data/{prep_name}/centroid.npy')).astype(np.float64)
    center = np.round(centroid).astype(int); half = target_shape // 2
    full_native = np.zeros(native_shape, dtype=np.uint8)
    def emb(c, h, t, dim):
        lf = c - h; hf = lf + t
        lc = max(0, int(lf)); hc = min(int(dim), int(hf))
        if hc <= lc: return None, None
        sl = lc - int(lf); sh = sl + (hc - lc)
        return slice(lc, hc), slice(sl, sh)
    s = [emb(center[i], half[i], target_shape[i], native_shape[i]) for i in range(3)]
    if any(x[0] is None for x in s): return full_native
    full_native[s[0][0], s[1][0], s[2][0]] = np.clip(seg_resamp[s[0][1], s[1][1], s[2][1]], 0, 255).astype(np.uint8)
    return full_native


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--out_dir', required=True)
    ap.add_argument('--gpu', type=int, default=0)
    args = ap.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)

    os.environ.setdefault('nnUNet_raw', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_raw'))
    os.environ.setdefault('nnUNet_preprocessed', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_preprocessed'))
    os.environ.setdefault('TN_PREPARED_DATA_DIR', os.path.join(REPO_ROOT, 'prepared_data'))
    os.environ.update({
        'TN_WB_TARGET_SPACING': '1,1,1', 'TN_WB_USE_PLANS_FG_NORM': '0',
        'TN_WB_NORM_CLIP': '0', 'TN_WB_CROP_PADDING': 'border',
        'TN_PHASE3_VAL_USE_GT_CROP': '1', 'TN_VESSEL_LOSS_WEIGHT': '0',
        'TN_SEG_DROPOUT_P': '0', 'TN_PHASE3_SEG_AUG': '0',
        'TN_PHASE1_EPOCHS': '0', 'TN_PHASE2_EPOCHS': '0', 'TN_PHASE3_EPOCHS': '1000',
        'TN_NUM_ITERS_PER_EPOCH_PHASE3': '200', 'TN_NUM_VAL_ITERS_PER_EPOCH_PHASE3': '30',
        'TN_INNER_DICE_ENABLE': '0', 'TN_OVERSAMPLE_FOREGROUND_PERCENT': '0.85',
    })
    from batchgenerators.utilities.file_and_folder_operations import join, load_json
    from nnunetv2.paths import nnUNet_preprocessed
    from nnunet_loc_trainer import nnUNetTrainerLoc

    plans = load_json(join(nnUNet_preprocessed, 'Dataset001_TN', 'nnUNetPlans.json'))
    dataset_json = load_json(join(nnUNet_preprocessed, 'Dataset001_TN', 'dataset.json'))
    plans['configurations']['3d_fullres']['patch_size'] = [96, 96, 96]
    plans['configurations']['3d_fullres']['batch_size'] = 4
    device = torch.device('cuda', args.gpu)
    trainer = nnUNetTrainerLoc(plans=plans, configuration='3d_fullres', fold=0, dataset_json=dataset_json, device=device)
    trainer.initialize()
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    trainer.network.load_state_dict(ckpt['network_weights'])
    trainer.network.eval()
    mod = trainer.network.module if hasattr(trainer.network, 'module') else trainer.network
    if hasattr(mod, '_orig_mod'): mod = mod._orig_mod
    print(f'[ckpt] {args.ckpt}  epoch={ckpt.get("current_epoch")}')

    splits = load_json(join(nnUNet_preprocessed, 'Dataset001_TN', 'splits_final.json'))
    val_keys = splits[0]['val']
    case_mapping = json.load(open(join(os.environ['nnUNet_raw'], 'Dataset001_TN', 'case_mapping.json')))
    print(f'扫描 {len(val_keys)} 个 val case...')

    # Spacing of the whole-brain input (we set TN_WB_TARGET_SPACING=1,1,1)
    SPACING_MM = 1.0

    rows = ['case,prep_name,side,fg1_dice,fg2_dice,loc_err_vox,loc_err_mm']
    per_case_data = {}  # case -> (loc_err_mm, gt_vox, pr_vox, wb_shape, slice_axial, slice_index_z)
    for ci, case in enumerate(val_keys):
        prep_name = case_mapping[case]
        side = 'ipsi' if prep_name.endswith('_ipsi') else ('contra' if prep_name.endswith('_contra') else 'unknown')
        try:
            with torch.no_grad():
                wb_tensor, wb_shapes, gt_centroid_norm = trainer._build_whole_brain_batch([case])
                wb_tensor = wb_tensor.to(device); gt_centroid_norm = gt_centroid_norm.to(device)
                hm_l, hm_r, c_l, c_r = trainer._loc_forward(wb_tensor, mod)
                pred_centroid = trainer._select_centroid_by_gt_side(c_l, c_r, gt_centroid_norm,
                    wb_shapes=wb_shapes, padded_shape=wb_tensor.shape[2:])
                centroid = trainer._round_centroid_to_voxel(pred_centroid, wb_tensor.shape[2:])
                seg_input = trainer._crop_with_centroid(wb_tensor, centroid, (96, 96, 96))
                logits = mod.forward_seg(seg_input)
                if isinstance(logits, (list, tuple)): logits = logits[0]
                pred_patch = logits.argmax(dim=1)[0].cpu().numpy().astype(np.uint8)
                scale = (torch.tensor(wb_tensor.shape[2:], device=device) - 1).float()
                crop_vox = (centroid * scale).cpu().numpy()[0]
                gt_vox = (gt_centroid_norm * scale).cpu().numpy()[0]
                pr_vox = (pred_centroid * scale).cpu().numpy()[0]
                loc_err = float(np.linalg.norm(gt_vox - pr_vox))
                loc_err_mm = loc_err * SPACING_MM
                wb_shape = tuple(int(x) for x in wb_tensor.shape[2:])
                wb_np = wb_tensor[0, 0].cpu().numpy()  # (D,H,W) at 1mm iso
                z_idx = int(round(float(gt_vox[2])))
                z_idx = max(0, min(wb_shape[2]-1, z_idx))
                slice_ax = wb_np[:, :, z_idx]  # (D, H) axial slice (since dim2 is last)
            info = json.load(open(os.path.join(REPO_ROOT, f'prepared_data/{prep_name}/info.json')))
            img_nii = nib.load(info['nii_path'])
            native_shape = tuple(int(x) for x in img_nii.shape[:3])
            spacing_prep = np.array(img_nii.header.get_zooms()[:3], dtype=np.float64)

            pred_native = project_patch(pred_patch, (96, 96, 96), crop_vox, wb_shape, native_shape)
            gt_native = gt_to_native(prep_name, case, native_shape, spacing_prep)

            fg1_g = (gt_native == 1); fg1_p = (pred_native == 1)
            fg1_tp = int((fg1_g & fg1_p).sum()); fg1_fp = int((fg1_p & ~fg1_g).sum()); fg1_fn = int((fg1_g & ~fg1_p).sum())
            fg1_d = 2*fg1_tp / max(1, 2*fg1_tp + fg1_fp + fg1_fn)
            fg2_g = (gt_native == 2); fg2_p = (pred_native == 2)
            fg2_tp = int((fg2_g & fg2_p).sum()); fg2_fp = int((fg2_p & ~fg2_g).sum()); fg2_fn = int((fg2_g & ~fg2_p).sum())
            fg2_d = 2*fg2_tp / max(1, 2*fg2_tp + fg2_fp + fg2_fn)
            rows.append(f'{case},{prep_name},{side},{fg1_d:.4f},{fg2_d:.4f},{loc_err:.3f},{loc_err_mm:.3f}')
            per_case_data[case] = {
                'prep_name': prep_name, 'side': side, 'loc_err_mm': loc_err_mm,
                'gt_vox': gt_vox, 'pr_vox': pr_vox, 'wb_shape': wb_shape,
                'slice_ax': slice_ax.astype(np.float32),
            }
            print(f'[{ci+1:3d}/{len(val_keys)}] {case} {side:6s}: FG1={fg1_d:.3f} FG2={fg2_d:.3f} err={loc_err:.2f}vox / {loc_err_mm:.2f}mm')
        except Exception as e:
            print(f'[{ci+1:3d}] {case} FAILED: {e}')
            rows.append(f'{case},{prep_name},{side},FAIL,FAIL,FAIL,FAIL')

    csv_path = os.path.join(args.out_dir, 'val_dice_per_case.csv')
    with open(csv_path, 'w') as f: f.write('\n'.join(rows))
    print(f'\n[saved] {csv_path}  ({len(rows)-1} rows)')

    # ---- pick 3 representative cases by loc_err (low / median / high) for axial samples ----
    errs = sorted([(d['loc_err_mm'], c) for c, d in per_case_data.items()])
    if len(errs) >= 3:
        sample_specs = [
            ('low',  errs[len(errs)//8]),                   # ~12.5th percentile
            ('med',  errs[len(errs)//2]),                   # median
            ('high', errs[-(len(errs)//8 + 1)]),            # ~87.5th percentile
        ]
        for tag, (err, case) in sample_specs:
            d = per_case_data[case]
            out = os.path.join(args.out_dir, f'sample_{tag}.npz')
            np.savez(out,
                case=case, prep_name=d['prep_name'], side=d['side'],
                err_mm=d['loc_err_mm'], wb_shape=np.array(d['wb_shape']),
                gt_vox=d['gt_vox'], pr_vox=d['pr_vox'], slice_ax=d['slice_ax'],
            )
            print(f'[sample {tag:4s}] {case} ({d["side"]}) err={err:.2f}mm -> {out}')

    print('\n[done]')


if __name__ == '__main__':
    main()
