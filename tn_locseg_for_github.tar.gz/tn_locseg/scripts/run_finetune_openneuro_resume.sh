#!/usr/bin/env bash
set -euo pipefail
cd ${ROOT}
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

OUT="${ROOT}/nnUNet_data/nnUNet_results_openneuro_finetune_resume_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT"

"${PYTHON:-python}" \
  ${ROOT}/scripts/finetune_openneuro.py \
  --init_ckpt ${ROOT}/nnUNet_data/nnUNet_results_openneuro_finetune_20260509_234533/finetune_latest.pth \
  --split_json ${ROOT}/nnUNet_data/openneuro_finetune_split.json \
  --output_dir "$OUT" \
  --gpu 0 \
  --epochs 100 \
  --iters_per_epoch 64 \
  --seg_lr 5e-4 \
  --loc_lr 1e-4 \
  --bs 4 \
  --val_interval 2 \
  2>&1 | tee "$OUT/run.log"
echo "[done] log: $OUT/run.log"
