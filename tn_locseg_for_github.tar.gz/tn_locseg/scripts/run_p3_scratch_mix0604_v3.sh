#!/usr/bin/env bash
# Phase3 from scratch, mix0604 — v3 (剥离干扰梯度, 用 D096 验证过的 loss 配置)
# 关键改动 vs v2:
#   #23: 移除两个干扰主分割梯度的 aux:
#        - --loss default            (DC + CE 1:1, 与 D096 stock nnUNet 一致, 不用 Focal Tversky)
#        - TN_VESSEL_LOSS_WEIGHT=0   (关掉 vessel aux BCE, 它一直在压 class 2 logit)
# 保留:
#   #22 b/c   wb norm clip + crop padding=border       (loc 已收敛到 1.2 vox, 留着)
#   #21 P1    oversample_foreground_percent=0.85       (无害)
#   phase3_val_full + cover 4                          (低噪音 dice)
#   splits MRN-disjoint
#
# 与 v3 gt100 构成 A/B 对比: mix vs 纯 GT 质心

set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_p3_scratch_mix0604_v3_20260506"

export TN_WB_TARGET_SPACING=1,1,1
# #24 fix: D001 是 MRI 不是 CT, 必须用 per-case 全图 z-score (与 D096 stock 一致),
# 不能用 CT-style 全局 plans-fg-norm + clip.
export TN_WB_USE_PLANS_FG_NORM=0
export TN_WB_NORM_CLIP=0                  # 关 (CT-only)
export TN_WB_CROP_PADDING=border          # #22 c (跨 modality 都对)

export TN_PHASE3_VAL_USE_GT_CROP=1
export TN_PHASE3_VESSEL_OVERSAMPLE_PROB=0.35
export TN_VESSEL_LOSS_WEIGHT=0            # #23 关掉 vessel aux (从 0.75 → 0)
# 不 export TN_OVERSAMPLE_FOREGROUND_PERCENT, 用 CLI 默认 0.85
export TN_SEG_DROPOUT_P=0.15

LOG_DIR="${nnUNet_results}"
mkdir -p "$LOG_DIR"
LOG="${LOG_DIR}/train_scratch_mix0604_v3_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

"${PYTHON:-python}" train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --continue_training \
  --loc_arch attn \
  --seg_patch_size 96 96 96 \
  --seg_bs 4 \
  --phase1_epochs 0 \
  --phase2_epochs 0 \
  --phase3_epochs 1000 \
  --phase3_warmup_epochs 200 \
  --num_iters_phase3 200 \
  --num_val_iters_phase3 30 \
  --phase3_val_full \
  --phase3_val_cover 4 \
  --val_interval 5 \
  --disable_inner_dice \
  --smooth_sigma 0 \
  --loc_loss_weight 0.2 \
  --loc_phase3_lr 5e-4 \
  --loc_phase3_lr_schedule cosine \
  --loc_phase3_lr_min_ratio 0.1 \
  --phase3_min_gt_mix 0.6 \
  --phase3_fg_aux_weight 0.0 \
  --loss default \
  --oversample_foreground_percent 0.85 \
  2>&1 | tee "$LOG"

echo "[done] log: $LOG"
