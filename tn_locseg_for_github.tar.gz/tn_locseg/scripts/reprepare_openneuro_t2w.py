"""
reprepare_openneuro_t2w.py
==========================
把 OpenNeuro 80 个 case 的 prepared_data 从 T1w 切换到 T2w.

为什么: inhouse train 用的是 CISS (T2 加权, CSF 亮, TN 暗), OpenNeuro 用 T1w
(T1 加权, CSF 暗, TN 几乎不可见). 物理成像方式不同, 模型无法迁移. T2w 跟 CISS
都是 T2 加权, 物理类似, 期望迁移效果好得多.

但 T1w 跟 T2w 不是 co-registered (shape/affine 不同), 所以不能直接换 nii_path,
需要:
  - centroid 从 T1w voxel → world RAS → T2w voxel 变换
  - 重新算 wb_shape
  - mask_aligned.nii.gz 不变 (它在物理 1mm 空间, 不依赖 T1w/T2w)

输入: prepared_data/sub-*/  (T1w-based)
输出: prepared_data_openneuro_t2w/sub-*/  (T2w-based, 同样的标注)
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import os, json, shutil, sys
import numpy as np
import nibabel as nib


def transform_voxel_t1w_to_t2w(centroid_t1w_vox, t1w_affine, t2w_affine):
    """
    centroid_t1w_vox: (3,) voxel index in T1w
    Convert: T1w_voxel -> world_RAS -> T2w_voxel
    Returns: T2w voxel index (float, can be rounded later)
    """
    # T1w voxel to world RAS: world = T1w_affine @ [voxel, 1]
    vox_h = np.append(centroid_t1w_vox, 1.0)
    world = t1w_affine @ vox_h  # (4,)
    # World RAS to T2w voxel: voxel = inv(T2w_affine) @ [world, 1]
    t2w_inv = np.linalg.inv(t2w_affine)
    vox_t2w = t2w_inv @ world  # (4,)
    return vox_t2w[:3]


def main():
    PREP_T1W = os.path.join(REPO_ROOT, 'prepared_data')
    PREP_T2W = os.path.join(REPO_ROOT, 'prepared_data_openneuro_t2w')
    OPENNEURO_ROOT = '${TN_OPENNEURO_DIR}'

    sub_names = sorted([d for d in os.listdir(PREP_T1W) if d.startswith('sub-')])
    print(f'重做 {len(sub_names)} 个 OpenNeuro case 从 T1w → T2w')
    os.makedirs(PREP_T2W, exist_ok=True)

    failed = []
    for ci, name in enumerate(sub_names):
        try:
            t1w_dir = os.path.join(PREP_T1W, name)
            t2w_dir = os.path.join(PREP_T2W, name)
            os.makedirs(t2w_dir, exist_ok=True)

            # 1. 读 T1w info
            info_t1w = json.load(open(os.path.join(t1w_dir, 'info.json')))
            t1w_path = info_t1w['nii_path']
            assert 'T1w' in t1w_path, f'unexpected: {t1w_path}'

            # 2. 找对应 T2w 路径
            patient = name.split('_')[0]  # sub-010
            anat_dir = os.path.join(OPENNEURO_ROOT, patient, 'anat')
            t2w_files = [f for f in os.listdir(anat_dir) if f.endswith('T2w.nii.gz')]
            if not t2w_files:
                raise FileNotFoundError(f'no T2w for {patient}')
            t2w_path = os.path.join(anat_dir, t2w_files[0])

            # 3. 读两个 nifti 的 affine
            t1w_nii = nib.load(t1w_path)
            t2w_nii = nib.load(t2w_path)

            # 4. centroid 变换
            centroid_t1w = np.load(os.path.join(t1w_dir, 'centroid.npy')).astype(np.float64)
            centroid_t2w = transform_voxel_t1w_to_t2w(centroid_t1w, t1w_nii.affine, t2w_nii.affine)
            # 取整 (跟原版 centroid 一致, 原版 center_ras 也是 int)
            centroid_t2w_int = np.round(centroid_t2w).astype(np.int64)

            # 5. 写新 centroid + info
            np.save(os.path.join(t2w_dir, 'centroid.npy'), centroid_t2w_int.astype(np.float64))

            new_info = dict(info_t1w)
            new_info['nii_path'] = t2w_path
            new_info['wb_shape'] = list(int(x) for x in t2w_nii.shape[:3])
            new_info['center_ras'] = [int(x) for x in centroid_t2w_int]
            # 保留 center_csv 但其实没用 (我们 trainer 用 center_ras)
            with open(os.path.join(t2w_dir, 'info.json'), 'w') as f:
                json.dump(new_info, f, indent=2)

            # 6. mask_aligned 不变, 直接拷贝
            shutil.copy(os.path.join(t1w_dir, 'mask_aligned.nii.gz'),
                        os.path.join(t2w_dir, 'mask_aligned.nii.gz'))

            print(f'[{ci+1:3d}/{len(sub_names)}] {name}: '
                  f'T1w shape={tuple(t1w_nii.shape[:3])} centroid={centroid_t1w.astype(int).tolist()} '
                  f'→ T2w shape={tuple(t2w_nii.shape[:3])} centroid={centroid_t2w_int.tolist()}')
        except Exception as e:
            print(f'[{ci+1}] {name} FAILED: {e}')
            failed.append((name, str(e)))

    print(f'\n=== 完成 ===')
    print(f'成功: {len(sub_names) - len(failed)}/{len(sub_names)}')
    if failed:
        print(f'失败:')
        for n, e in failed: print(f'  {n}: {e}')
    print(f'\nT2w prepared_data: {PREP_T2W}/')


if __name__ == '__main__':
    main()
