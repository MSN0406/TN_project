"""
infer_phase3_to_nii.py
======================
Load a phase3 ckpt, run inference on val cases, dump NIfTI files for ITK-SNAP/Slicer:
  <output_dir>/<case>/
    image_native.nii.gz   原始全脑 image (与 prepared_data 同 spacing/affine, 直接拷贝)
    gt_native.nii.gz      GT label 嵌入到全脑 (与 image 对齐)
    pred_native.nii.gz    模型预测 (与 image 对齐, 0=bg, 1=nerve, 2=vessel)
    image_patch.nii.gz    96³ patch image (1mm spacing, identity affine), 网络见到的
    gt_patch.nii.gz       96³ GT patch (1mm)
    pred_patch.nii.gz     96³ pred patch (1mm)

用 ITK-SNAP 打开:
  itksnap -g image_native.nii.gz -s pred_native.nii.gz   # 主图 + 预测 overlay
  也可以载入 gt_native.nii.gz 作为额外 segmentation 比对

裁剪行为:
  - 用网络预测的 centroid (deployment 模式), 不是 GT centroid
  - 想要 GT-crop oracle 模式加 --use_gt_centroid
"""
import os
REPO_ROOT = os.environ.get('TN_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import argparse, os, sys, json
import numpy as np
import torch
import torch.nn.functional as F
import nibabel as nib

sys.path.insert(0, REPO_ROOT)


def project_patch_to_native(patch_np, patch_size, center_vox_in_resamp, resamp_shape, native_shape, spacing_resamp, spacing_native, is_label=True):
    """
    把 96^3 patch (在 resampled 1mm 空间) 嵌回 native spacing 全脑.
    1. 先在 resamp_shape 大小的 zero volume 里, 以 center_vox 为中心放 patch
    2. 然后 nearest-neighbor resample 回 native_shape
    """
    # Stage 1: place patch in resamp-sized zero volume
    full_resamp = np.zeros(tuple(resamp_shape), dtype=patch_np.dtype)
    half = [s // 2 for s in patch_size]
    lo, hi = [], []
    src_lo, src_hi = [], []
    for d in range(3):
        c = int(center_vox_in_resamp[d])
        lo_full = c - half[d]
        hi_full = lo_full + patch_size[d]
        lo_clip = max(0, lo_full); hi_clip = min(int(resamp_shape[d]), hi_full)
        if hi_clip <= lo_clip:
            return np.zeros(native_shape, dtype=patch_np.dtype)
        lo.append(lo_clip); hi.append(hi_clip)
        src_lo.append(lo_clip - lo_full)
        src_hi.append(src_lo[-1] + (hi_clip - lo_clip))
    full_resamp[lo[0]:hi[0], lo[1]:hi[1], lo[2]:hi[2]] = \
        patch_np[src_lo[0]:src_hi[0], src_lo[1]:src_hi[1], src_lo[2]:src_hi[2]]

    # Stage 2: resample to native shape
    if tuple(int(x) for x in resamp_shape) == tuple(int(x) for x in native_shape):
        return full_resamp
    t = torch.from_numpy(full_resamp.astype(np.float32)).view(1, 1, *resamp_shape)
    mode = 'nearest' if is_label else 'trilinear'
    kwargs = dict(size=tuple(int(x) for x in native_shape), mode=mode)
    if mode == 'trilinear':
        kwargs['align_corners'] = False
    out = F.interpolate(t, **kwargs)[0, 0].numpy()
    if is_label:
        out = np.round(out).astype(patch_np.dtype)
    return out


def infer_one_case(trainer, case_key, device, use_gt_centroid):
    mod = trainer.network.module if hasattr(trainer.network, 'module') else trainer.network
    if hasattr(mod, '_orig_mod'):
        mod = mod._orig_mod
    with torch.no_grad():
        wb_tensor, wb_shapes, gt_centroid_norm = trainer._build_whole_brain_batch([case_key])
        wb_tensor = wb_tensor.to(device)
        gt_centroid_norm = gt_centroid_norm.to(device)
        # Loc forward (always, to report loc_err)
        hm_l, hm_r, c_l, c_r = trainer._loc_forward(wb_tensor, mod)
        pred_centroid = trainer._select_centroid_by_gt_side(
            c_l, c_r, gt_centroid_norm, wb_shapes=wb_shapes, padded_shape=wb_tensor.shape[2:]
        )
        # Choose centroid
        crop_centroid = gt_centroid_norm if use_gt_centroid else pred_centroid
        crop_centroid = trainer._round_centroid_to_voxel(crop_centroid, wb_tensor.shape[2:])
        # Forward
        seg_input = trainer._crop_with_centroid(wb_tensor, crop_centroid, (96, 96, 96))
        seg_target = trainer._load_and_crop_gt_label_patch(
            [case_key], wb_shapes, wb_tensor.shape[2:], crop_centroid, (96, 96, 96)
        )
        logits = mod.forward_seg(seg_input)
        if isinstance(logits, (list, tuple)):
            logits = logits[0]
        pred = logits.argmax(dim=1)[0].cpu().numpy().astype(np.uint8)
        gt = seg_target[0, 0].cpu().numpy().astype(np.uint8)
        img = seg_input[0, 0].cpu().numpy().astype(np.float32)
        # Centroid in voxel coords
        scale = (torch.tensor(wb_tensor.shape[2:], device=device) - 1).float()
        crop_vox = (crop_centroid * scale).cpu().numpy()[0]
        gt_vox = (gt_centroid_norm * scale).cpu().numpy()[0]
        pr_vox = (pred_centroid * scale).cpu().numpy()[0]
        loc_err_vox = float(np.linalg.norm(gt_vox - pr_vox))
        # Per-class dice on patch
        dice = {}
        for c in (1, 2):
            tp = ((pred == c) & (gt == c)).sum()
            fp = ((pred == c) & (gt != c)).sum()
            fn = ((pred != c) & (gt == c)).sum()
            dice[f'FG{c}'] = 2 * tp / max(1, 2 * tp + fp + fn)
        return dict(img_patch=img, gt_patch=gt, pred_patch=pred,
                    crop_vox=crop_vox, dice=dice, loc_err_vox=loc_err_vox,
                    resamp_shape=tuple(int(x) for x in wb_tensor.shape[2:]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True)
    ap.add_argument('--cases', nargs='+', default=None,
                    help='specific keys; default = first N val cases')
    ap.add_argument('--n', type=int, default=8, help='take first N val cases if --cases not given')
    ap.add_argument('--output_dir', required=True)
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--use_gt_centroid', action='store_true',
                    help='oracle mode (用 GT centroid 裁), default = pred centroid (deployment)')
    args = ap.parse_args()

    # Env (matching v3 mix0604 config)
    os.environ.setdefault('nnUNet_raw', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_raw'))
    os.environ.setdefault('nnUNet_preprocessed', os.path.join(REPO_ROOT, 'nnUNet_data/nnUNet_preprocessed'))
    os.environ.setdefault('TN_PREPARED_DATA_DIR', os.path.join(REPO_ROOT, 'prepared_data'))
    os.environ['TN_WB_TARGET_SPACING'] = '1,1,1'
    os.environ['TN_WB_USE_PLANS_FG_NORM'] = '0'
    os.environ['TN_WB_NORM_CLIP'] = '0'
    os.environ['TN_WB_CROP_PADDING'] = 'border'
    os.environ['TN_PHASE3_VAL_USE_GT_CROP'] = '1'
    os.environ['TN_VESSEL_LOSS_WEIGHT'] = '0'
    os.environ['TN_SEG_DROPOUT_P'] = '0'
    os.environ['TN_PHASE3_SEG_AUG'] = '0'
    os.environ['TN_PHASE1_EPOCHS'] = '0'
    os.environ['TN_PHASE2_EPOCHS'] = '0'
    os.environ['TN_PHASE3_EPOCHS'] = '1000'
    os.environ['TN_NUM_ITERS_PER_EPOCH_PHASE3'] = '200'
    os.environ['TN_NUM_VAL_ITERS_PER_EPOCH_PHASE3'] = '30'
    os.environ['TN_INNER_DICE_ENABLE'] = '0'
    os.environ['TN_OVERSAMPLE_FOREGROUND_PERCENT'] = '0.85'

    from nnunetv2.utilities.dataset_name_id_conversion import maybe_convert_to_dataset_name
    from batchgenerators.utilities.file_and_folder_operations import join, load_json
    from nnunetv2.paths import nnUNet_preprocessed
    from nnunet_loc_trainer import nnUNetTrainerLoc

    dataset_name = maybe_convert_to_dataset_name('Dataset001_TN')
    plans = load_json(join(nnUNet_preprocessed, dataset_name, 'nnUNetPlans.json'))
    dataset_json = load_json(join(nnUNet_preprocessed, dataset_name, 'dataset.json'))
    plans['configurations']['3d_fullres']['patch_size'] = [96, 96, 96]
    plans['configurations']['3d_fullres']['batch_size'] = 4

    device = torch.device('cuda', args.gpu) if torch.cuda.is_available() else torch.device('cpu')
    trainer = nnUNetTrainerLoc(plans=plans, configuration='3d_fullres', fold=0,
                               dataset_json=dataset_json, device=device)
    trainer.initialize()
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    trainer.network.load_state_dict(ckpt['network_weights'])
    trainer.network.eval()
    print(f'[infer] loaded ckpt epoch={ckpt.get("current_epoch")}, use_gt_centroid={args.use_gt_centroid}')

    # Pick cases
    splits = load_json(join(nnUNet_preprocessed, dataset_name, 'splits_final.json'))
    val_keys = splits[0]['val']
    if args.cases:
        cases = args.cases
    else:
        cases = list(val_keys[:args.n])
    print(f'[infer] cases ({len(cases)}): {cases}')

    case_mapping = json.load(open(join(os.environ['nnUNet_raw'], 'Dataset001_TN', 'case_mapping.json')))
    prepared_dir = os.environ['TN_PREPARED_DATA_DIR']

    os.makedirs(args.output_dir, exist_ok=True)
    summary = []
    for ci, case in enumerate(cases):
        print(f'[infer] {ci+1}/{len(cases)}: {case}')
        try:
            res = infer_one_case(trainer, case, device, args.use_gt_centroid)
        except Exception as e:
            print(f'  FAILED: {e}')
            continue
        # Load native image to get its affine + shape + native GT
        prep_name = case_mapping[case]
        info = json.load(open(join(prepared_dir, prep_name, 'info.json')))
        img_nii = nib.load(info['nii_path'])
        native_shape = tuple(int(x) for x in img_nii.shape[:3])
        spacing_native = np.array(img_nii.header.get_zooms()[:3], dtype=np.float64)
        spacing_resamp = np.array([1.0, 1.0, 1.0])
        # Centroid in resamp-space already from `res['crop_vox']`
        crop_vox_resamp = res['crop_vox']
        resamp_shape = res['resamp_shape']

        # Project pred + gt patch to native shape
        pred_native = project_patch_to_native(
            res['pred_patch'], (96, 96, 96), crop_vox_resamp, resamp_shape,
            native_shape, spacing_resamp, spacing_native, is_label=True,
        )
        gt_native = project_patch_to_native(
            res['gt_patch'], (96, 96, 96), crop_vox_resamp, resamp_shape,
            native_shape, spacing_resamp, spacing_native, is_label=True,
        )

        # Output dir per case
        case_out = join(args.output_dir, case)
        os.makedirs(case_out, exist_ok=True)

        # Native: same affine as original image
        img_data = img_nii.get_fdata().astype(np.float32)
        if img_data.ndim == 4: img_data = img_data[..., 0]
        nib.save(nib.Nifti1Image(img_data, img_nii.affine, img_nii.header), join(case_out, 'image_native.nii.gz'))
        nib.save(nib.Nifti1Image(gt_native, img_nii.affine, img_nii.header), join(case_out, 'gt_native.nii.gz'))
        nib.save(nib.Nifti1Image(pred_native, img_nii.affine, img_nii.header), join(case_out, 'pred_native.nii.gz'))

        # Patch-level (96^3, 1mm spacing, identity affine)
        patch_aff = np.eye(4); patch_aff[0, 0] = patch_aff[1, 1] = patch_aff[2, 2] = 1.0
        nib.save(nib.Nifti1Image(res['img_patch'], patch_aff), join(case_out, 'image_patch.nii.gz'))
        nib.save(nib.Nifti1Image(res['gt_patch'], patch_aff), join(case_out, 'gt_patch.nii.gz'))
        nib.save(nib.Nifti1Image(res['pred_patch'], patch_aff), join(case_out, 'pred_patch.nii.gz'))

        d = res['dice']
        summary.append(f'{case}: patch dice FG1={d["FG1"]:.3f} FG2={d["FG2"]:.3f}  loc_err={res["loc_err_vox"]:.2f} vox  -> {case_out}')
        print(f'  saved: {case_out}/  (dice FG1={d["FG1"]:.3f} FG2={d["FG2"]:.3f}, loc_err={res["loc_err_vox"]:.2f} vox)')

    print('\n=== summary ===')
    for s in summary: print(s)
    with open(join(args.output_dir, 'summary.txt'), 'w') as f:
        f.write('\n'.join(summary))


if __name__ == '__main__':
    main()
