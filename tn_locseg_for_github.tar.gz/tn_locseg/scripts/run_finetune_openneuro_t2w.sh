#!/usr/bin/env bash
# OpenNeuro fine-tune 用 T2w (而非 T1w) 数据
# 关键改动: TN_PREPARED_DATA_DIR 指向 prepared_data_openneuro_t2w/
set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-1}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

# === 关键: 用 T2w prepared_data ===
export TN_PREPARED_DATA_DIR="$ROOT/prepared_data_openneuro_t2w"
echo "[finetune] using prepared_data: $TN_PREPARED_DATA_DIR"

OUT="$ROOT/nnUNet_data/nnUNet_results_openneuro_finetune_t2w_$(date +%Y%m%d_%H%M%S)"
mkdir -p "$OUT"

"${PYTHON:-python}" \
  $ROOT/scripts/finetune_openneuro.py \
  --init_ckpt $ROOT/nnUNet_data/viz_snapshots/mix0604_v3_phase3_best_e110.pth \
  --split_json $ROOT/nnUNet_data/openneuro_finetune_split.json \
  --output_dir "$OUT" \
  --gpu 0 \
  --epochs 100 \
  --iters_per_epoch 64 \
  --seg_lr 5e-4 \
  --loc_lr 1e-4 \
  --bs 4 \
  --val_interval 2 \
  2>&1 | tee "$OUT/run.log"
echo "[done] log: $OUT/run.log"
