#!/usr/bin/env bash
# Phase3 续训 (方案 A, 无 vessel 过采样): 从 phase3_best 加载 + lr 减半
# 用法: bash scripts/continue_phase3_finetune_a.sh
# 默认使用 GPU0（空闲卡）；若需指定卡: CUDA_VISIBLE_DEVICES=4 bash scripts/continue_phase3_finetune_a.sh

set -euo pipefail
ROOT="${TN_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
cd "$ROOT"

# 未指定时使用空闲卡 0（与 B 常用 GPU3 错开）
export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0}"
echo "[GPU] CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES}"

export nnUNet_raw="${ROOT}/nnUNet_data/nnUNet_raw"
export nnUNet_preprocessed="${ROOT}/nnUNet_data/nnUNet_preprocessed"
export nnUNet_results="${ROOT}/nnUNet_data/nnUNet_results_phase3_retrain_lrlow_a"
export TN_SEG_CROP_SIZE=96
export TN_PHASE2_PRECOMPUTED_DIR="${ROOT}/precomputed_phase2_crop96_pred"

LOG="${ROOT}/train_phase3_continue_finetune_a_$(date +%Y%m%d_%H%M%S).log"
echo "Logging to $LOG"

conda run -n tnproject python train_nnunet_loc.py \
  --dataset Dataset001_TN \
  --config 3d_fullres \
  --fold 0 \
  --gpu 0 \
  --phase1_epochs 150 \
  --phase2_epochs 277 \
  --phase3_epochs 600 \
  --continue_training \
  --seg_lr 5e-4 \
  --seg_lr_schedule cosine \
  --seg_lr_min_ratio 0.05 \
  --loc_phase3_lr 5e-5 \
  --loc_phase3_lr_schedule cosine \
  --loc_phase3_lr_min_ratio 0.2 \
  --finetune_lr_scale 0.5 \
  --seg_bs 8 \
  --num_val_iters_phase3 20 \
  --num_iters_phase3 100 \
  --phase3_vessel_oversample_prob 0.0 \
  2>&1 | tee "$LOG"
