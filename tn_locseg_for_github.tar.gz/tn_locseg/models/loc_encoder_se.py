"""
loc_encoder_se.py
=================
定位编码器的 SE (Squeeze-and-Excitation) 变体 - 通道注意力替代空间 Attention Gate.

设计依据:
    - 2025 J Neurosurg 论文: SE-ResNet50 backbone 在 TN 分割上是 SOTA (Dice 0.775)
    - 2023 SEVB-Net Frontiers: SE + BottleNeck V-Net 专门为 TN 设计
    - 对定位任务, spatial attention gate 可能抑制 skip connection 的精细位置线索,
      而 SE channel attention 只调整通道权重, 保留空间细节

与 LocEncoder3D 的区别:
    - 移除 AttentionGate3D (skip connection 直接 concat)
    - 在每个 encoder 和 decoder stage 后加 SEBlock3D
    - 架构其余部分完全保持, 便于消融对比

输入/输出接口与 LocEncoder3D 完全一致:
    input: (B, 1, D, H, W)
    output: (heatmap_left, heatmap_right), 均为 (B, 1, D, H, W)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .loc_encoder import ResBlock3D


class SEBlock3D(nn.Module):
    """Squeeze-and-Excitation block for 3D features (Hu et al., CVPR 2018).

    Squeeze: 全局平均池化压缩空间维度 (B, C, D, H, W) → (B, C)
    Excitation: 两层 MLP + sigmoid 产生每个通道的权重
    Scale: 通道权重乘回原特征图
    """

    def __init__(self, channels, reduction=16):
        super().__init__()
        reduced = max(channels // reduction, 8)
        self.avg_pool = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, reduced, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(reduced, channels, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x):
        b, c, _, _, _ = x.shape
        s = self.avg_pool(x).view(b, c)
        s = self.fc(s).view(b, c, 1, 1, 1)
        return x * s


class LocEncoderSE3D(nn.Module):
    """
    LocEncoder 的 SE 变体:
      - Encoder: 每个 stage 后加 SE block (通道注意力)
      - Decoder: skip connection 直接 concat (无 spatial attention gate),
                 每个 decoder stage 后加 SE block
      - Heatmap heads: 同 LocEncoder3D, dual-head (left/right)

    参数:
        in_channels: 输入通道数
        channels: 每层通道数 (从浅到深)
        se_reduction: SE block 的 reduction ratio (默认 16)
    """

    def __init__(self, in_channels=1, channels=(16, 32, 64, 128, 256), se_reduction=16):
        super().__init__()
        self.channels = channels

        # --- 编码器 ---
        self.encoders = nn.ModuleList()
        self.se_enc = nn.ModuleList()
        self.pools = nn.ModuleList()
        ch_in = in_channels
        for ch in channels:
            self.encoders.append(nn.Sequential(
                nn.Conv3d(ch_in, ch, 3, padding=1, bias=False),
                nn.InstanceNorm3d(ch, affine=True),
                nn.LeakyReLU(0.01, inplace=True),
                ResBlock3D(ch),
            ))
            self.se_enc.append(SEBlock3D(ch, reduction=se_reduction))
            self.pools.append(nn.MaxPool3d(2))
            ch_in = ch

        # --- 解码器 (直接 concat, 无 attention gate) ---
        self.upconvs = nn.ModuleList()
        self.decoders = nn.ModuleList()
        self.se_dec = nn.ModuleList()
        for i in range(len(channels) - 1, 0, -1):
            self.upconvs.append(nn.ConvTranspose3d(channels[i], channels[i - 1], 2, stride=2))
            self.decoders.append(nn.Sequential(
                nn.Conv3d(channels[i - 1] * 2, channels[i - 1], 3, padding=1, bias=False),
                nn.InstanceNorm3d(channels[i - 1], affine=True),
                nn.LeakyReLU(0.01, inplace=True),
            ))
            self.se_dec.append(SEBlock3D(channels[i - 1], reduction=se_reduction))

        # --- Dual Heatmap 输出头 ---
        self.heatmap_head_left = nn.Conv3d(channels[0], 1, 1)
        self.heatmap_head_right = nn.Conv3d(channels[0], 1, 1)

    def forward(self, x):
        # 编码
        enc_features = []
        for enc, se, pool in zip(self.encoders, self.se_enc, self.pools):
            x = enc(x)
            x = se(x)  # SE channel attention
            enc_features.append(x)
            x = pool(x)

        # 解码 (skip connection 直接 concat, 无 spatial attention gate)
        for i, (upconv, dec, se) in enumerate(zip(self.upconvs, self.decoders, self.se_dec)):
            x = upconv(x)
            skip = enc_features[-(i + 2)]
            # 处理尺寸不一致的情况
            if x.shape != skip.shape:
                x = F.interpolate(x, size=skip.shape[2:], mode="trilinear", align_corners=False)
            x = torch.cat([x, skip], dim=1)  # 直接 concat, 不做 gating
            x = dec(x)
            x = se(x)  # SE channel attention

        heatmap_left = self.heatmap_head_left(x)    # (B, 1, D, H, W)
        heatmap_right = self.heatmap_head_right(x)  # (B, 1, D, H, W)
        return heatmap_left, heatmap_right
