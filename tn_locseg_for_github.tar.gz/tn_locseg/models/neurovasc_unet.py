"""
Optional NeuroVascU-Net blocks (Section 2.3.1–2.3.2, arXiv:2511.18422) on PlainConvUNet.

MSC^2F at the bottleneck; CDA^2F after transpconv||skip concat on the last K decoder stages.
Full paper backbone (dilated U-Net + gated attention skips) is not used — only these blocks.

Enabled when NnUNetSegNetwork(use_neurovasc_modules=True). Default path uses stock PlainConvUNet.
"""

from __future__ import annotations

from typing import Tuple

import torch
import torch.nn as nn

from dynamic_network_architectures.architectures.unet import PlainConvUNet
from dynamic_network_architectures.building_blocks.unet_decoder import UNetDecoder

from .neurovasc_paper_modules import CDA2FPaper, MSC2FPaper, bottleneck_spatial_size


class NeuroVascUNetDecoder(UNetDecoder):
    """
    UNetDecoder with CDA^2F (paper Sec. 2.3.2) after each transpconv||skip concat
    on the last K decoder stages. Concat width is 2 * c_skip; CDA runs on that many channels.
    """

    def __init__(
        self,
        encoder,
        num_classes: int,
        n_conv_per_stage,
        deep_supervision: bool,
        neurovasc_cda_last_n: int = 2,
        neurovasc_cda_stochastic_depth_p: float = 0.1,
        nonlin_first: bool = False,
    ):
        super().__init__(encoder, num_classes, n_conv_per_stage, deep_supervision, nonlin_first=nonlin_first)
        n = len(self.stages)
        k = max(0, min(int(neurovasc_cda_last_n), n))
        self._cda_last_n = k
        cdas = []
        for s in range(n):
            if s >= n - k:
                c_skip = encoder.output_channels[-(s + 2)]
                c_cat = 2 * c_skip
                cdas.append(
                    CDA2FPaper(c_cat, stochastic_depth_p=neurovasc_cda_stochastic_depth_p)
                )
            else:
                cdas.append(nn.Identity())
        self.cdas = nn.ModuleList(cdas)

    def forward(self, skips):
        lres_input = skips[-1]
        seg_outputs = []
        for s in range(len(self.stages)):
            x = self.transpconvs[s](lres_input)
            x = torch.cat((x, skips[-(s + 2)]), 1)
            x = self.cdas[s](x)
            x = self.stages[s](x)
            if self.deep_supervision:
                seg_outputs.append(self.seg_layers[s](x))
            elif s == (len(self.stages) - 1):
                seg_outputs.append(self.seg_layers[-1](x))
            lres_input = x
        seg_outputs = seg_outputs[::-1]
        if not self.deep_supervision:
            return seg_outputs[0]
        return seg_outputs


class PlainConvUNetNeuroVasc(PlainConvUNet):
    """
    PlainConvUNet with MSC^2F bottleneck and CDA^2F in the last decoder stages.
    """

    def __init__(
        self,
        *args,
        neurovasc_mscf: bool = True,
        neurovasc_cda_last_n: int = 2,
        neurovasc_seg_spatial: Tuple[int, int, int] = (64, 64, 64),
        neurovasc_cda_stochastic_depth_p: float = 0.1,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self._nv_mscf = bool(neurovasc_mscf)
        self._nv_cda_n = int(neurovasc_cda_last_n)

        c_bot = self.encoder.output_channels[-1]
        if self._nv_mscf:
            bd, bh, bw = bottleneck_spatial_size(
                neurovasc_seg_spatial, tuple(self.encoder.strides)
            )
            self.mscf = MSC2FPaper(c_bot, bd, bh, bw)
        else:
            self.mscf = nn.Identity()

        ncpd = kwargs["n_conv_per_stage_decoder"]
        if isinstance(ncpd, int):
            ncpd = [ncpd] * (len(self.encoder.output_channels) - 1)
        deep_supervision = kwargs.get("deep_supervision", False)
        nonlin_first = kwargs.get("nonlin_first", False)
        num_classes = kwargs["num_classes"]

        self.decoder = NeuroVascUNetDecoder(
            self.encoder,
            num_classes,
            ncpd,
            deep_supervision,
            neurovasc_cda_last_n=self._nv_cda_n,
            neurovasc_cda_stochastic_depth_p=neurovasc_cda_stochastic_depth_p,
            nonlin_first=nonlin_first,
        )

    def forward(self, x: torch.Tensor):
        skips = self.encoder(x)
        if self._nv_mscf:
            skips = list(skips)
            skips[-1] = self.mscf(skips[-1])
            skips = tuple(skips)
        return self.decoder(skips)
