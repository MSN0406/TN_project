"""
二次定位 (coarse-to-fine): 全脑粗定位后，在粗质心周围裁小块再精细定位，坐标映射回全脑。

与单次 forward_loc 共用同一套权重；细定位在原始分辨率的 ROI 上再 interpolate 到 loc_input_size。
适用于 nnUNet Loc 封装与 LocSegNet（二者均在 forward_loc 内对输入做 trilinear resize）。
"""

from __future__ import annotations

import torch


def extract_roi_around_centroid(
    wb: torch.Tensor,
    centroid_norm: torch.Tensor,
    crop_size: int,
    full_shape: torch.Tensor,
) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
    """
    在归一化质心周围裁立方 ROI（原分辨率），贴边时平移窗口。

    参数:
        wb: (1, 1, D, H, W)
        centroid_norm: (1, 3) in [0, 1]，全脑归一化坐标
        crop_size: 目标立方边长（体素），会按各维不超过当前 shape 裁剪
        full_shape: (3,) float，D,H,W

    返回:
        crop: (1, 1, cd, ch, cw)
        starts: (3,) float，每轴起始体素索引
        sizes: (3,) float，每轴 crop 长度
    """
    if wb.dim() != 5 or wb.shape[0] != 1:
        raise ValueError("extract_roi_around_centroid 当前仅支持 batch=1")
    _, _, d, h, w = wb.shape
    fs = full_shape.view(3).float().to(wb.device)
    max_idx = (fs - 1).clamp(min=1.0)
    cn = centroid_norm.squeeze(0).float() * max_idx
    center = cn.round().long()
    cd = max(min(crop_size, d), 2)
    ch = max(min(crop_size, h), 2)
    cw = max(min(crop_size, w), 2)

    sd = int((center[0] - cd // 2).clamp(0, d - cd).item())
    sh = int((center[1] - ch // 2).clamp(0, h - ch).item())
    sw = int((center[2] - cw // 2).clamp(0, w - cw).item())

    crop = wb[:, :, sd : sd + cd, sh : sh + ch, sw : sw + cw]
    starts = torch.tensor([sd, sh, sw], device=wb.device, dtype=torch.float32)
    sizes = torch.tensor([cd, ch, cw], device=wb.device, dtype=torch.float32)
    return crop, starts, sizes


def fine_norm_to_global_norm(
    centroid_norm_in_roi: torch.Tensor,
    starts: torch.Tensor,
    sizes: torch.Tensor,
    full_shape: torch.Tensor,
) -> torch.Tensor:
    """
    将 ROI 内 [0,1]^3 质心（与 loc 网络内部 grid 一致）映射到全脑 [0,1]^3。

    centroid_norm_in_roi: (1, 3)
    starts, sizes: (3,) float
    full_shape: (3,) float
    """
    fs = full_shape.view(3).float().to(centroid_norm_in_roi.device)
    den = (fs - 1).clamp(min=1e-6)
    roi_span = (sizes - 1).clamp(min=1e-6)
    vox = starts + centroid_norm_in_roi.view(3) * roi_span
    return (vox / den).clamp(0.0, 1.0).view(1, 3)
