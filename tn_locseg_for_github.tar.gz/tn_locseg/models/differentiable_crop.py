"""
differentiable_crop.py
======================
可微分 3D ROI 裁剪, 使用 grid_sample 实现.

这是 LocSegNet 的核心组件: 将定位网络预测的 centroid 转换为
从 whole brain 中裁出 ROI patch 的操作, 同时保持梯度可回传.
"""

import torch
import torch.nn.functional as F


def make_crop_grid(center_norm, crop_size, volume_shape):
    """
    创建以 center_norm 为中心的 3D 采样网格.

    参数:
        center_norm: (B, 3) 归一化坐标 [0, 1], 顺序为 (dim0, dim1, dim2)
        crop_size: (int, int, int) 裁剪尺寸 (输出 patch 的空间大小)
        volume_shape: (D, H, W) 输入体积的空间尺寸

    返回:
        grid: (B, crop_d, crop_h, crop_w, 3) 采样网格, 值在 [-1, 1]
              (grid_sample 要求的格式)
    """
    B = center_norm.shape[0]
    device = center_norm.device
    crop_d, crop_h, crop_w = crop_size
    D, H, W = volume_shape

    # 将 [0, 1] 坐标转换为 [-1, 1] (grid_sample 要求)
    center_gs = center_norm * 2 - 1  # (B, 3)

    # 计算 crop 在 [-1, 1] 空间中的半宽
    half_d = crop_d / D
    half_h = crop_h / H
    half_w = crop_w / W

    # 生成局部网格 (相对于中心的偏移, 范围 [-half, +half])
    lin_d = torch.linspace(-half_d, half_d, crop_d, device=device)
    lin_h = torch.linspace(-half_h, half_h, crop_h, device=device)
    lin_w = torch.linspace(-half_w, half_w, crop_w, device=device)

    # (crop_d, crop_h, crop_w, 3)
    # 注意: grid_sample 的 grid 最后一维顺序是 (w, h, d) 即 (x, y, z)
    grid_d, grid_h, grid_w = torch.meshgrid(lin_d, lin_h, lin_w, indexing="ij")

    grid = torch.stack([grid_w, grid_h, grid_d], dim=-1)  # (D, H, W, 3)
    grid = grid.unsqueeze(0).expand(B, -1, -1, -1, -1)  # (B, D, H, W, 3)

    # 加上中心坐标偏移
    # center_gs 顺序是 (dim0, dim1, dim2) = (d, h, w)
    # grid 最后一维顺序是 (w, h, d)
    offset = torch.stack([
        center_gs[:, 2],  # w (dim2)
        center_gs[:, 1],  # h (dim1)
        center_gs[:, 0],  # d (dim0)
    ], dim=-1)  # (B, 3)

    grid = grid + offset.view(B, 1, 1, 1, 3)

    return grid


def differentiable_crop_3d(volume, center_norm, crop_size, mode="bilinear",
                           padding_mode="zeros"):
    """
    可微分的 3D ROI 裁剪.

    参数:
        volume: (B, C, D, H, W) 输入体积
        center_norm: (B, 3) 归一化坐标 [0, 1], 顺序为 (dim0, dim1, dim2)
        crop_size: (int, int, int) 或 int, 裁剪尺寸
        mode: 插值模式 ("bilinear" 或 "nearest")
        padding_mode: 填充模式 ("zeros", "border", "reflection")

    返回:
        crop: (B, C, crop_d, crop_h, crop_w) 裁剪出的 patch
    """
    if isinstance(crop_size, int):
        crop_size = (crop_size, crop_size, crop_size)

    D, H, W = volume.shape[2:]
    grid = make_crop_grid(center_norm, crop_size, (D, H, W))

    crop = F.grid_sample(volume, grid, mode=mode, padding_mode=padding_mode,
                         align_corners=True)
    return crop


def hard_crop_3d(volume, center_voxel, crop_size):
    """
    不可微分的硬裁剪 (用于推理或 Phase 2 使用 GT centroid 时).

    参数:
        volume: (B, C, D, H, W) 输入体积
        center_voxel: (B, 3) 体素坐标 (整数), 顺序为 (dim0, dim1, dim2)
        crop_size: (int, int, int) 或 int

    返回:
        crops: list of (1, C, crop_d, crop_h, crop_w) tensors
    """
    if isinstance(crop_size, int):
        crop_size = (crop_size, crop_size, crop_size)

    B, C, D, H, W = volume.shape
    crops = []

    for b in range(B):
        c = center_voxel[b].long()
        halves = [s // 2 for s in crop_size]

        slices = []
        for dim_idx, (dim_size, half, cs) in enumerate(zip([D, H, W], halves, crop_size)):
            lo = max(0, c[dim_idx].item() - half)
            hi = min(dim_size, lo + cs)
            lo = max(0, hi - cs)
            slices.append(slice(lo, hi))

        crop = volume[b:b+1, :, slices[0], slices[1], slices[2]]
        crops.append(crop)

    return torch.cat(crops, dim=0)
