"""
loc_encoder.py
==============
轻量级 3D 定位编码器 + Dual Heatmap Head + Soft Argmax.

输入: whole brain (downsampled to 128³)
输出: 2 个 3D heatmap (left/right) → soft_argmax → centroid (归一化 [0, 1])

Dual-Head 设计:
    head_left:  始终预测位于大脑左半球 (dim0 < 0.5) 的目标
    head_right: 始终预测位于大脑右半球 (dim0 >= 0.5) 的目标
    训练时根据 GT centroid 的 dim0 坐标决定监督哪个 head,
    彻底消除左右歧义.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from dynamic_network_architectures.architectures.unet import PlainConvUNet
from dynamic_network_architectures.initialization.weight_init import InitWeights_He


class AttentionGate3D(nn.Module):
    """Attention Gate for skip connections (Oktay et al., 2018).

    用 gating signal (来自解码器上采样) 对 skip connection 做空间注意力加权,
    抑制无关区域, 让网络聚焦三叉神经所在区域.
    """

    def __init__(self, F_g, F_l, F_int):
        super().__init__()
        self.W_g = nn.Conv3d(F_g, F_int, 1, bias=False)
        self.W_x = nn.Conv3d(F_l, F_int, 1, bias=False)
        self.psi = nn.Sequential(
            nn.Conv3d(F_int, 1, 1, bias=False),
            nn.Sigmoid(),
        )
        self.relu = nn.ReLU(inplace=True)

    def forward(self, g, x):
        """
        g: gating signal (decoder upconv output), (B, F_g, D, H, W)
        x: skip connection (encoder feature), (B, F_l, D, H, W)
        """
        g1 = self.W_g(g)
        x1 = self.W_x(x)
        attn = self.psi(self.relu(g1 + x1))
        return x * attn


class ResBlock3D(nn.Module):
    """3D 残差块: Conv-IN-LeakyReLU-Conv-IN + skip."""

    def __init__(self, channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv3d(channels, channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(channels, affine=True),
            nn.LeakyReLU(0.01, inplace=True),
            nn.Conv3d(channels, channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(channels, affine=True),
        )
        self.act = nn.LeakyReLU(0.01, inplace=True)

    def forward(self, x):
        return self.act(x + self.block(x))


class LocEncoder3D(nn.Module):
    """
    轻量级 3D 编码器-解码器, 用于定位.

    编码器: 逐步下采样 (128→64→32→16→8)
    解码器: 逐步上采样回 128, 输出 1 通道 heatmap
    """

    def __init__(self, in_channels=1, channels=(16, 32, 64, 128, 256)):
        super().__init__()
        self.channels = channels

        # --- 编码器 ---
        self.encoders = nn.ModuleList()
        self.pools = nn.ModuleList()
        ch_in = in_channels
        for ch in channels:
            self.encoders.append(nn.Sequential(
                nn.Conv3d(ch_in, ch, 3, padding=1, bias=False),
                nn.InstanceNorm3d(ch, affine=True),
                nn.LeakyReLU(0.01, inplace=True),
                ResBlock3D(ch),
            ))
            self.pools.append(nn.MaxPool3d(2))
            ch_in = ch

        # --- 解码器 ---
        self.upconvs = nn.ModuleList()
        self.attention_gates = nn.ModuleList()
        self.decoders = nn.ModuleList()
        for i in range(len(channels) - 1, 0, -1):
            self.upconvs.append(nn.ConvTranspose3d(channels[i], channels[i - 1], 2, stride=2))
            self.attention_gates.append(
                AttentionGate3D(channels[i - 1], channels[i - 1], max(channels[i - 1] // 2, 8))
            )
            self.decoders.append(nn.Sequential(
                nn.Conv3d(channels[i - 1] * 2, channels[i - 1], 3, padding=1, bias=False),
                nn.InstanceNorm3d(channels[i - 1], affine=True),
                nn.LeakyReLU(0.01, inplace=True),
            ))

        # --- Dual Heatmap 输出头 ---
        self.heatmap_head_left = nn.Conv3d(channels[0], 1, 1)
        self.heatmap_head_right = nn.Conv3d(channels[0], 1, 1)

    def forward(self, x):
        # 编码
        enc_features = []
        for enc, pool in zip(self.encoders, self.pools):
            x = enc(x)
            enc_features.append(x)
            x = pool(x)

        # 解码 (skip connections + attention gates)
        for i, (upconv, attn_gate, dec) in enumerate(zip(self.upconvs, self.attention_gates, self.decoders)):
            x = upconv(x)
            skip = enc_features[-(i + 2)]
            # 处理尺寸不一致的情况
            if x.shape != skip.shape:
                x = F.interpolate(x, size=skip.shape[2:], mode="trilinear", align_corners=False)
            skip = attn_gate(g=x, x=skip)
            x = torch.cat([x, skip], dim=1)
            x = dec(x)

        heatmap_left = self.heatmap_head_left(x)    # (B, 1, D, H, W)
        heatmap_right = self.heatmap_head_right(x)  # (B, 1, D, H, W)
        return heatmap_left, heatmap_right


class NnUNetLocEncoder3D(nn.Module):
    """
    基于 nnU-Net v2 PlainConvUNet 的定位网络.

    输入: (B, 1, D, H, W)
    输出: 两个 heatmap (left/right), 均为 (B, 1, D, H, W)
    """

    def __init__(
        self,
        in_channels=1,
        features_per_stage=(16, 32, 64, 128, 256),
        n_conv_per_stage=2,
        n_conv_per_stage_decoder=2,
    ):
        super().__init__()
        n_stages = len(features_per_stage)
        kernel_sizes = [3] * n_stages
        strides = [1] + [2] * (n_stages - 1)

        if isinstance(n_conv_per_stage, int):
            n_conv_per_stage = [n_conv_per_stage] * n_stages
        if isinstance(n_conv_per_stage_decoder, int):
            n_conv_per_stage_decoder = [n_conv_per_stage_decoder] * (n_stages - 1)

        # num_classes=2, 分别作为 left/right heatmap logits
        self.network = PlainConvUNet(
            input_channels=in_channels,
            n_stages=n_stages,
            features_per_stage=list(features_per_stage),
            conv_op=nn.Conv3d,
            kernel_sizes=kernel_sizes,
            strides=strides,
            n_conv_per_stage=n_conv_per_stage,
            num_classes=2,
            n_conv_per_stage_decoder=n_conv_per_stage_decoder,
            conv_bias=False,
            norm_op=nn.InstanceNorm3d,
            norm_op_kwargs={"eps": 1e-5, "affine": True},
            dropout_op=None,
            dropout_op_kwargs=None,
            nonlin=nn.LeakyReLU,
            nonlin_kwargs={"inplace": True},
            deep_supervision=False,
        )
        self.network.apply(InitWeights_He(1e-2))

    def forward(self, x):
        out = self.network(x)  # (B, 2, D, H, W)
        heatmap_left = out[:, 0:1]
        heatmap_right = out[:, 1:2]
        return heatmap_left, heatmap_right


def soft_argmax_3d(heatmap, temperature=1.0):
    """
    从 3D heatmap 中提取坐标 (可微分).

    参数:
        heatmap: (B, 1, D, H, W) 原始 logits
        temperature: softmax 温度, 越小越尖锐

    返回:
        coords: (B, 3) 归一化坐标 [0, 1] 范围, 顺序为 (dim0, dim1, dim2)
    """
    B, C, D, H, W = heatmap.shape
    assert C == 1

    # Flatten spatial dims, 然后 softmax
    flat = heatmap.view(B, -1) / temperature
    weights = F.softmax(flat, dim=-1).view(B, D, H, W)

    # 创建坐标网格 (归一化到 [0, 1])
    device = heatmap.device
    grid_d = torch.linspace(0, 1, D, device=device)
    grid_h = torch.linspace(0, 1, H, device=device)
    grid_w = torch.linspace(0, 1, W, device=device)

    # 对每个维度求加权平均
    coord_d = (weights.sum(dim=(2, 3)) * grid_d.view(1, -1)).sum(dim=1)  # (B,)
    coord_h = (weights.sum(dim=(1, 3)) * grid_h.view(1, -1)).sum(dim=1)
    coord_w = (weights.sum(dim=(1, 2)) * grid_w.view(1, -1)).sum(dim=1)

    coords = torch.stack([coord_d, coord_h, coord_w], dim=1)  # (B, 3)
    return coords


def generate_heatmap_target(center_norm, spatial_size, sigma=3.0):
    """
    生成 3D Gaussian heatmap 作为定位 GT.

    参数:
        center_norm: (B, 3) 归一化坐标 [0, 1]
        spatial_size: (D, H, W) heatmap 尺寸
        sigma: Gaussian 标准差 (以 voxel 为单位)

    返回:
        heatmap: (B, 1, D, H, W) Gaussian heatmap
    """
    B = center_norm.shape[0]
    D, H, W = spatial_size
    device = center_norm.device

    # 创建坐标网格
    grid_d = torch.arange(D, device=device, dtype=torch.float32)
    grid_h = torch.arange(H, device=device, dtype=torch.float32)
    grid_w = torch.arange(W, device=device, dtype=torch.float32)
    zz, yy, xx = torch.meshgrid(grid_d, grid_h, grid_w, indexing="ij")

    # 将归一化坐标转换为 voxel 坐标
    center_vox = center_norm.clone()
    center_vox[:, 0] *= (D - 1)
    center_vox[:, 1] *= (H - 1)
    center_vox[:, 2] *= (W - 1)

    # 计算距离
    zz = zz.unsqueeze(0).expand(B, -1, -1, -1)
    yy = yy.unsqueeze(0).expand(B, -1, -1, -1)
    xx = xx.unsqueeze(0).expand(B, -1, -1, -1)

    cz = center_vox[:, 0].view(B, 1, 1, 1)
    cy = center_vox[:, 1].view(B, 1, 1, 1)
    cx = center_vox[:, 2].view(B, 1, 1, 1)

    dist_sq = (zz - cz) ** 2 + (yy - cy) ** 2 + (xx - cx) ** 2
    heatmap = torch.exp(-dist_sq / (2 * sigma ** 2))

    return heatmap.unsqueeze(1)  # (B, 1, D, H, W)
