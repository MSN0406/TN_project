"""
locseg_net.py
=============
LocSegNet: 三叉神经定位+分割一体网络.

架构:
    Whole Brain → [Downsample] → [Loc Encoder] → Dual Heatmap (left/right) → soft_argmax → centroid
                                                                ↓ (选择正确 head)
    Whole Brain → [Differentiable Crop (centroid)] → ROI patch → [Seg Network] → mask

Dual-Head 定位:
    编码器共享, 两个独立 heatmap head 分别负责左/右半脑.
    训练时根据 GT centroid 的 dim0 坐标选择 head (dim0 < 0.5 → left, >= 0.5 → right).
    推理时返回双侧结果, 由调用方选择.

三阶段训练:
    Phase 1: 仅训练定位 (Loc Encoder + Dual Heatmap Head)
    Phase 2: 仅训练分割 (Seg Network), 使用 GT centroid 裁剪
    Phase 3: 端到端联合微调
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from .loc_encoder import LocEncoder3D, NnUNetLocEncoder3D, soft_argmax_3d
from .seg_decoder import NnUNetSegNetwork
from .differentiable_crop import differentiable_crop_3d, hard_crop_3d


class LocSegNet(nn.Module):
    """
    定位-分割一体网络 (Dual-Head 定位).

    参数:
        loc_input_size: 定位网络输入尺寸 (downsampled), 如 (128, 128, 128)
        seg_crop_size: 分割网络输入尺寸 (crop size), 如 (64, 64, 64)
        num_classes: 分割类别数
        loc_channels: 定位编码器通道数 (loc_arch=custom 时生效)
        loc_arch: 定位网络架构 ("nnunet" 或 "custom")
        loc_features_per_stage: nnU-Net 定位网络每层特征通道数
        loc_n_conv_per_stage: nnU-Net 定位网络 encoder 每层卷积块数
        loc_n_conv_per_stage_decoder: nnU-Net 定位网络 decoder 每层卷积块数
        seg_channels: 保留兼容参数 (严格 nnU-Net 结构下不使用)
        seg_arch: 分割网络架构选择 (仅支持 "nnunet")
        seg_features_per_stage: nnU-Net PlainConvUNet 的每层特征通道数
        n_conv_per_stage: 每个 encoder stage 的卷积块数 (nnunet 模式)
        n_conv_per_stage_decoder: 每个 decoder stage 的卷积块数 (nnunet 模式)
    """

    def __init__(
        self,
        loc_input_size=(128, 128, 128),
        seg_crop_size=(64, 64, 64),
        num_classes=3,
        loc_channels=(16, 32, 64, 128, 256),
        loc_arch="nnunet",
        loc_features_per_stage=(16, 32, 64, 128, 256),
        loc_n_conv_per_stage=2,
        loc_n_conv_per_stage_decoder=2,
        seg_channels=(32, 64, 128, 256, 512),
        deep_supervision=True,
        dual_seg=False,
        dropout=0.0,
        seg_arch="nnunet",
        seg_features_per_stage=(32, 64, 128, 256, 320),
        n_conv_per_stage=2,
        n_conv_per_stage_decoder=2,
        use_neurovasc_modules=False,
        neurovasc_mscf=True,
        neurovasc_cda_last_n=2,
        neurovasc_cda_stochastic_depth_p=0.1,
        loc_head_select="gt",
    ):
        super().__init__()

        self.loc_input_size = loc_input_size
        self.seg_crop_size = seg_crop_size
        self.dual_seg = dual_seg
        # 双头训练时选哪一侧监督: "gt"=用 GT 质心 dim0; "pred"=用左右 heatmap 峰值谁更大
        self.loc_head_select = str(loc_head_select).lower().strip()
        if self.loc_head_select not in ("gt", "pred"):
            raise ValueError(f"loc_head_select must be 'gt' or 'pred', got {loc_head_select!r}")
        self.loc_arch = loc_arch.lower() if isinstance(loc_arch, str) else loc_arch
        self.seg_arch = seg_arch.lower() if isinstance(seg_arch, str) else seg_arch

        if self.loc_arch not in ("nnunet", "custom"):
            raise ValueError(
                f"Unsupported loc_arch={loc_arch}. Use nnunet/custom."
            )
        if self.seg_arch not in ("nnunet", "plainconvunet"):
            raise ValueError(
                f"Unsupported seg_arch={seg_arch}. "
                "This project is now locked to nnU-Net PlainConvUNet."
            )
        if dual_seg:
            raise ValueError("dual_seg=True is not supported in nnU-Net-only mode.")

        # --- 定位分支 (dual-head) ---
        if self.loc_arch == "nnunet":
            self.loc_encoder = NnUNetLocEncoder3D(
                in_channels=1,
                features_per_stage=loc_features_per_stage,
                n_conv_per_stage=loc_n_conv_per_stage,
                n_conv_per_stage_decoder=loc_n_conv_per_stage_decoder,
            )
        else:
            self.loc_encoder = LocEncoder3D(
                in_channels=1,
                channels=loc_channels,
            )

        # --- 分割分支: 严格使用 nnU-Net PlainConvUNet ---
        self.seg_network = NnUNetSegNetwork(
            in_channels=1,
            num_classes=num_classes,
            features_per_stage=seg_features_per_stage,
            n_conv_per_stage=n_conv_per_stage,
            n_conv_per_stage_decoder=n_conv_per_stage_decoder,
            deep_supervision=deep_supervision,
            dropout=dropout,
            use_neurovasc_modules=use_neurovasc_modules,
            neurovasc_mscf=neurovasc_mscf,
            neurovasc_cda_last_n=neurovasc_cda_last_n,
            neurovasc_seg_spatial=seg_crop_size,
            neurovasc_cda_stochastic_depth_p=neurovasc_cda_stochastic_depth_p,
        )

        # --- 训练阶段控制 ---
        self._phase = 1
        self._use_gt_centroid = False

    def set_phase(self, phase):
        """
        设置训练阶段.
            phase=1: 仅训练定位, 冻结分割
            phase=2: 仅训练分割 (使用 GT centroid), 冻结定位
            phase=3: 端到端联合训练
        """
        self._phase = phase
        if phase == 1:
            self._freeze_seg()
            self._unfreeze_loc()
            self._use_gt_centroid = False
        elif phase == 2:
            self._freeze_loc()
            self._unfreeze_seg()
            self._use_gt_centroid = True
        elif phase == 3:
            self._unfreeze_loc()
            self._unfreeze_seg()
            self._use_gt_centroid = False
        print(f"[LocSegNet] Phase set to {phase}")

    def _freeze_loc(self):
        for p in self.loc_encoder.parameters():
            p.requires_grad = False

    def _unfreeze_loc(self):
        for p in self.loc_encoder.parameters():
            p.requires_grad = True

    def _freeze_seg(self):
        for p in self.seg_network.parameters():
            p.requires_grad = False

    def _unfreeze_seg(self):
        for p in self.seg_network.parameters():
            p.requires_grad = True

    @staticmethod
    def _select_by_gt(heatmap_left, heatmap_right, centroid_left, centroid_right,
                      gt_centroid_norm):
        """
        根据 GT centroid 的 dim0 位置选择对应 head 的输出.

        dim0 < 0.5 → 目标在左半脑 → 选 head_left
        dim0 >= 0.5 → 目标在右半脑 → 选 head_right

        参数:
            heatmap_left/right: (B, 1, D, H, W)
            centroid_left/right: (B, 3)
            gt_centroid_norm: (B, 3) GT 归一化坐标

        返回:
            selected_heatmap: (B, 1, D, H, W)
            selected_centroid: (B, 3)
        """
        use_left = (gt_centroid_norm[:, 0] < 0.5)  # (B,) bool

        # 选择 heatmap: (B, 1, D, H, W)
        selected_heatmap = torch.where(
            use_left.view(-1, 1, 1, 1, 1),
            heatmap_left,
            heatmap_right,
        )

        # 选择 centroid: (B, 3)
        selected_centroid = torch.where(
            use_left.unsqueeze(1),
            centroid_left,
            centroid_right,
        )

        return selected_heatmap, selected_centroid

    @staticmethod
    def _select_by_pred(heatmap_left, heatmap_right, centroid_left, centroid_right):
        """
        根据左右 heatmap 的全局最大响应选头 (网络自行判断左右).

        每个样本: max(left) >= max(right) 则选 left head, 否则选 right.
        梯度只通过被选中的 head 传回 (与 _select_by_gt 相同).
        """
        B = heatmap_left.shape[0]
        flat_left = heatmap_left.reshape(B, -1)
        flat_right = heatmap_right.reshape(B, -1)
        max_left = flat_left.max(dim=1).values
        max_right = flat_right.max(dim=1).values
        use_left = max_left >= max_right

        selected_heatmap = torch.where(
            use_left.view(-1, 1, 1, 1, 1),
            heatmap_left,
            heatmap_right,
        )
        selected_centroid = torch.where(
            use_left.unsqueeze(1),
            centroid_left,
            centroid_right,
        )
        return selected_heatmap, selected_centroid

    def forward_loc(self, whole_brain, gt_centroid_norm=None):
        """
        定位前向传播 (dual-head).

        参数:
            whole_brain: (B, 1, D, H, W) 原始 whole brain
            gt_centroid_norm: (B, 3) GT 归一化坐标.
                              非空时用于选头: loc_head_select='gt' 用 dim0;
                              'pred' 用左右 heatmap 峰值比较, GT 仍用于 trainer 里算 Gaussian target.
                              推理时为 None.

        返回:
            dict:
                heatmap: 选中 head 的 heatmap (训练用)
                centroid_norm: 选中 head 的 centroid (训练用)
                heatmap_left / heatmap_right: 双侧 heatmap
                centroid_left / centroid_right: 双侧 centroid
        """
        # 降采样到 loc_input_size
        wb_low = F.interpolate(
            whole_brain, size=self.loc_input_size,
            mode="trilinear", align_corners=False,
        )

        # 共享编码器 → 双 heatmap
        heatmap_left, heatmap_right = self.loc_encoder(wb_low)

        # soft argmax 提取坐标
        centroid_left = soft_argmax_3d(heatmap_left, temperature=1.0)
        centroid_right = soft_argmax_3d(heatmap_right, temperature=1.0)

        result = {
            "heatmap_left": heatmap_left,
            "heatmap_right": heatmap_right,
            "centroid_left": centroid_left,
            "centroid_right": centroid_right,
        }

        # 根据 GT 或预测响应选择 head (训练/验证时 gt_centroid_norm 通常非空)
        if gt_centroid_norm is not None:
            if self.loc_head_select == "pred":
                selected_hm, selected_cn = self._select_by_pred(
                    heatmap_left, heatmap_right,
                    centroid_left, centroid_right,
                )
            else:
                selected_hm, selected_cn = self._select_by_gt(
                    heatmap_left, heatmap_right,
                    centroid_left, centroid_right,
                    gt_centroid_norm,
                )
            result["heatmap"] = selected_hm
            result["centroid_norm"] = selected_cn
        else:
            # 推理: 默认返回两侧, heatmap/centroid_norm 设为 left (调用方应使用双侧)
            result["heatmap"] = heatmap_left
            result["centroid_norm"] = centroid_left

        return result

    def forward_seg(self, whole_brain, centroid_norm):
        """
        分割前向传播.

        使用 differentiable crop + border padding:
          - 以 centroid 为中心从 whole brain 裁剪 ROI
          - border padding: 边界处延伸像素值, 提供周围上下文
          - 梯度可回传到 centroid (Phase 3 联合训练需要)

        参数:
            whole_brain: (B, 1, D, H, W) 原始 whole brain
            centroid_norm: (B, 3) 归一化坐标 [0, 1]

        返回 (dual_seg=False):
            seg_output: (B, num_classes, D, H, W), ds_outputs, roi
        返回 (dual_seg=True):
            seg_outputs: {"nerve": (B,2,D,H,W), "vessel": (B,2,D,H,W)}
            ds_outputs:  {"nerve": [...], "vessel": [...]}
            roi: (B, 1, D, H, W)
        """
        roi = differentiable_crop_3d(
            whole_brain, centroid_norm, self.seg_crop_size,
            mode="bilinear", padding_mode="border",
        )

        if self.dual_seg:
            nerve_out, nerve_ds = self.seg_nerve(roi)
            vessel_out, vessel_ds = self.seg_vessel(roi)
            return (
                {"nerve": nerve_out, "vessel": vessel_out},
                {"nerve": nerve_ds, "vessel": vessel_ds},
                roi,
            )
        else:
            seg_output, ds_outputs = self.seg_network(roi)
            return seg_output, ds_outputs, roi

    def forward(self, whole_brain, gt_centroid_norm=None):
        """
        完整前向传播.

        参数:
            whole_brain: (B, 1, D, H, W) 原始 whole brain
            gt_centroid_norm: (B, 3) GT 归一化坐标

        返回:
            dict:
                heatmap: 选中的定位 heatmap
                centroid_norm: 选中的归一化坐标
                heatmap_left / heatmap_right: 双侧 heatmap
                centroid_left / centroid_right: 双侧 centroid
                seg_output: 分割结果
                ds_outputs: deep supervision 输出
                roi: 裁剪出的 ROI (用于可视化)
        """
        result = {}

        # --- 定位 (dual-head) ---
        loc_result = self.forward_loc(whole_brain, gt_centroid_norm)
        result.update(loc_result)

        if self._phase == 1:
            # Phase 1: 仅返回定位结果
            return result

        # --- 确定使用的 centroid ---
        if self._use_gt_centroid and gt_centroid_norm is not None:
            crop_centroid = gt_centroid_norm
        else:
            crop_centroid = result["centroid_norm"]  # 选中的 centroid

        # --- 分割 (始终使用 differentiable crop + border padding) ---
        seg_out, ds_out, roi = self.forward_seg(
            whole_brain, crop_centroid,
        )
        if self.dual_seg:
            result["seg_nerve"] = seg_out["nerve"]
            result["seg_vessel"] = seg_out["vessel"]
            result["ds_nerve"] = ds_out["nerve"]
            result["ds_vessel"] = ds_out["vessel"]
        else:
            result["seg_output"] = seg_out
            result["ds_outputs"] = ds_out
        result["roi"] = roi

        return result

    def predict(self, whole_brain):
        """推理时使用, 返回双侧定位坐标和分割结果."""
        self.eval()
        with torch.no_grad():
            loc_result = self.forward_loc(whole_brain, gt_centroid_norm=None)

            seg_out, ds_out, roi = self.forward_seg(
                whole_brain, loc_result["centroid_left"],
            )

        result = {
            "centroid_left": loc_result["centroid_left"],
            "centroid_right": loc_result["centroid_right"],
            "heatmap_left": loc_result["heatmap_left"],
            "heatmap_right": loc_result["heatmap_right"],
            "roi": roi,
        }
        if self.dual_seg:
            result["seg_nerve"] = torch.softmax(seg_out["nerve"], dim=1)
            result["seg_vessel"] = torch.softmax(seg_out["vessel"], dim=1)
        else:
            result["seg_output"] = torch.softmax(seg_out, dim=1)
        return result