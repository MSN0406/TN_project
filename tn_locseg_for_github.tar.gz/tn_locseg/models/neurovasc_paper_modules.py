"""
NeuroVascU-Net MSC^2F and CDA^2F (Section 2.3.1–2.3.2, arXiv:2511.18422).

https://arxiv.org/html/2511.18422v1

Backbone differs from the full NeuroVasc paper (dilated U-Net + gated skips); block
internals follow Section 2.3.1–2.3.2. Spherical CNN branch uses a multi-orientation
depthwise proxy (see class docstring) because SO(3) spherical CNNs are not in PyTorch core.
"""

from __future__ import annotations

import math
from typing import Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


def _forward_block_fp32_safe(module: nn.Module, x: torch.Tensor) -> torch.Tensor:
    """
    Run a paper block in float32 when autocast uses fp16/bf16.

    FFT (FSA) uses experimental ComplexHalf under autocast; GatedAxialAttention softmax can
    overflow in fp16 at full decoder resolution — both yield NaN logits and poison training.
    """
    dt = x.dtype
    if dt in (torch.float16, torch.bfloat16):
        with torch.amp.autocast(device_type=x.device.type, enabled=False):
            y = module._forward_compute(x.float())  # type: ignore[attr-defined]
        return y.to(dt)
    return module._forward_compute(x)  # type: ignore[attr-defined]


def _stride_to_dhw(s) -> Tuple[int, int, int]:
    if isinstance(s, (tuple, list)):
        return int(s[0]), int(s[1]), int(s[2])
    v = int(s)
    return v, v, v


def bottleneck_spatial_size(
    input_dhw: Tuple[int, int, int],
    strides,
) -> Tuple[int, int, int]:
    """Spatial size at deepest encoder output given ROI (D,H,W) and per-stage strides."""
    d, h, w = int(input_dhw[0]), int(input_dhw[1]), int(input_dhw[2])
    for st in strides:
        sd, sh, sw = _stride_to_dhw(st)
        d = max(1, d // sd)
        h = max(1, h // sh)
        w = max(1, w // sw)
    return d, h, w


def _make_3d_log_kernel(sigma: float, device, dtype) -> torch.Tensor:
    radius = max(int(math.ceil(3 * sigma)), 1)
    z = torch.arange(-radius, radius + 1, device=device, dtype=dtype)
    y = torch.arange(-radius, radius + 1, device=device, dtype=dtype)
    x = torch.arange(-radius, radius + 1, device=device, dtype=dtype)
    zz, yy, xx = torch.meshgrid(z, y, x, indexing="ij")
    r2 = xx * xx + yy * yy + zz * zz
    s2 = sigma * sigma
    c = -1.0 / (math.pi * s2 * s2)
    k = c * (1.0 - r2 / (2.0 * s2)) * torch.exp(-r2 / (2.0 * s2))
    k = k / (k.abs().sum() + 1e-8)
    return k


class AnisotropicASPP3d(nn.Module):
    dilations: Tuple[Tuple[int, int, int], ...] = ((1, 1, 1), (1, 2, 2), (1, 3, 3))

    def __init__(self, channels: int, bn_eps: float = 1e-5):
        super().__init__()
        c = channels
        self.branches = nn.ModuleList()
        for dd, dh, dw in self.dilations:
            pad = (dd, dh, dw)
            self.branches.append(
                nn.Sequential(
                    nn.Conv3d(c, c, kernel_size=3, padding=pad, dilation=(dd, dh, dw), bias=False),
                    nn.BatchNorm3d(c, eps=bn_eps),
                    nn.ReLU(inplace=True),
                )
            )
        self.project = nn.Sequential(
            nn.Conv3d(len(self.dilations) * c, c, kernel_size=1, bias=False),
            nn.BatchNorm3d(c, eps=bn_eps),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        feats = [b(x) for b in self.branches]
        return self.project(torch.cat(feats, dim=1))


class FrequencySpatialAttention3d(nn.Module):
    """Eq. (3); mask (C,D,H,W_rfft) fixed at construction (MSC bottleneck)."""

    def __init__(self, channels: int, bottleneck_d: int, bottleneck_h: int, bottleneck_w: int):
        super().__init__()
        wf = bottleneck_w // 2 + 1
        # Start near identity in frequency domain (1 + 0j) so training begins from ASPP path.
        self.mask_real = nn.Parameter(torch.ones(channels, bottleneck_d, bottleneck_h, wf))
        self.mask_imag = nn.Parameter(torch.zeros(channels, bottleneck_d, bottleneck_h, wf))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, d, h, w = x.shape
        x_fft = torch.fft.rfftn(x, dim=(-3, -2, -1), norm="ortho")
        mr = self.mask_real.unsqueeze(0).expand(b, -1, -1, -1, -1)
        mi = self.mask_imag.unsqueeze(0).expand(b, -1, -1, -1, -1)
        m = torch.complex(mr, mi)
        y_fft = m * x_fft
        return torch.fft.irfftn(y_fft, s=(d, h, w), dim=(-3, -2, -1), norm="ortho")


class FrequencySpatialAttention3dCDA(nn.Module):
    """
    Same Eq. (3) operator; learnable mask stored at a base grid and trilinearly resized
    to the current rfft grid so CDA can run at multiple decoder resolutions.
    """

    def __init__(self, channels: int, base_d: int = 12, base_h: int = 12, base_w: int = 12):
        super().__init__()
        wf = base_w // 2 + 1
        self.mask_real = nn.Parameter(torch.ones(channels, base_d, base_h, wf))
        self.mask_imag = nn.Parameter(torch.zeros(channels, base_d, base_h, wf))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, d, h, w = x.shape
        x_fft = torch.fft.rfftn(x, dim=(-3, -2, -1), norm="ortho")
        _, _, d_f, h_f, w_f = x_fft.shape
        tgt = (d_f, h_f, w_f)
        mr = F.interpolate(self.mask_real.unsqueeze(0), size=tgt, mode="trilinear", align_corners=False)
        mi = F.interpolate(self.mask_imag.unsqueeze(0), size=tgt, mode="trilinear", align_corners=False)
        mr = mr.expand(b, -1, -1, -1, -1)
        mi = mi.expand(b, -1, -1, -1, -1)
        m = torch.complex(mr, mi)
        y_fft = m * x_fft
        return torch.fft.irfftn(y_fft, s=(d, h, w), dim=(-3, -2, -1), norm="ortho")


class ECA3d(nn.Module):
    def __init__(self, channels: int, gamma: int = 2, b: int = 1):
        super().__init__()
        t = int(abs((math.log2(max(channels, 2)) + b) / gamma))
        k = t if t % 2 else t + 1
        k = max(3, min(k, channels))
        self.conv = nn.Conv1d(1, 1, kernel_size=k, padding=k // 2, bias=False)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, _, _, _ = x.shape
        y = x.mean(dim=(2, 3, 4)).view(b, 1, c)
        y = torch.sigmoid(self.conv(y)).view(b, c, 1, 1, 1)
        return x * y


class MSC2FPaper(nn.Module):
    """Section 2.3.1; Eq. (4)."""

    def __init__(
        self,
        channels: int,
        bottleneck_d: int,
        bottleneck_h: int,
        bottleneck_w: int,
        log_sigma: float = 1.0,
        bn_eps: float = 1e-5,
    ):
        super().__init__()
        self.log_sigma = log_sigma
        self.aspp = AnisotropicASPP3d(channels, bn_eps=bn_eps)
        self.fsa = FrequencySpatialAttention3d(channels, bottleneck_d, bottleneck_h, bottleneck_w)
        c = channels
        self.dw = nn.Conv3d(3 * c, 3 * c, kernel_size=3, padding=1, groups=3 * c, bias=False)
        self.bn_dw = nn.BatchNorm3d(3 * c, eps=bn_eps)
        self.relu = nn.ReLU(inplace=True)
        self.eca = ECA3d(3 * c)
        self.conv_yhat = nn.Conv3d(3 * c, c, kernel_size=1, bias=False)
        self.bn_yhat = nn.BatchNorm3d(c, eps=bn_eps)
        self.conv_aspp_residual = nn.Conv3d(c, c, kernel_size=1, bias=False)
        self.bn_aspp = nn.BatchNorm3d(c, eps=bn_eps)

    def _forward_compute(self, f_skip: torch.Tensor) -> torch.Tensor:
        f_aspp = self.aspp(f_skip)
        k = _make_3d_log_kernel(self.log_sigma, f_aspp.device, f_aspp.dtype)
        b, c, d, h, w = f_aspp.shape
        k_expand = k.view(1, 1, *k.shape).expand(c, 1, *k.shape)
        pad = k.shape[0] // 2
        e = F.conv3d(f_aspp, k_expand, padding=pad, groups=c)
        f_token = self.fsa(f_aspp)
        cat = torch.cat([f_skip, e, f_token], dim=1)
        y = self.relu(self.bn_dw(self.dw(cat)))
        y = self.eca(y)
        y_hat = self.relu(self.bn_yhat(self.conv_yhat(y)))
        out_aspp = self.bn_aspp(self.conv_aspp_residual(f_aspp))
        return out_aspp + y_hat

    def forward(self, f_skip: torch.Tensor) -> torch.Tensor:
        return _forward_block_fp32_safe(self, f_skip)


class Involution3D(nn.Module):
    def __init__(self, channels: int, kernel_size: int = 3, reduction: int = 4):
        super().__init__()
        self.kernel_size = kernel_size
        self.pad = kernel_size // 2
        self.groups = min(8, max(1, channels // 8))
        if channels % self.groups != 0:
            self.groups = 1
        mid = max(channels // reduction, 8)
        self.reduce = nn.Conv3d(channels, mid, kernel_size=1, bias=False)
        self.gen = nn.Conv3d(mid, kernel_size**3 * self.groups, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm3d(channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c, d, h, w = x.shape
        g = self.groups
        cg = c // g
        k = self.kernel_size
        att = self.gen(self.reduce(x)).view(b, g, k * k * k, d, h, w)
        att = torch.softmax(att, dim=2)
        xp = F.pad(x, (self.pad,) * 6)
        out = torch.zeros(b, c, d, h, w, device=x.device, dtype=x.dtype)
        for a in range(k):
            for bb in range(k):
                for cc in range(k):
                    t = a * k * k + bb * k + cc
                    sl = xp[:, :, a : a + d, bb : bb + h, cc : cc + w]
                    og = out.view(b, g, cg, d, h, w)
                    sv = sl.view(b, g, cg, d, h, w)
                    wg = att[:, :, t, :, :, :].unsqueeze(2)
                    og = og + sv * wg
                    out = og.view(b, c, d, h, w)
        return self.bn(out)


class DepthwiseConvNeXtBlock3d(nn.Module):
    def __init__(self, channels: int, bn_eps: float = 1e-5):
        super().__init__()
        self.norm = nn.BatchNorm3d(channels, eps=bn_eps)
        self.dw = nn.Conv3d(channels, channels, kernel_size=5, padding=2, groups=channels, bias=False)
        self.act = nn.GELU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.act(self.dw(self.norm(x)))


class MultiOrientationSphericalProxy3d(nn.Module):
    """Proxy for Spherical CNN branch (paper Sec. 2.3.2); see module docstring."""

    def __init__(self, channels: int):
        super().__init__()
        c = channels
        self.dx = nn.Conv3d(c, c, kernel_size=(3, 1, 1), padding=(1, 0, 0), groups=c, bias=False)
        self.dy = nn.Conv3d(c, c, kernel_size=(1, 3, 1), padding=(0, 1, 0), groups=c, bias=False)
        self.dz = nn.Conv3d(c, c, kernel_size=(1, 1, 3), padding=(0, 0, 1), groups=c, bias=False)
        self.d3 = nn.Conv3d(c, c, kernel_size=3, padding=1, groups=c, bias=False)
        self.pw = nn.Conv3d(4 * c, c, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm3d(c)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = torch.cat([self.dx(x), self.dy(x), self.dz(x), self.d3(x)], dim=1)
        return self.bn(self.pw(y))


class GatedAxialAttention3d(nn.Module):
    def __init__(self, channels: int, dim_head: int = 8, bn_eps: float = 1e-5, chunk: int = 2048):
        super().__init__()
        self.channels = channels
        self.dim_head = max(dim_head, 4)
        self.chunk = chunk
        self.norm = nn.LayerNorm(channels, eps=bn_eps)
        self.to_qkv = nn.Linear(channels, 3 * self.dim_head)
        self.gate = nn.Sequential(nn.Linear(channels, channels), nn.Sigmoid())
        self.proj = nn.Linear(self.dim_head, channels)

    def _attn_along(self, x: torch.Tensor, axis: int) -> torch.Tensor:
        b, c, d, h, w = x.shape
        if axis == 0:
            xt = x.permute(0, 3, 4, 2, 1).contiguous()
            seq, n_other = d, h * w
        elif axis == 1:
            xt = x.permute(0, 2, 4, 3, 1).contiguous()
            seq, n_other = h, d * w
        else:
            xt = x.permute(0, 2, 3, 4, 1).contiguous()
            seq, n_other = w, d * h
        flat = xt.view(b * n_other, seq, c)
        outs = []
        for s0 in range(0, flat.shape[0], self.chunk):
            s1 = min(s0 + self.chunk, flat.shape[0])
            blk = flat[s0:s1]
            blk = self.norm(blk)
            qkv = self.to_qkv(blk).view(blk.shape[0], seq, 3, self.dim_head)
            q, k_, v = qkv[:, :, 0], qkv[:, :, 1], qkv[:, :, 2]
            att = torch.softmax(
                torch.bmm(q, k_.transpose(-2, -1)) / math.sqrt(self.dim_head), dim=-1
            )
            y = torch.bmm(att, v)
            y = self.proj(y)
            g = self.gate(blk)
            y = y * g + blk
            outs.append(y)
        y_all = torch.cat(outs, dim=0).view(b, n_other, seq, c)
        if axis == 0:
            y_all = y_all.view(b, h, w, d, c).permute(0, 4, 3, 1, 2).contiguous()
        elif axis == 1:
            y_all = y_all.view(b, d, w, h, c).permute(0, 4, 1, 3, 2).contiguous()
        else:
            y_all = y_all.view(b, d, h, w, c).permute(0, 4, 1, 2, 3).contiguous()
        return y_all

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self._attn_along(x, 0)
        x = self._attn_along(x, 1)
        x = self._attn_along(x, 2)
        return x


class StochasticDepth(nn.Module):
    def __init__(self, p: float = 0.1):
        super().__init__()
        self.p = p

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if not self.training or self.p <= 0.0:
            return x
        b = x.shape[0]
        keep = torch.bernoulli(
            torch.full((b, 1, 1, 1, 1), 1 - self.p, device=x.device, dtype=x.dtype)
        )
        return x * keep / (1 - self.p)


class CDA2FPaper(nn.Module):
    """Section 2.3.2 / Fig. 3(b)."""

    def __init__(self, channels: int, stochastic_depth_p: float = 0.1, bn_eps: float = 1e-5):
        super().__init__()
        c = channels
        self.inv = Involution3D(c)
        self.fsa = FrequencySpatialAttention3dCDA(c)
        self.sph = MultiOrientationSphericalProxy3d(c)
        self.cnxt = DepthwiseConvNeXtBlock3d(c, bn_eps=bn_eps)
        self.merge = nn.Sequential(
            nn.Conv3d(2 * c, c, kernel_size=1, bias=False),
            nn.BatchNorm3d(c, eps=bn_eps),
            nn.ReLU(inplace=True),
        )
        self.sum_scale = nn.Parameter(torch.ones(1))
        self.drop = StochasticDepth(stochastic_depth_p)
        self.axial = GatedAxialAttention3d(
            c, dim_head=min(16, max(4, c // 4)), bn_eps=bn_eps
        )

    def _forward_compute(self, x: torch.Tensor) -> torch.Tensor:
        b1, b2, b3 = self.inv(x), self.fsa(x), self.sph(x)
        s = self.sum_scale * (b1 + b2 + b3)
        b4 = self.cnxt(x)
        fused = self.merge(torch.cat([s, b4], dim=1))
        fused = self.drop(fused)
        fused = fused + x
        return self.axial(fused)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return _forward_block_fp32_safe(self, x)
