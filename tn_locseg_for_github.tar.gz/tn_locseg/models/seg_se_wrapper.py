"""
seg_se_wrapper.py
=================
为 nnU-Net 的 PlainConvUNet 分割网络注入 SE (Squeeze-and-Excitation) 通道注意力.

设计原则:
  - 不修改 dynamic_network_architectures 安装包, 以 wrapper 方式注入
  - encoder 每个 stage 输出后加 SEBlock3D
  - decoder 每个 stage 融合 skip 后加 SEBlock3D
  - state_dict 键名保持兼容: encoder.* / decoder.* 与原始 PlainConvUNet 一致,
    新增的 se_encoder.* / se_decoder.* 在加载旧 checkpoint 时自动随机初始化

用法:
  seg_net = get_network_from_plans(...)       # PlainConvUNet
  seg_net = SEPlainConvUNet(seg_net)          # 注入 SE
"""

import torch
import torch.nn as nn


class SEBlock3D(nn.Module):
    """Squeeze-and-Excitation block for 3D features."""

    def __init__(self, channels: int, reduction: int = 16):
        super().__init__()
        reduced = max(channels // reduction, 8)
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.fc = nn.Sequential(
            nn.Linear(channels, reduced, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(reduced, channels, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        b, c = x.shape[:2]
        s = self.pool(x).view(b, c)
        s = self.fc(s).view(b, c, 1, 1, 1)
        return x * s


class SEPlainConvUNet(nn.Module):
    """PlainConvUNet + SE blocks on every encoder and decoder stage.

    Wraps an existing PlainConvUNet instance, reusing its encoder/decoder
    sub-modules directly (same state_dict prefix) and adding SE modules as
    new children (se_encoder / se_decoder).

    Args:
        base_unet: a PlainConvUNet (or compatible) instance.
        se_reduction: SE bottleneck reduction ratio.
    """

    def __init__(self, base_unet: nn.Module, se_reduction: int = 16):
        super().__init__()
        self.encoder = base_unet.encoder
        self.decoder = base_unet.decoder

        for attr in ("key_to_encoder", "key_to_stem", "keys_to_in_proj", "key_to_lpe"):
            if hasattr(base_unet, attr):
                setattr(self, attr, getattr(base_unet, attr))

        enc_channels = self.encoder.output_channels
        self.se_encoder = nn.ModuleList(
            [SEBlock3D(ch, reduction=se_reduction) for ch in enc_channels]
        )

        n_dec_stages = len(self.decoder.stages)
        self.se_decoder = nn.ModuleList(
            [SEBlock3D(enc_channels[-(s + 2)], reduction=se_reduction)
             for s in range(n_dec_stages)]
        )

    def forward(self, x: torch.Tensor):
        skips = []
        for i, stage in enumerate(self.encoder.stages):
            x = stage(x)
            x = self.se_encoder[i](x)
            skips.append(x)

        dec = self.decoder
        lres_input = skips[-1]
        seg_outputs = []
        for s in range(len(dec.stages)):
            x = dec.transpconvs[s](lres_input)
            x = torch.cat((x, skips[-(s + 2)]), 1)
            x = dec.stages[s](x)
            x = self.se_decoder[s](x)
            if dec.deep_supervision:
                seg_outputs.append(dec.seg_layers[s](x))
            elif s == (len(dec.stages) - 1):
                seg_outputs.append(dec.seg_layers[-1](x))
            lres_input = x

        seg_outputs = seg_outputs[::-1]
        if not dec.deep_supervision:
            return seg_outputs[0]
        return seg_outputs

    def compute_conv_feature_map_size(self, input_size):
        return (
            self.encoder.compute_conv_feature_map_size(input_size)
            + self.decoder.compute_conv_feature_map_size(input_size)
        )

    @staticmethod
    def initialize(module):
        from dynamic_network_architectures.initialization.weight_init import InitWeights_He
        InitWeights_He(1e-2)(module)
