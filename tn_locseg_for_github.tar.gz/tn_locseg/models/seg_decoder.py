"""
seg_decoder.py
==============
分割网络模块.

包含:
  1. SegmentationNetwork — 原自定义 3D U-Net (保留兼容)
  2. NnUNetSegNetwork  — nnU-Net v2 PlainConvUNet 包装类 (推荐)

输入: ROI patch (B, 1, 64, 64, 64) — 从 whole brain 裁出的全分辨率 crop
输出: 分割 mask (B, num_classes, 64, 64, 64) + deep supervision outputs
"""

import torch
import torch.nn as nn
import torch.nn.functional as F

from dynamic_network_architectures.architectures.unet import PlainConvUNet
from dynamic_network_architectures.initialization.weight_init import InitWeights_He


class ConvBlock3D(nn.Module):
    """Conv3d - InstanceNorm - LeakyReLU."""

    def __init__(self, in_ch, out_ch, kernel_size=3, stride=1):
        super().__init__()
        padding = kernel_size // 2
        self.block = nn.Sequential(
            nn.Conv3d(in_ch, out_ch, kernel_size, stride=stride, padding=padding, bias=False),
            nn.InstanceNorm3d(out_ch, affine=True),
            nn.LeakyReLU(0.01, inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class ResBlock3D(nn.Module):
    """残差块: 两次 Conv-IN-LReLU + skip."""

    def __init__(self, channels):
        super().__init__()
        self.block = nn.Sequential(
            ConvBlock3D(channels, channels),
            nn.Conv3d(channels, channels, 3, padding=1, bias=False),
            nn.InstanceNorm3d(channels, affine=True),
        )
        self.act = nn.LeakyReLU(0.01, inplace=True)

    def forward(self, x):
        return self.act(x + self.block(x))


class SegEncoder(nn.Module):
    """分割网络的编码器部分."""

    def __init__(self, in_channels=1, channels=(32, 64, 128, 256, 512),
                 num_res_blocks=2):
        super().__init__()
        self.stages = nn.ModuleList()
        self.downsamples = nn.ModuleList()

        ch_in = in_channels
        for i, ch in enumerate(channels):
            blocks = [ConvBlock3D(ch_in, ch)]
            for _ in range(num_res_blocks):
                blocks.append(ResBlock3D(ch))
            self.stages.append(nn.Sequential(*blocks))

            if i < len(channels) - 1:
                self.downsamples.append(
                    nn.Conv3d(ch, ch, 2, stride=2, bias=False)  # strided conv downsample
                )
            ch_in = ch

    def forward(self, x):
        features = []
        for i, stage in enumerate(self.stages):
            x = stage(x)
            features.append(x)
            if i < len(self.downsamples):
                x = self.downsamples[i](x)
        return features


class SegDecoder(nn.Module):
    """分割网络的解码器部分, 支持 deep supervision 和 dropout."""

    def __init__(self, channels=(32, 64, 128, 256, 512), num_classes=3,
                 num_res_blocks=1, deep_supervision=True, dropout=0.0):
        super().__init__()
        self.deep_supervision = deep_supervision
        self.use_dropout = dropout > 0
        reversed_ch = list(reversed(channels))

        self.upsamples = nn.ModuleList()
        self.stages = nn.ModuleList()
        self.ds_heads = nn.ModuleList()  # deep supervision heads
        if self.use_dropout:
            self.dropouts = nn.ModuleList()

        for i in range(len(reversed_ch) - 1):
            ch_in = reversed_ch[i]
            ch_out = reversed_ch[i + 1]

            # 上采样
            self.upsamples.append(
                nn.ConvTranspose3d(ch_in, ch_out, 2, stride=2, bias=False)
            )

            # 解码块 (拼接后通道 = ch_out * 2)
            blocks = [ConvBlock3D(ch_out * 2, ch_out)]
            for _ in range(num_res_blocks):
                blocks.append(ResBlock3D(ch_out))
            self.stages.append(nn.Sequential(*blocks))

            # Dropout (训练时随机丢弃, 推理时关闭)
            if self.use_dropout:
                self.dropouts.append(nn.Dropout3d(p=dropout))

            # Deep supervision 输出头
            if deep_supervision:
                self.ds_heads.append(nn.Conv3d(ch_out, num_classes, 1))

        # 最终输出头
        self.final_head = nn.Conv3d(reversed_ch[-1], num_classes, 1)

    def forward(self, encoder_features):
        """
        参数:
            encoder_features: list of tensors, 从低分辨率到高分辨率
                [最深层特征, ..., 最浅层特征]
                注意: encoder 输出是从浅到深, 这里要反过来

        返回:
            output: 最终分割结果 (B, num_classes, D, H, W)
            ds_outputs: deep supervision 输出列表 (从深到浅, 分辨率递增)
        """
        features = list(reversed(encoder_features))  # 深→浅
        x = features[0]  # 最深层

        ds_outputs = []
        for i, (upsample, stage) in enumerate(zip(self.upsamples, self.stages)):
            x = upsample(x)
            skip = features[i + 1]
            # 处理尺寸不一致
            if x.shape != skip.shape:
                x = F.interpolate(x, size=skip.shape[2:], mode="trilinear",
                                  align_corners=False)
            x = torch.cat([x, skip], dim=1)
            x = stage(x)

            # Dropout (仅训练时生效)
            if self.use_dropout:
                x = self.dropouts[i](x)

            if self.deep_supervision and i < len(self.ds_heads):
                ds_outputs.append(self.ds_heads[i](x))

        output = self.final_head(x)
        return output, ds_outputs


class SegmentationNetwork(nn.Module):
    """
    完整的分割网络 (Encoder + Decoder), 旧版自定义实现.

    输入: (B, 1, D, H, W) ROI patch
    输出: (B, num_classes, D, H, W) 分割结果 + deep supervision

    注: 保留以兼容旧 checkpoint, 新训练建议使用 NnUNetSegNetwork.
    """

    def __init__(self, in_channels=1, num_classes=3,
                 channels=(32, 64, 128, 256, 512),
                 num_res_blocks=2, deep_supervision=True, dropout=0.0):
        super().__init__()
        self.encoder = SegEncoder(in_channels, channels, num_res_blocks)
        self.decoder = SegDecoder(channels, num_classes, num_res_blocks=1,
                                  deep_supervision=deep_supervision, dropout=dropout)

    def forward(self, x):
        features = self.encoder(x)
        output, ds_outputs = self.decoder(features)
        return output, ds_outputs


class NnUNetSegNetwork(nn.Module):
    """
    nnU-Net v2 PlainConvUNet 包装类.

    使用 dynamic_network_architectures 包中经过大规模医学图像分割验证的
    PlainConvUNet 架构, 输出接口与原 SegmentationNetwork 一致:
        forward(x) -> (output, ds_outputs)

    参数:
        in_channels: 输入通道数 (1 for grayscale)
        num_classes: 输出类别数 (3: bg/nerve/vessel)
        features_per_stage: 每个 encoder stage 的特征通道数
        n_conv_per_stage: 每个 encoder stage 的卷积块数
        n_conv_per_stage_decoder: 每个 decoder stage 的卷积块数
        deep_supervision: 是否输出 deep supervision
        dropout: dropout 概率 (0=不使用)
    """

    def __init__(
        self,
        in_channels=1,
        num_classes=3,
        features_per_stage=(32, 64, 128, 256, 320),
        n_conv_per_stage=2,
        n_conv_per_stage_decoder=2,
        deep_supervision=True,
        dropout=0.0,
        use_neurovasc_modules=False,
        neurovasc_mscf=True,
        neurovasc_cda_last_n=2,
        neurovasc_seg_spatial=None,
        neurovasc_cda_stochastic_depth_p=0.1,
    ):
        super().__init__()
        n_stages = len(features_per_stage)

        kernel_sizes = [3] * n_stages
        strides = [1] + [2] * (n_stages - 1)

        dropout_op = nn.Dropout3d if dropout > 0 else None
        dropout_kwargs = {"p": dropout} if dropout > 0 else None

        if isinstance(n_conv_per_stage, int):
            n_conv_per_stage = [n_conv_per_stage] * n_stages
        if isinstance(n_conv_per_stage_decoder, int):
            n_conv_per_stage_decoder = [n_conv_per_stage_decoder] * (n_stages - 1)

        unet_kwargs = dict(
            input_channels=in_channels,
            n_stages=n_stages,
            features_per_stage=list(features_per_stage),
            conv_op=nn.Conv3d,
            kernel_sizes=kernel_sizes,
            strides=strides,
            n_conv_per_stage=n_conv_per_stage,
            num_classes=num_classes,
            n_conv_per_stage_decoder=n_conv_per_stage_decoder,
            conv_bias=False,
            norm_op=nn.InstanceNorm3d,
            norm_op_kwargs={"eps": 1e-5, "affine": True},
            dropout_op=dropout_op,
            dropout_op_kwargs=dropout_kwargs,
            nonlin=nn.LeakyReLU,
            nonlin_kwargs={"inplace": True},
            deep_supervision=deep_supervision,
        )
        if use_neurovasc_modules:
            from .neurovasc_unet import PlainConvUNetNeuroVasc

            nv_spatial = neurovasc_seg_spatial if neurovasc_seg_spatial is not None else (64, 64, 64)
            self.network = PlainConvUNetNeuroVasc(
                neurovasc_mscf=neurovasc_mscf,
                neurovasc_cda_last_n=neurovasc_cda_last_n,
                neurovasc_seg_spatial=tuple(int(x) for x in nv_spatial),
                neurovasc_cda_stochastic_depth_p=float(neurovasc_cda_stochastic_depth_p),
                **unet_kwargs,
            )
        else:
            self.network = PlainConvUNet(**unet_kwargs)
        self.deep_supervision = deep_supervision

        self.network.apply(InitWeights_He(1e-2))

    def forward(self, x):
        """
        参数:
            x: (B, 1, D, H, W) ROI patch

        返回:
            output: (B, num_classes, D, H, W) 全分辨率分割结果
            ds_outputs: list of (B, num_classes, D_i, H_i, W_i) deep supervision
                        分辨率从高到低 (与 PlainConvUNet 原始输出一致)
        """
        out = self.network(x)

        if self.deep_supervision:
            output = out[0]
            ds_outputs = out[1:]
            return output, ds_outputs
        else:
            return out, []
