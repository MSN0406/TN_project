"""
trainer.py
==========
三阶段课程训练器.

Phase 1: 定位网络训练
Phase 2: 分割网络训练 (使用 GT centroid)
Phase 3: 端到端联合训练
"""

import csv
import os
import time
from datetime import datetime

import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F
from torch.nn.parallel import DistributedDataParallel as DDP
from torch.utils.data import DataLoader
from torch.utils.data.distributed import DistributedSampler
from torch.amp import GradScaler, autocast
from tqdm import tqdm

from models.loc_encoder import generate_heatmap_target
from training.losses import (LocalizationLoss, DiceCELoss,
                              DiceFocalBoundaryLoss, DeepSupervisionLoss,
                              soft_dice_heatmap)


class LocSegTrainer:
    """三阶段训练器."""

    def __init__(self, model, train_dataset, val_dataset, cfg, device="cuda",
                 distributed=False, local_rank=0, world_size=1):
        self.distributed = distributed
        self.local_rank = local_rank
        self.world_size = world_size
        self.is_main = (local_rank == 0)  # 仅主进程负责日志 / 保存

        self.model = model.to(device)
        if distributed:
            # find_unused_parameters=True: Phase 1/2 有冻结参数不参与 forward
            self.model = DDP(self.model, device_ids=[local_rank],
                             find_unused_parameters=True)

        self.device = device
        self.cfg = cfg
        self.dual_seg = cfg["segmentation"].get("dual_seg", False)
        self.mask_size = cfg["segmentation"].get("mask_size", 64)  # 原始标注尺寸

        self.train_dataset = train_dataset
        self.val_dataset = val_dataset

        # 损失函数 (需要 .to(device) 确保 class_weights 等 buffer 在正确设备上)
        p1cfg = cfg.get("training", {}).get("phase1", {})
        hm_dice_w = float(p1cfg.get("heatmap_dice_weight", 0.0))
        self.loc_loss_fn = LocalizationLoss(
            heatmap_weight=1.0, centroid_weight=5.0, sharpness_weight=0.5,
            heatmap_dice_weight=hm_dice_w,
        ).to(device)

        self.class_names = cfg["segmentation"].get("class_names",
                                                    ["background", "class1", "class2"])
        ds_weights = cfg["segmentation"].get("deep_supervision_weights", [1.0, 0.5, 0.25])

        if self.dual_seg:
            # 两个独立的 binary 分割损失
            nerve_weights = cfg["segmentation"].get("nerve_class_weights", [0.07, 1.48])
            vessel_weights = cfg["segmentation"].get("vessel_class_weights", [0.07, 1.46])
            nerve_loss = DiceCELoss(
                num_classes=2,
                dice_weight=cfg["loss"]["dice_weight"],
                ce_weight=cfg["loss"]["ce_weight"],
                class_weights=nerve_weights,
            )
            vessel_loss = DiceCELoss(
                num_classes=2,
                dice_weight=cfg["loss"]["dice_weight"],
                ce_weight=cfg["loss"]["ce_weight"],
                class_weights=vessel_weights,
            )
            self.seg_loss_nerve = DeepSupervisionLoss(nerve_loss, weights=ds_weights).to(device)
            self.seg_loss_vessel = DeepSupervisionLoss(vessel_loss, weights=ds_weights).to(device)
        else:
            class_weights = cfg["segmentation"].get("class_weights", None)
            loss_type = cfg["loss"].get("segmentation", "dice_ce")

            if loss_type == "dice_focal_boundary":
                base_seg_loss = DiceFocalBoundaryLoss(
                    num_classes=cfg["segmentation"]["num_classes"],
                    dice_weight=cfg["loss"].get("dice_weight", 1.0),
                    focal_weight=cfg["loss"].get("focal_weight", 1.0),
                    boundary_weight=cfg["loss"].get("boundary_weight", 1.0),
                    gamma=cfg["loss"].get("focal_gamma", 2.0),
                    class_weights=class_weights,
                )
            else:
                dice_class_weights = cfg["loss"].get("dice_class_weights", None)
                base_seg_loss = DiceCELoss(
                    num_classes=cfg["segmentation"]["num_classes"],
                    dice_weight=cfg["loss"]["dice_weight"],
                    ce_weight=cfg["loss"]["ce_weight"],
                    class_weights=class_weights,
                    dice_class_weights=dice_class_weights,
                )

            self.seg_loss_fn = DeepSupervisionLoss(
                base_seg_loss, weights=ds_weights,
            ).to(device)

        # AMP (mixed precision)
        self.scaler = GradScaler("cuda")

        # Best checkpoint 追踪 (按 val metric: Phase1=min dist, Phase2/3=max dice)
        self.best_val_metric = None  # 当前最佳验证指标
        self.best_epoch = 0

        # Logging
        self.log_dir = cfg["output"]["log_dir"]
        self.ckpt_dir = cfg["output"]["checkpoint_dir"]
        os.makedirs(self.log_dir, exist_ok=True)
        os.makedirs(self.ckpt_dir, exist_ok=True)

        # 文本日志 (所有阶段共用一个, 追加写入)
        self.text_log_path = os.path.join(self.log_dir, "training.log")

    # ================================================================
    # DDP 工具
    # ================================================================
    @property
    def raw_model(self):
        """获取原始模型 (解包 DDP wrapper)."""
        if self.distributed:
            return self.model.module
        return self.model

    # ================================================================
    # Mask 对齐工具
    # ================================================================
    def _clamp_mask(self, mask):
        """将越界的 mask 值置为 0 (背景), 防止 F.one_hot 越界."""
        num_classes = self.cfg["segmentation"]["num_classes"]
        mask[mask >= num_classes] = 0
        mask[mask < 0] = 0
        return mask

    @staticmethod
    def _center_crop_5d(tensor, target_shape):
        """
        Center-crop a 5D tensor (B, C, D, H, W) 到目标空间尺寸.

        参数:
            tensor: (B, C, D, H, W) 模型输出
            target_shape: (D', H', W') 目标空间尺寸

        返回:
            cropped: (B, C, D', H', W')
        """
        _, _, d, h, w = tensor.shape
        td, th, tw = target_shape

        if d == td and h == th and w == tw:
            return tensor

        d0 = (d - td) // 2
        h0 = (h - th) // 2
        w0 = (w - tw) // 2
        return tensor[:, :, d0:d0+td, h0:h0+th, w0:w0+tw]

    def _crop_seg_outputs(self, seg_out, ds_outs, mask_shape):
        """
        Center-crop 分割输出 & deep supervision 输出, 使其与 mask 空间对齐.

        模型在 96x96x96 的 ROI 上预测, 但标注只有中心 64x64x64
        (原始标注 48x48x48 → 嵌入到 64x64x64).
        因此把预测裁剪到与 mask 相同大小再计算 loss,
        避免把未标注区域错误地当作 background 监督.

        Deep supervision 输出按相同比例裁剪:
          96→64 (主输出), 48→32, 24→16, 12→8 ...

        参数:
            seg_out: (B, C, crop_D, crop_H, crop_W) 主分割输出
            ds_outs: list of (B, C, D_i, H_i, W_i) deep supervision 输出
            mask_shape: (D, H, W) mask 的空间尺寸 (e.g. 64, 64, 64)

        返回:
            seg_out_cropped, ds_outs_cropped
        """
        seg_cropped = self._center_crop_5d(seg_out, mask_shape)

        crop_size = self.cfg["segmentation"]["crop_size"]
        if isinstance(crop_size, list):
            crop_d, crop_h, crop_w = crop_size
        else:
            crop_d = crop_h = crop_w = crop_size

        ds_cropped = []
        for ds in ds_outs:
            _, _, dd, dh, dw = ds.shape
            target_d = round(mask_shape[0] * dd / crop_d)
            target_h = round(mask_shape[1] * dh / crop_h)
            target_w = round(mask_shape[2] * dw / crop_w)
            ds_cropped.append(self._center_crop_5d(ds, (target_d, target_h, target_w)))

        return seg_cropped, ds_cropped

    # ================================================================
    # Logging
    # ================================================================
    def _log_text(self, msg):
        """Append one line to text log with timestamp (main process only)."""
        if not self.is_main:
            return
        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{ts}] {msg}"
        with open(self.text_log_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")
            f.flush()
        tqdm.write(line)

    def _init_csv(self, phase, fieldnames):
        """Create CSV log if missing; return path (append if exists)."""
        csv_path = os.path.join(self.log_dir, f"phase{phase}_metrics.csv")
        if not os.path.exists(csv_path):
            with open(csv_path, "w", newline="") as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                writer.writeheader()
        return csv_path

    def _append_csv(self, csv_path, fieldnames, row_dict):
        """Append one row to CSV."""
        with open(csv_path, "a", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writerow(row_dict)

    def _make_loader(self, dataset, batch_size, shuffle=True, use_distributed=None):
        """
        创建 DataLoader.

        参数:
            use_distributed: None=自动 (训练用分布式, 验证不用).
                             True/False 可手动覆盖.

        返回:
            (loader, sampler)  sampler 可能为 None
        """
        from data.dataset import locseg_collate_fn

        if use_distributed is None:
            use_distributed = self.distributed

        sampler = None
        if use_distributed:
            sampler = DistributedSampler(dataset, shuffle=shuffle)
            shuffle = False  # sampler 内部处理 shuffle

        loader = DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=shuffle if sampler is None else False,
            sampler=sampler,
            num_workers=self.cfg["training"]["num_workers"],
            pin_memory=self.cfg["training"]["pin_memory"],
            collate_fn=locseg_collate_fn,
            drop_last=True,
        )
        return loader, sampler

    def _make_optimizer(self, params, lr, weight_decay):
        optim_name = self.cfg["training"].get("optimizer", "SGD")
        if optim_name.upper() == "SGD":
            return torch.optim.SGD(
                params, lr=lr, weight_decay=weight_decay,
                momentum=0.99, nesterov=True,
            )
        return torch.optim.AdamW(params, lr=lr, weight_decay=weight_decay)

    def _make_scheduler(self, optimizer, epochs):
        sched_name = self.cfg["training"].get("scheduler", "poly")
        if sched_name == "poly":
            return torch.optim.lr_scheduler.LambdaLR(
                optimizer,
                lr_lambda=lambda ep: (1 - ep / max(epochs, 1)) ** 0.9,
            )
        return torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs)

    # ================================================================
    # Phase 1: 定位训练
    # ================================================================
    def train_phase1(self, resume_ckpt=None):
        """Phase 1: 仅训练定位网络."""
        pcfg = self.cfg["training"]["phase1"]
        if self.is_main:
            print(f"\n{'='*60}")
            print(f"Phase 1: Localization Only ({pcfg['epochs']} epochs)")
            print(f"{'='*60}")

        self.raw_model.set_phase(1)
        self.train_dataset.phase = 1
        self.val_dataset.phase = 1

        loader, train_sampler = self._make_loader(self.train_dataset, pcfg["batch_size"])
        val_loader, _ = self._make_loader(self.val_dataset, pcfg["batch_size"],
                                          shuffle=False, use_distributed=False)

        optimizer = self._make_optimizer(
            filter(lambda p: p.requires_grad, self.model.parameters()),
            lr=pcfg["lr"], weight_decay=pcfg["weight_decay"],
        )
        scheduler = self._make_scheduler(optimizer, pcfg["epochs"])

        # 断点续训
        start_epoch = 1
        if resume_ckpt:
            start_epoch = self.load_checkpoint(resume_ckpt, optimizer, scheduler) + 1
            if self.is_main:
                print(f"  从 epoch {start_epoch} 恢复训练")

        loc_input_size = tuple(self.cfg["localization"]["input_size"])
        sigma = self.cfg["localization"]["heatmap_sigma"]

        # 日志初始化
        self._log_text(
            f"Phase 1 start: epochs={pcfg['epochs']}, lr={pcfg['lr']}, bs={pcfg['batch_size']}, "
            f"from epoch {start_epoch}",
        )
        p1_fields = [
            "epoch", "train_loss", "train_heatmap_dice",
            "val_dist_voxels", "val_heatmap_dice", "lr", "timestamp",
        ]
        p1_csv = self._init_csv(1, p1_fields)

        epoch_pbar = tqdm(range(start_epoch, pcfg["epochs"] + 1),
                          desc="Phase1 Epoch", unit="epoch",
                          initial=start_epoch - 1, total=pcfg["epochs"],
                          disable=not self.is_main)
        for epoch in epoch_pbar:
            if train_sampler is not None:
                train_sampler.set_epoch(epoch)  # DDP: 确保每 epoch 数据 shuffle 不同

            if self.is_main and epoch == start_epoch:
                self._log_text(
                    f"Phase1 epoch {epoch}: batch loop started "
                    f"(training.log may stay sparse until this epoch ends; check tqdm / nvidia-smi)",
                )

            self.model.train()
            epoch_loss = 0.0
            epoch_train_hm_dice = 0.0

            batch_pbar = tqdm(loader, desc=f"  Epoch {epoch}", leave=False, unit="batch",
                              disable=not self.is_main)
            for batch in batch_pbar:
                wb = batch["whole_brain"].to(self.device)
                gt_centroid_norm = batch["centroid_norm"].to(self.device)

                optimizer.zero_grad()
                with autocast("cuda"):
                    result = self.model(wb, gt_centroid_norm)
                    heatmap = result["heatmap"]
                    centroid = result["centroid_norm"]

                    # 生成 GT heatmap
                    gt_heatmap = generate_heatmap_target(
                        gt_centroid_norm, loc_input_size, sigma=sigma,
                    ).to(self.device)

                    loss = self.loc_loss_fn(heatmap, gt_heatmap, centroid, gt_centroid_norm)

                self.scaler.scale(loss).backward()
                self.scaler.step(optimizer)
                self.scaler.update()
                epoch_loss += loss.item()
                with torch.no_grad():
                    pred_h = torch.sigmoid(heatmap.float())
                    gt_h = gt_heatmap.float()
                    batch_hm_dice = soft_dice_heatmap(pred_h, gt_h).item()
                epoch_train_hm_dice += batch_hm_dice
                batch_pbar.set_postfix(
                    loss=f"{loss.item():.4f}",
                    hm_dice=f"{batch_hm_dice:.3f}",
                )

            scheduler.step()
            avg_loss = epoch_loss / len(loader)
            avg_train_hm_dice = epoch_train_hm_dice / max(len(loader), 1)
            cur_lr = scheduler.get_last_lr()[0]

            # 更新 epoch 进度条 (训练集平均定位 heatmap Dice)
            epoch_pbar.set_postfix(
                loss=f"{avg_loss:.4f}",
                train_hm_dice=f"{avg_train_hm_dice:.4f}",
                lr=f"{cur_lr:.2e}",
            )

            # 验证 (每 5 epoch) + 文本日志: 非验证 epoch 也记录训练集 HM Dice
            val_dist = None
            val_hm_dice = None
            if epoch % 5 == 0 or epoch == pcfg["epochs"]:
                val_dist, val_hm_dice = self._validate_loc(val_loader, loc_input_size, sigma)
                msg = (f"Phase1 Epoch {epoch}/{pcfg['epochs']} | "
                       f"Loss={avg_loss:.6f} | "
                       f"Train HM Dice={avg_train_hm_dice:.4f} | "
                       f"Val Dist={val_dist:.2f} vox | "
                       f"Val HM Dice={val_hm_dice:.4f} | "
                       f"LR={cur_lr:.2e}")
                self._log_text(msg)

                # 保存 best checkpoint (Phase1: 越小越好)
                self._update_best(val_dist, epoch, phase=1,
                                  optimizer=optimizer, scheduler=scheduler,
                                  mode="min")
            elif self.is_main:
                self._log_text(
                    f"Phase1 Epoch {epoch}/{pcfg['epochs']} | "
                    f"Loss={avg_loss:.6f} | Train HM Dice={avg_train_hm_dice:.4f} | "
                    f"LR={cur_lr:.2e}",
                )

            # 写 CSV (每个 epoch 都记录, 仅主进程)
            if self.is_main:
                self._append_csv(p1_csv, p1_fields, {
                    "epoch": epoch,
                    "train_loss": f"{avg_loss:.6f}",
                    "train_heatmap_dice": f"{avg_train_hm_dice:.4f}",
                    "val_dist_voxels": f"{val_dist:.2f}" if val_dist is not None else "",
                    "val_heatmap_dice": f"{val_hm_dice:.4f}" if val_hm_dice is not None else "",
                    "lr": f"{cur_lr:.2e}",
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                })

            if epoch % self.cfg["output"]["save_every"] == 0:
                self._save_checkpoint(f"phase1_epoch{epoch}.pth",
                                      optimizer=optimizer, scheduler=scheduler,
                                      epoch=epoch, phase=1)

        self._save_checkpoint("phase1_final.pth",
                              optimizer=optimizer, scheduler=scheduler,
                              epoch=pcfg["epochs"], phase=1)
        self._log_text(f"Phase 1 完成. Best val_dist={self.best_val_metric:.2f} @ epoch {self.best_epoch}")

    def _validate_loc(self, loader, loc_input_size, sigma):
        """
        验证集: 平均质心距离 (体素) + 选中 heatmap 与 GT 高斯的 Soft Dice (越大越好).
        返回 (mean_dist_voxels, mean_heatmap_dice).
        """
        self.model.eval()
        total_dist = 0.0
        count = 0
        total_hm_dice = 0.0
        count_hm = 0

        with torch.no_grad():
            for batch in loader:
                wb = batch["whole_brain"].to(self.device)
                gt_norm = batch["centroid_norm"].to(self.device)
                wb_shape = batch["wb_shape"].to(self.device)

                result = self.model(wb, gt_norm)
                pred_norm = result["centroid_norm"]

                # 转换为体素坐标计算距离
                pred_vox = pred_norm * (wb_shape - 1)
                gt_vox = gt_norm * (wb_shape - 1)
                dist = torch.norm(pred_vox - gt_vox, dim=1)  # (B,)
                total_dist += dist.sum().item()
                count += dist.shape[0]

                # Heatmap Soft Dice (与 Phase1 训练目标一致)
                heatmap = result["heatmap"]
                gt_h = generate_heatmap_target(
                    gt_norm, loc_input_size, sigma=sigma,
                ).to(self.device)
                pred_h = torch.sigmoid(heatmap)
                for b in range(pred_h.shape[0]):
                    d = soft_dice_heatmap(pred_h[b:b+1], gt_h[b:b+1])
                    total_hm_dice += d.item()
                    count_hm += 1

        mean_dist = total_dist / max(count, 1)
        mean_hm_dice = total_hm_dice / max(count_hm, 1)
        return mean_dist, mean_hm_dice

    # ================================================================
    # Phase 2: 分割训练
    # ================================================================
    def train_phase2(self, resume_ckpt=None):
        """Phase 2: 仅训练分割网络, 使用 GT centroid."""
        pcfg = self.cfg["training"]["phase2"]
        if int(pcfg.get("epochs", 0)) <= 0:
            if self.is_main:
                print("\n[Phase 2] training.phase2.epochs=0 → 跳过 Phase 2")
                self._log_text("Phase 2 跳过 (epochs=0), 直接进入后续阶段")
            return

        if self.is_main:
            print(f"\n{'='*60}")
            print(f"Phase 2: Segmentation Only ({pcfg['epochs']} epochs)")
            print(f"{'='*60}")

        self.raw_model.set_phase(2)
        self.best_val_metric = None  # 重置 best tracker
        self.best_epoch = 0
        self.train_dataset.phase = 2
        self.val_dataset.phase = 2

        loader, train_sampler = self._make_loader(self.train_dataset, pcfg["batch_size"])
        val_loader, _ = self._make_loader(self.val_dataset, pcfg["batch_size"],
                                          shuffle=False, use_distributed=False)

        optimizer = self._make_optimizer(
            filter(lambda p: p.requires_grad, self.model.parameters()),
            lr=pcfg["lr"], weight_decay=pcfg["weight_decay"],
        )
        scheduler = self._make_scheduler(optimizer, pcfg["epochs"])

        # 断点续训
        start_epoch = 1
        if resume_ckpt:
            start_epoch = self.load_checkpoint(resume_ckpt, optimizer, scheduler) + 1
            if self.is_main:
                print(f"  从 epoch {start_epoch} 恢复训练")

        # 日志初始化
        self._log_text(f"Phase 2 开始: epochs={pcfg['epochs']}, lr={pcfg['lr']}, bs={pcfg['batch_size']}, 从 epoch {start_epoch} 开始")
        p2_fields = ["epoch", "train_loss", "val_dice", "lr", "timestamp"]
        p2_csv = self._init_csv(2, p2_fields)

        epoch_pbar = tqdm(range(start_epoch, pcfg["epochs"] + 1),
                          desc="Phase2 Epoch", unit="epoch",
                          initial=start_epoch - 1, total=pcfg["epochs"],
                          disable=not self.is_main)
        for epoch in epoch_pbar:
            if train_sampler is not None:
                train_sampler.set_epoch(epoch)

            self.model.train()
            epoch_loss = 0.0

            batch_pbar = tqdm(loader, desc=f"  Epoch {epoch}", leave=False,
                              unit="batch", disable=not self.is_main)
            for batch in batch_pbar:
                wb = batch["whole_brain"].to(self.device)
                gt_centroid = batch["centroid_norm"].to(self.device)
                mask = batch["mask"].to(self.device)
                mask = self._clamp_mask(mask)

                optimizer.zero_grad()
                with autocast("cuda"):
                    result = self.model(wb, gt_centroid)

                    if self.dual_seg:
                        # 两个独立网络各自计算 loss
                        nerve_out, nerve_ds = result["seg_nerve"], result["ds_nerve"]
                        vessel_out, vessel_ds = result["seg_vessel"], result["ds_vessel"]
                        # Center-crop (如果 crop > mask)
                        nerve_out, nerve_ds = self._crop_seg_outputs(
                            nerve_out, nerve_ds, mask.shape[1:])
                        vessel_out, vessel_ds = self._crop_seg_outputs(
                            vessel_out, vessel_ds, mask.shape[1:])
                        # 拆分 binary mask: nerve=1→1, vessel=2→bg; vessel=2→1, nerve=1→bg
                        nerve_mask = (mask == 1).long()
                        vessel_mask = (mask == 2).long()
                        loss_n = self.seg_loss_nerve(nerve_out, nerve_ds, nerve_mask)
                        loss_v = self.seg_loss_vessel(vessel_out, vessel_ds, vessel_mask)
                        loss = loss_n + loss_v
                    else:
                        seg_out = result["seg_output"]
                        ds_outs = result["ds_outputs"]
                        seg_out, ds_outs = self._crop_seg_outputs(
                            seg_out, ds_outs, mask.shape[1:])
                        loss = self.seg_loss_fn(seg_out, ds_outs, mask)

                self.scaler.scale(loss).backward()
                self.scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=12.0)
                self.scaler.step(optimizer)
                self.scaler.update()
                epoch_loss += loss.item()
                batch_pbar.set_postfix(loss=f"{loss.item():.4f}")

            scheduler.step()
            avg_loss = epoch_loss / len(loader)
            cur_lr = scheduler.get_last_lr()[0]

            # 更新 epoch 进度条
            epoch_pbar.set_postfix(loss=f"{avg_loss:.4f}", lr=f"{cur_lr:.2e}")

            val_dice = None
            if epoch % 5 == 0 or epoch == pcfg["epochs"]:
                show_detail = (epoch % 20 == 0 or epoch == pcfg["epochs"])
                val_dice = self._validate_seg(val_loader, verbose=show_detail)
                msg = (f"Phase2 Epoch {epoch}/{pcfg['epochs']} | "
                       f"Loss={avg_loss:.6f} | "
                       f"Val Dice={val_dice:.4f} | "
                       f"LR={cur_lr:.2e}")
                self._log_text(msg)

                # 保存 best checkpoint (Phase2: Dice 越大越好)
                self._update_best(val_dice, epoch, phase=2,
                                  optimizer=optimizer, scheduler=scheduler,
                                  mode="max")

            # 写 CSV (每个 epoch 都记录, 仅主进程)
            if self.is_main:
                self._append_csv(p2_csv, p2_fields, {
                    "epoch": epoch,
                    "train_loss": f"{avg_loss:.6f}",
                    "val_dice": f"{val_dice:.4f}" if val_dice is not None else "",
                    "lr": f"{cur_lr:.2e}",
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                })

            if epoch % self.cfg["output"]["save_every"] == 0:
                self._save_checkpoint(f"phase2_epoch{epoch}.pth",
                                      optimizer=optimizer, scheduler=scheduler,
                                      epoch=epoch, phase=2)

        self._save_checkpoint("phase2_final.pth",
                              optimizer=optimizer, scheduler=scheduler,
                              epoch=pcfg["epochs"], phase=2)
        self._log_text(f"Phase 2 完成. Best val_dice={self.best_val_metric:.4f} @ epoch {self.best_epoch}")

    def _validate_seg(self, loader, verbose=False):
        """
        计算验证集上的 per-class Dice score.

        返回:
            mean_dice: 前景类平均 Dice
        同时打印 nerve 和 vessel 各自的 Dice (verbose=True 时).
        """
        self.model.eval()
        num_classes = self.cfg["segmentation"]["num_classes"]

        # per-class 累计 (nerve=1, vessel=2)
        class_dice_sum = {c: 0.0 for c in range(1, num_classes)}
        class_count = {c: 0 for c in range(1, num_classes)}

        with torch.no_grad():
            for batch in loader:
                wb = batch["whole_brain"].to(self.device)
                gt_centroid = batch["centroid_norm"].to(self.device)
                mask = batch["mask"].to(self.device)
                mask = self._clamp_mask(mask)

                result = self.model(wb, gt_centroid)

                if self.dual_seg:
                    # 从两个 binary 网络重建多类预测
                    nerve_out = self._center_crop_5d(result["seg_nerve"], mask.shape[1:])
                    vessel_out = self._center_crop_5d(result["seg_vessel"], mask.shape[1:])
                    nerve_pred = torch.argmax(nerve_out, dim=1)   # (B, D, H, W), 0 or 1
                    vessel_pred = torch.argmax(vessel_out, dim=1)
                    # 合并: nerve=1, vessel=2
                    pred = torch.zeros_like(nerve_pred)
                    pred[nerve_pred == 1] = 1
                    pred[vessel_pred == 1] = 2
                    # 重叠: 用 softmax 置信度决定
                    overlap = (nerve_pred == 1) & (vessel_pred == 1)
                    if overlap.any():
                        nerve_conf = torch.softmax(nerve_out, dim=1)[:, 1]  # (B, D, H, W)
                        vessel_conf = torch.softmax(vessel_out, dim=1)[:, 1]
                        pred[overlap & (vessel_conf > nerve_conf)] = 2
                        pred[overlap & (nerve_conf >= vessel_conf)] = 1
                else:
                    seg_out = result["seg_output"]
                    seg_out = self._center_crop_5d(seg_out, mask.shape[1:])
                    pred = torch.argmax(seg_out, dim=1)

                for b in range(pred.shape[0]):
                    for c in range(1, num_classes):
                        pred_c = (pred[b] == c).float()
                        gt_c = (mask[b] == c).float()
                        intersection = (pred_c * gt_c).sum()
                        union = pred_c.sum() + gt_c.sum()
                        if union > 0:
                            dice = (2 * intersection / union).item()
                            class_dice_sum[c] += dice
                            class_count[c] += 1

        # Per-class 平均
        class_dice_avg = {}
        for c in range(1, num_classes):
            class_dice_avg[c] = class_dice_sum[c] / max(class_count[c], 1)

        if verbose and self.is_main:
            for c in range(1, num_classes):
                name = self.class_names[c] if c < len(self.class_names) else f"class{c}"
                print(f"    {name}: Dice={class_dice_avg[c]:.4f} (n={class_count[c]})")

        # 前景类均值
        mean_dice = sum(class_dice_avg.values()) / max(len(class_dice_avg), 1)
        return mean_dice

    # ================================================================
    # Phase 3: 联合训练
    # ================================================================
    def train_phase3(self, resume_ckpt=None):
        """Phase 3: 端到端联合微调."""
        pcfg = self.cfg["training"]["phase3"]
        if self.is_main:
            print(f"\n{'='*60}")
            print(f"Phase 3: Joint Fine-tuning ({pcfg['epochs']} epochs)")
            print(f"{'='*60}")

        self.raw_model.set_phase(3)
        self.best_val_metric = None  # 重置 best tracker
        self.best_epoch = 0
        self.train_dataset.phase = 3
        self.val_dataset.phase = 3

        loader, train_sampler = self._make_loader(self.train_dataset, pcfg["batch_size"])
        val_loader, _ = self._make_loader(self.val_dataset, pcfg["batch_size"],
                                          shuffle=False, use_distributed=False)

        optimizer = self._make_optimizer(
            self.model.parameters(),
            lr=pcfg["lr"], weight_decay=pcfg["weight_decay"],
        )
        scheduler = self._make_scheduler(optimizer, pcfg["epochs"])

        # 断点续训
        start_epoch = 1
        if resume_ckpt:
            start_epoch = self.load_checkpoint(resume_ckpt, optimizer, scheduler) + 1
            if self.is_main:
                print(f"  从 epoch {start_epoch} 恢复训练")

        loc_input_size = tuple(self.cfg["localization"]["input_size"])
        sigma = self.cfg["localization"]["heatmap_sigma"]
        loc_w = pcfg["loc_loss_weight"]
        seg_w = pcfg["seg_loss_weight"]

        # 日志初始化
        self._log_text(f"Phase 3 开始: epochs={pcfg['epochs']}, lr={pcfg['lr']}, bs={pcfg['batch_size']}, 从 epoch {start_epoch} 开始")
        p3_fields = [
            "epoch", "train_loc_loss", "train_seg_loss", "train_heatmap_dice",
            "val_dist_voxels", "val_heatmap_dice", "val_dice", "lr", "timestamp",
        ]
        p3_csv = self._init_csv(3, p3_fields)

        epoch_pbar = tqdm(range(start_epoch, pcfg["epochs"] + 1),
                          desc="Phase3 Epoch", unit="epoch",
                          initial=start_epoch - 1, total=pcfg["epochs"],
                          disable=not self.is_main)
        for epoch in epoch_pbar:
            if train_sampler is not None:
                train_sampler.set_epoch(epoch)

            self.model.train()
            epoch_loc_loss = 0.0
            epoch_seg_loss = 0.0
            epoch_train_hm_dice = 0.0

            batch_pbar = tqdm(loader, desc=f"  Epoch {epoch}", leave=False,
                              unit="batch", disable=not self.is_main)
            for batch in batch_pbar:
                wb = batch["whole_brain"].to(self.device)
                gt_centroid = batch["centroid_norm"].to(self.device)
                mask = batch["mask"].to(self.device)
                mask = self._clamp_mask(mask)

                optimizer.zero_grad()
                with autocast("cuda"):
                    result = self.model(wb, gt_centroid)

                    # 定位损失
                    gt_heatmap = generate_heatmap_target(
                        gt_centroid, loc_input_size, sigma=sigma,
                    ).to(self.device)
                    loc_loss = self.loc_loss_fn(
                        result["heatmap"], gt_heatmap,
                        result["centroid_norm"], gt_centroid,
                    )

                    # 分割损失 (center-crop 到 mask 尺寸)
                    if self.dual_seg:
                        nerve_out, nerve_ds = self._crop_seg_outputs(
                            result["seg_nerve"], result["ds_nerve"], mask.shape[1:])
                        vessel_out, vessel_ds = self._crop_seg_outputs(
                            result["seg_vessel"], result["ds_vessel"], mask.shape[1:])
                        nerve_mask = (mask == 1).long()
                        vessel_mask = (mask == 2).long()
                        seg_loss = (self.seg_loss_nerve(nerve_out, nerve_ds, nerve_mask)
                                    + self.seg_loss_vessel(vessel_out, vessel_ds, vessel_mask))
                    else:
                        seg_out_c, ds_outs_c = self._crop_seg_outputs(
                            result["seg_output"], result["ds_outputs"], mask.shape[1:])
                        seg_loss = self.seg_loss_fn(seg_out_c, ds_outs_c, mask)

                    total_loss = loc_w * loc_loss + seg_w * seg_loss

                self.scaler.scale(total_loss).backward()
                self.scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=12.0)
                self.scaler.step(optimizer)
                self.scaler.update()
                epoch_loc_loss += loc_loss.item()
                epoch_seg_loss += seg_loss.item()
                with torch.no_grad():
                    hm = result["heatmap"]
                    pred_h = torch.sigmoid(hm.float())
                    batch_hm_dice = soft_dice_heatmap(pred_h, gt_heatmap.float()).item()
                epoch_train_hm_dice += batch_hm_dice
                batch_pbar.set_postfix(
                    loc=f"{loc_loss.item():.4f}",
                    seg=f"{seg_loss.item():.4f}",
                    hm_dice=f"{batch_hm_dice:.3f}",
                )

            scheduler.step()
            avg_loc = epoch_loc_loss / len(loader)
            avg_seg = epoch_seg_loss / len(loader)
            avg_train_hm_dice = epoch_train_hm_dice / max(len(loader), 1)
            cur_lr = scheduler.get_last_lr()[0]

            # 更新 epoch 进度条
            epoch_pbar.set_postfix(
                loc=f"{avg_loc:.4f}",
                seg=f"{avg_seg:.4f}",
                train_hm_dice=f"{avg_train_hm_dice:.4f}",
                lr=f"{cur_lr:.2e}",
            )

            val_dist = None
            val_hm_dice = None
            val_dice = None
            if epoch % 5 == 0 or epoch == pcfg["epochs"]:
                val_dist, val_hm_dice = self._validate_loc(val_loader, loc_input_size, sigma)
                show_detail = (epoch % 20 == 0 or epoch == pcfg["epochs"])
                val_dice = self._validate_seg(val_loader, verbose=show_detail)
                msg = (f"Phase3 Epoch {epoch}/{pcfg['epochs']} | "
                       f"Loc={avg_loc:.6f} Seg={avg_seg:.6f} | "
                       f"Train HM Dice={avg_train_hm_dice:.4f} | "
                       f"Val Dist={val_dist:.2f} Val HM_Dice={val_hm_dice:.4f} "
                       f"Seg_Dice={val_dice:.4f}")
                self._log_text(msg)

                # 保存 best checkpoint (Phase3: Dice 越大越好)
                self._update_best(val_dice, epoch, phase=3,
                                  optimizer=optimizer, scheduler=scheduler,
                                  mode="max")
            elif self.is_main:
                self._log_text(
                    f"Phase3 Epoch {epoch}/{pcfg['epochs']} | "
                    f"Loc={avg_loc:.6f} Seg={avg_seg:.6f} | "
                    f"Train HM Dice={avg_train_hm_dice:.4f} | LR={cur_lr:.2e}",
                )

            # 写 CSV (每个 epoch 都记录, 仅主进程)
            if self.is_main:
                self._append_csv(p3_csv, p3_fields, {
                    "epoch": epoch,
                    "train_loc_loss": f"{avg_loc:.6f}",
                    "train_seg_loss": f"{avg_seg:.6f}",
                    "train_heatmap_dice": f"{avg_train_hm_dice:.4f}",
                    "val_dist_voxels": f"{val_dist:.2f}" if val_dist is not None else "",
                    "val_heatmap_dice": f"{val_hm_dice:.4f}" if val_hm_dice is not None else "",
                    "val_dice": f"{val_dice:.4f}" if val_dice is not None else "",
                    "lr": f"{cur_lr:.2e}",
                    "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                })

            if epoch % self.cfg["output"]["save_every"] == 0:
                self._save_checkpoint(f"phase3_epoch{epoch}.pth",
                                      optimizer=optimizer, scheduler=scheduler,
                                      epoch=epoch, phase=3)

        self._save_checkpoint("phase3_final.pth",
                              optimizer=optimizer, scheduler=scheduler,
                              epoch=pcfg["epochs"], phase=3)
        self._log_text(f"Phase 3 完成. Best val_dice={self.best_val_metric:.4f} @ epoch {self.best_epoch}")

    # ================================================================
    # 工具方法
    # ================================================================
    def _save_checkpoint(self, filename, optimizer=None, scheduler=None, epoch=None, phase=None):
        """保存 checkpoint. 仅主进程执行, 确保 checkpoint 格式与单卡一致."""
        if not self.is_main:
            return
        path = os.path.join(self.ckpt_dir, filename)
        ckpt = {
            "model_state": self.raw_model.state_dict(),  # 解包 DDP, 保持 key 一致
            "phase": phase or self.raw_model._phase,
        }
        if optimizer is not None:
            ckpt["optimizer_state"] = optimizer.state_dict()
        if scheduler is not None:
            ckpt["scheduler_state"] = scheduler.state_dict()
        if epoch is not None:
            ckpt["epoch"] = epoch
        ckpt["scaler_state"] = self.scaler.state_dict()
        torch.save(ckpt, path)
        tqdm.write(f"  [CKPT] Saved: {path}")

    def _update_best(self, val_metric, epoch, phase, optimizer=None, scheduler=None,
                     mode="max"):
        """
        检查当前验证指标是否为最佳, 如果是则保存 best checkpoint.

        参数:
            val_metric: 当前验证指标 (Dice=越大越好, Dist=越小越好)
            epoch: 当前 epoch
            phase: 当前 phase
            mode: "max" (Dice) 或 "min" (Dist)
            optimizer/scheduler: 传入以保存完整训练状态
        """
        if val_metric is None:
            return

        is_better = False
        if self.best_val_metric is None:
            is_better = True
        elif mode == "max" and val_metric > self.best_val_metric:
            is_better = True
        elif mode == "min" and val_metric < self.best_val_metric:
            is_better = True

        if is_better:
            old_best = self.best_val_metric
            self.best_val_metric = val_metric
            self.best_epoch = epoch
            self._save_checkpoint(
                f"phase{phase}_best.pth",
                optimizer=optimizer, scheduler=scheduler,
                epoch=epoch, phase=phase,
            )
            if self.is_main:
                direction = "↑" if mode == "max" else "↓"
                old_str = f"{old_best:.4f}" if old_best is not None else "N/A"
                tqdm.write(f"  [BEST] Phase{phase} epoch {epoch}: "
                           f"{old_str} → {val_metric:.4f} {direction}")

    def load_checkpoint(self, path, optimizer=None, scheduler=None):
        """加载 checkpoint, 返回已恢复的 epoch 数 (如果有)."""
        # 先加载到 CPU, 避免在 GPU 上产生额外的显存开销
        ckpt = torch.load(path, map_location="cpu")
        self.raw_model.load_state_dict(ckpt["model_state"])  # 解包 DDP 加载
        if optimizer is not None and "optimizer_state" in ckpt:
            optimizer.load_state_dict(ckpt["optimizer_state"])
        if scheduler is not None and "scheduler_state" in ckpt:
            scheduler.load_state_dict(ckpt["scheduler_state"])
        if "scaler_state" in ckpt:
            self.scaler.load_state_dict(ckpt["scaler_state"])
        resumed_epoch = ckpt.get("epoch", 0)
        phase = ckpt.get("phase", None)
        del ckpt  # 释放 CPU 内存
        if self.device.startswith("cuda"):
            torch.cuda.empty_cache()
        if self.is_main:
            print(f"[LOAD] Loaded checkpoint: {path} (phase={phase}, epoch={resumed_epoch})")
        return resumed_epoch

    def train_all(self):
        """运行完整的三阶段训练."""
        t0 = time.time()
        self.train_phase1()
        if int(self.cfg["training"]["phase2"].get("epochs", 0)) > 0:
            self.train_phase2()
        elif self.is_main:
            print("\n[Phase 2] epochs=0, 跳过")
        self.train_phase3()
        elapsed = time.time() - t0
        print(f"\n全部训练完成! 总用时: {elapsed/3600:.1f} 小时")
