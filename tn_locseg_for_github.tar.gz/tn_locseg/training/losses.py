"""
losses.py
=========
LocSegNet 损失函数.
  - 定位: Heatmap MSE + Centroid L2
  - 分割: Dice + CrossEntropy (nnUNet 标配) + Deep Supervision
"""

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class DiceLoss(nn.Module):
    """
    Soft Dice Loss, 支持多类 + per-class 加权.

    对于神经/血管这样极度不平衡的分割任务:
      - 默认跳过背景 (ignore_background=True)
      - 支持 dice_class_weights: 对不同前景类给予不同权重
        例如 [0.3, 0.7] 表示 nerve 占 30%, vessel 占 70%
      - 支持返回 per-class dice (用于监控)
    """

    def __init__(self, num_classes=3, smooth=1e-5, ignore_background=True,
                 dice_class_weights=None):
        super().__init__()
        self.num_classes = num_classes
        self.smooth = smooth
        self.ignore_background = ignore_background
        self.dice_class_weights = dice_class_weights

    def forward(self, logits, target, return_per_class=False):
        """
        logits: (B, C, D, H, W)
        target: (B, D, H, W) long

        返回:
            loss: 标量, 1 - weighted_mean(dice)
            per_class_dice: (可选) dict {class_idx: dice_value}
        """
        probs = torch.softmax(logits, dim=1)
        target_onehot = F.one_hot(target, self.num_classes)  # (B, D, H, W, C)
        target_onehot = target_onehot.permute(0, 4, 1, 2, 3).float()  # (B, C, D, H, W)

        dims = (0, 2, 3, 4)
        intersection = (probs * target_onehot).sum(dim=dims)
        union = probs.sum(dim=dims) + target_onehot.sum(dim=dims)

        per_class_dice = (2 * intersection + self.smooth) / (union + self.smooth)

        start_idx = 1 if self.ignore_background else 0
        fg_dice = per_class_dice[start_idx:]

        if self.dice_class_weights is not None:
            w = torch.tensor(self.dice_class_weights, dtype=fg_dice.dtype,
                             device=fg_dice.device)
            w = w / w.sum()
            loss = 1 - (w * fg_dice).sum()
        else:
            loss = 1 - fg_dice.mean()

        if return_per_class:
            dice_dict = {i: per_class_dice[i].item() for i in range(self.num_classes)}
            return loss, dice_dict
        return loss


class DiceCELoss(nn.Module):
    """
    Dice + CrossEntropy 组合损失 (nnUNet 标配).

    针对神经/血管分割的改进:
      - Dice loss 仅计算前景类 (nerve + vessel), 不受背景主导
      - CE loss 使用类别权重, 大幅降低背景权重
      - 支持返回 per-class dice 用于监控
    """

    def __init__(self, num_classes=3, dice_weight=1.0, ce_weight=1.0,
                 class_weights=None, dice_class_weights=None):
        super().__init__()
        self.dice_loss = DiceLoss(num_classes=num_classes, ignore_background=True,
                                  dice_class_weights=dice_class_weights)
        self.dice_weight = dice_weight
        self.ce_weight = ce_weight
        self.num_classes = num_classes

        if class_weights is not None:
            self.register_buffer("class_weights",
                                 torch.tensor(class_weights, dtype=torch.float32))
        else:
            self.class_weights = None

    def forward(self, logits, target, return_per_class=False):
        """
        logits: (B, C, D, H, W)
        target: (B, D, H, W) long
        """
        if return_per_class:
            dice, dice_dict = self.dice_loss(logits, target, return_per_class=True)
        else:
            dice = self.dice_loss(logits, target)

        ce = F.cross_entropy(logits, target, weight=self.class_weights)
        loss = self.dice_weight * dice + self.ce_weight * ce

        if return_per_class:
            return loss, dice_dict
        return loss


class FocalLoss(nn.Module):
    """
    Focal Loss (Lin et al., 2017).

    对容易分类的样本降低权重, 让模型聚焦困难样本 (如细小的 nerve/vessel 边界).

    公式: FL(p) = -α * (1-p)^γ * log(p)
      - γ (gamma): 聚焦参数, 越大越忽略简单样本. 常用 γ=2.
      - α: 类别权重, 同 CE 的 class_weights.
    """

    def __init__(self, num_classes=3, gamma=2.0, class_weights=None):
        super().__init__()
        self.num_classes = num_classes
        self.gamma = gamma

        if class_weights is not None:
            self.register_buffer("class_weights",
                                 torch.tensor(class_weights, dtype=torch.float32))
        else:
            self.class_weights = None

    def forward(self, logits, target):
        """
        logits: (B, C, D, H, W)
        target: (B, D, H, W) long
        """
        # 计算标准 CE (per-pixel, 不做 reduction)
        ce = F.cross_entropy(logits, target, weight=self.class_weights,
                             reduction="none")  # (B, D, H, W)

        # 获取每个像素对正确类别的预测概率
        probs = torch.softmax(logits, dim=1)  # (B, C, D, H, W)
        # gather: 取出每个像素在 target 类别上的概率
        pt = probs.gather(1, target.unsqueeze(1)).squeeze(1)  # (B, D, H, W)

        # Focal 调制因子: (1 - pt)^γ
        focal_weight = (1 - pt) ** self.gamma

        loss = (focal_weight * ce).mean()
        return loss


class BoundaryLoss(nn.Module):
    """
    Boundary Loss (Kervadec et al., 2019).

    使用 GT mask 的有符号距离变换 (signed distance transform) 加权预测概率,
    引导模型关注边界精度而非仅像素重叠.

    原理:
      - 距离图 φ: 边界=0, 目标内部<0, 目标外部>0
      - Loss = Σ φ(x) · p(x), 鼓励 p(x) 在 φ<0 处高, φ>0 处低
      - 对细长结构 (vessel) 特别有效: 即使预测稍有偏移,
        距离信息也能给出有意义的梯度方向
    """

    def __init__(self, num_classes=3, ignore_background=True):
        super().__init__()
        self.num_classes = num_classes
        self.ignore_background = ignore_background

    @staticmethod
    def _compute_distance_map(target_np, num_classes):
        """
        计算每个类别的有符号距离变换.

        参数:
            target_np: (D, H, W) numpy array, int
            num_classes: int

        返回:
            dist_maps: (C, D, H, W) numpy array, float32
        """
        from scipy.ndimage import distance_transform_edt

        dist_maps = np.zeros((num_classes, *target_np.shape), dtype=np.float32)
        for c in range(num_classes):
            binary = (target_np == c).astype(np.float64)
            if binary.sum() == 0 or binary.sum() == binary.size:
                # 类别不存在或占满全图 → 距离图全 0 (不贡献 loss)
                continue
            pos_dist = distance_transform_edt(1 - binary)  # 外部到边界的距离 (>0)
            neg_dist = distance_transform_edt(binary)       # 内部到边界的距离 (>0)
            dist_maps[c] = (pos_dist - neg_dist).astype(np.float32)
        return dist_maps

    def forward(self, logits, target):
        """
        logits: (B, C, D, H, W)
        target: (B, D, H, W) long
        """
        probs = torch.softmax(logits, dim=1)  # (B, C, D, H, W)
        B = target.shape[0]

        # 计算距离图 (在 CPU 上用 scipy, 结果搬回 GPU)
        target_np = target.detach().cpu().numpy()
        dist_maps = np.stack([
            self._compute_distance_map(target_np[b], self.num_classes)
            for b in range(B)
        ])  # (B, C, D, H, W)
        dist_maps = torch.from_numpy(dist_maps).to(logits.device)

        # 仅计算前景类别
        start_idx = 1 if self.ignore_background else 0
        loss = (probs[:, start_idx:] * dist_maps[:, start_idx:]).mean()
        return loss


class DiceFocalBoundaryLoss(nn.Module):
    """
    Dice + Focal + Boundary 组合损失.

    三个损失各司其职:
      - Dice Loss: 直接优化分割重叠度 (对类别不平衡鲁棒)
      - Focal Loss: 聚焦困难像素, 减少背景主导 (替代标准 CE)
      - Boundary Loss: 提供空间距离信息, 改善边界精度

    接口与 DiceCELoss 一致, 可作为 drop-in replacement.
    """

    def __init__(self, num_classes=3, dice_weight=1.0, focal_weight=1.0,
                 boundary_weight=1.0, gamma=2.0, class_weights=None):
        super().__init__()
        self.dice_loss = DiceLoss(num_classes=num_classes, ignore_background=True)
        self.focal_loss = FocalLoss(num_classes=num_classes, gamma=gamma,
                                    class_weights=class_weights)
        self.boundary_loss = BoundaryLoss(num_classes=num_classes,
                                          ignore_background=True)
        self.dice_weight = dice_weight
        self.focal_weight = focal_weight
        self.boundary_weight = boundary_weight
        self.num_classes = num_classes

    def forward(self, logits, target, return_per_class=False):
        """
        logits: (B, C, D, H, W)
        target: (B, D, H, W) long
        """
        if return_per_class:
            dice, dice_dict = self.dice_loss(logits, target, return_per_class=True)
        else:
            dice = self.dice_loss(logits, target)

        focal = self.focal_loss(logits, target)
        boundary = self.boundary_loss(logits, target)

        loss = (self.dice_weight * dice
                + self.focal_weight * focal
                + self.boundary_weight * boundary)

        if return_per_class:
            return loss, dice_dict
        return loss


class DeepSupervisionLoss(nn.Module):
    """带 Deep Supervision 的分割损失."""

    def __init__(self, base_loss, weights=(1.0, 0.5, 0.25, 0.125)):
        super().__init__()
        self.base_loss = base_loss
        self.weights = weights

    def forward(self, output, ds_outputs, target):
        """
        output: 最终分割输出 (B, C, D, H, W)
        ds_outputs: deep supervision 输出列表 (分辨率从低到高)
        target: GT mask (B, D, H, W)
        """
        # 主输出损失
        loss = self.base_loss(output, target)

        # Deep supervision 损失
        for i, ds_out in enumerate(ds_outputs):
            if i >= len(self.weights):
                break
            # 下采样 target 到对应分辨率
            ds_size = ds_out.shape[2:]
            if ds_size != target.shape[1:]:
                target_ds = F.interpolate(
                    target.unsqueeze(1).float(), size=ds_size,
                    mode="nearest",
                ).squeeze(1).long()
            else:
                target_ds = target
            loss += self.weights[i] * self.base_loss(ds_out, target_ds)

        return loss


class WingLoss(nn.Module):
    """
    Wing Loss: 对小误差比 L2 更敏感, 对大误差比 L1 更平滑.
    有效避免坐标回归时所有预测值趋向均值的问题.

    参考: Feng et al., "Wing Loss for Robust Facial Landmark Localisation
          with Convolutional Neural Networks", CVPR 2018.

    公式:
        L(x) = w * ln(1 + |x|/eps)     if |x| < w
        L(x) = |x| - C                  otherwise
    其中 C = w - w * ln(1 + w/eps) 使函数连续.
    """

    def __init__(self, w=0.05, eps=0.01):
        super().__init__()
        self.w = w
        self.eps = eps
        self.C = w - w * torch.log(torch.tensor(1.0 + w / eps)).item()

    def forward(self, pred, target):
        """pred, target: (B, 3) 归一化坐标 [0, 1]."""
        diff = torch.abs(pred - target)
        # Per-axis 计算, 防止某个轴主导 loss
        small = self.w * torch.log(1 + diff / self.eps)
        large = diff - self.C
        loss = torch.where(diff < self.w, small, large)
        # 每个轴独立平均, 然后再平均
        return loss.mean(dim=0).sum()


class PeakSharpnessLoss(nn.Module):
    """
    峰值尖锐度损失: 惩罚平坦的 heatmap, 鼓励尖锐的单峰.

    思路: heatmap 的最大值应该尽量大 (接近 1),
         且 heatmap 的熵应该尽量低 (集中在一个点).
    """

    def __init__(self, peak_weight=1.0, entropy_weight=0.1):
        super().__init__()
        self.peak_weight = peak_weight
        self.entropy_weight = entropy_weight

    def forward(self, heatmap):
        """heatmap: (B, 1, D, H, W) logits (未经 sigmoid/softmax)."""
        B = heatmap.shape[0]
        flat = heatmap.view(B, -1)

        # 1. Peak loss: 最大值应接近高值 (sigmoid 后接近 1)
        max_val = torch.sigmoid(flat.max(dim=1).values)
        peak_loss = (1 - max_val).mean()

        # 2. Entropy loss: 空间分布应该集中
        probs = F.softmax(flat, dim=1)
        entropy = -(probs * torch.log(probs + 1e-8)).sum(dim=1).mean()
        # 归一化: 最大熵 = log(N)
        max_entropy = torch.log(torch.tensor(float(flat.shape[1]), device=flat.device))
        entropy_norm = entropy / max_entropy

        return self.peak_weight * peak_loss + self.entropy_weight * entropy_norm


class LocalizationLoss(nn.Module):
    """
    定位损失 (改进版):
      - Heatmap: Focal MSE (重点关注峰值区域)
      - Centroid: Wing Loss (对小误差敏感, 避免均值回归)
      - Peak Sharpness: 惩罚平坦 heatmap
      - 可选: heatmap soft Dice 项 (1 - Dice), 与 trainer phase1.heatmap_dice_weight 对齐
    """

    def __init__(self, heatmap_weight=1.0, centroid_weight=3.5,
                 sharpness_weight=0.3, heatmap_dice_weight=0.3):
        super().__init__()
        self.heatmap_weight = heatmap_weight
        self.centroid_weight = centroid_weight
        self.sharpness_weight = sharpness_weight
        self.heatmap_dice_weight = heatmap_dice_weight

        self.wing_loss = WingLoss(w=0.05, eps=0.01)
        self.sharpness_loss = PeakSharpnessLoss(peak_weight=1.0, entropy_weight=0.1)

    def forward(self, pred_heatmap, gt_heatmap, pred_centroid, gt_centroid):
        """
        pred_heatmap: (B, 1, D, H, W)
        gt_heatmap: (B, 1, D, H, W) Gaussian target
        pred_centroid: (B, 3) 归一化坐标
        gt_centroid: (B, 3) 归一化坐标
        """
        # 1. Focal MSE on heatmap: 对峰值区域加权
        #    gt 值越大的地方权重越高, 确保网络学到精确的峰位置
        focal_weight = 1 + 5 * gt_heatmap  # 峰值处权重 ~6x
        heatmap_loss = (focal_weight * (pred_heatmap - gt_heatmap) ** 2).mean()

        # 2. Wing loss on centroid (per-axis, 抗均值回归)
        centroid_loss = self.wing_loss(pred_centroid, gt_centroid)

        # 3. Peak sharpness (防止 heatmap 变平坦)
        sharp_loss = self.sharpness_loss(pred_heatmap)

        total = (self.heatmap_weight * heatmap_loss
                 + self.centroid_weight * centroid_loss
                 + self.sharpness_weight * sharp_loss)

        if self.heatmap_dice_weight > 0:
            # soft_dice_heatmap 定义在本类之后, 运行时模块已加载完毕
            total = total + self.heatmap_dice_weight * (
                1.0 - soft_dice_heatmap(pred_heatmap, gt_heatmap)
            )

        return total


def soft_dice_heatmap(pred: torch.Tensor, gt: torch.Tensor, smooth: float = 1e-5) -> torch.Tensor:
    """
    预测 heatmap 与 GT heatmap 的 soft Dice（按 batch 平均）.
    pred, gt: 同形状 float，常见 (B, 1, D, H, W) 或 (B, D, H, W).
    返回标量 tensor，便于 .item() 记录。
    """
    if pred.shape != gt.shape:
        raise ValueError(f"soft_dice_heatmap: shape mismatch {pred.shape} vs {gt.shape}")
    p = pred.reshape(pred.shape[0], -1)
    g = gt.reshape(gt.shape[0], -1)
    inter = (p * g).sum(dim=1)
    union = p.sum(dim=1) + g.sum(dim=1)
    dice = (2.0 * inter + smooth) / (union + smooth)
    return dice.mean()
